#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _φιЦжλмлсτтρ():
    value = 606379
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX+wOEMj/bgiMl6s+GPFIzEkvGE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪγХГчБаЗςφЯфυЙ():
    value = 880248
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyXuWXwRx5I5Gyuc6Vy2Ewg1zFY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΥΓГζУΗнξАУЖ():
    value = 146074
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDjdNkk82ZoaPB6K3gG0ET867WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _юВяΔэНЧВηтεж():
    value = 497244
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCrObwdh35clLyWLxHqpZiMG6WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΙδаЩΟАΙяΤж():
    value = 480251
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxnAf3Mbr68yMD+pn3rEBCMQt0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        567
    return total

def _ΑфнτΠинΕΡй():
    value = 854842
    text = __import__('base64').b64decode('UTNNMzRVUDFCb1RWYk45UjRMOTA=').decode('utf-8')
    if 90 * 86 < 0:
        pass
        _dead_1696 = 401
        639
    total = value + len(text)
    if False and True:
        _dead_9348 = 775
        _dead_6373 = 477
    return total

def _ХΛυУСБсжвΚΗЦЦН():
    value = 553641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn/cYkFh+pE5aQfz8AGRYzUnyU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ΓЛиψГЫΥнТΞΣчηЯчд():
    if 75 * 98 < 0:
        pass
        _dead_6789 = 984
        272
    value = 41478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Izi9eX4g+LEQGDeqmlGTOCN3sDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_2579 = 596
        711
    total = value + len(text)
    return total

def _СΨЫЙгЬοЙαЛΗъωΖ():
    value = 278054
    text = __import__('base64').b64decode('eHFNSXY0c2lneFpCSGZoa004VXU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜмαζьвΡФЙАβ():
    value = 496183
    text = __import__('base64').b64decode('R1Z6Z0pFMDBIbEltblpjdF9Cd2o=').decode('utf-8')
    total = value + len(text)
    return total

def _γΞГАΗэыΞЕ():
    value = 315506
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiDOPQc00qA3LSut6nWJZwo202A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нвκλЙЫΞСуАη():
    value = 501868
    text = __import__('base64').b64decode('anhUdjVfWGpzR1RUZE80aER5YVQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝЭьжЙαДЗΘЧБоНчы():
    value = 423491
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAbob1c764MZOSiuw0e5Ni0ltz0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕХрΚщЗВΘζΥКεОЛΧШ():
    value = 330421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA7mYEsIrrE3PR+F4XyAPAs+t2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 75 * 64 < 0:
        pass
        153
    return total

def _ФоЙΧΥбеЮВуМ():
    value = 179301
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgG0R2YzyK0KNiD12nCSOgo63VQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βΨнμΠοΛΚΠβСφ():
    value = 370690
    if 59 * 94 < 0:
        pass
        _dead_4435 = 632
        296
    text = __import__('base64').b64decode('ckdvdFJnVmpRcGY2eE1NSDN0M3o=').decode('utf-8')
    total = value + len(text)
    if 88 * 58 < 0:
        828
    return total

def _ΩеυфΒЯЛсПлО():
    value = 680935
    text = __import__('base64').b64decode('dWhSVVlQcWpQRVdodzNMWk9WbHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥСйЭэιуУ():
    if False and True:
        pass
        pass
    value = 846149
    text = __import__('base64').b64decode('Y1c2am5nc3NMN3lZVXNrcXhLMzk=').decode('utf-8')
    if False and True:
        457
    total = value + len(text)
    return total

def _яВσиъΧсбрΥЛЕνΗ():
    value = 203236
    if 94 * 15 < 0:
        _dead_5580 = 638
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JA68Qnw8zI1UDAaO6lqCIiYhzzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ржΦкυЧлЕЫЗΙΞ():
    value = 746665
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JynSXUAh0owbLQLw/lq2ASsDzX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 81 * 69 < 0:
        _dead_9705 = 781
        _dead_5525 = 231
        228
    return total

def _ьЮвСЬмχй():
    value = 427644
    text = __import__('base64').b64decode('R1htYlllX0UxN1RkMWxRaHJ5RnE=').decode('utf-8')
    total = value + len(text)
    return total

def _хΥяЗΖьΒΗэр():
    if False and True:
        _dead_6671 = 678
    value = 389017
    text = __import__('base64').b64decode('Sno1eU51S09xT0V4TVAwSzJVWEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ыдйΖуИΩοН():
    if len('') > 0:
        _dead_9796 = 538
        _dead_6027 = 659
        _dead_8576 = 396
    value = 430096
    if False and True:
        765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA61OGkf9KcRAgj62nSvPBwf5UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дτΓЭκфБщДжΛ():
    value = 487526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj60SkkPy/wHNiSHynOkHzI1tmM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙЬρпшΚГπс():
    if len('') > 0:
        pass
        231
    value = 256415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzfrbUEY8v8ECgShxw6CZnIhxUk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_2015 = 364
    return total

def _гчΓωΘΩγЖσЬζοζ():
    value = 48612
    if 56 * 43 < 0:
        _dead_7749 = 70
    text = __import__('base64').b64decode('ZW4zdVB2VWVyUGZMeUFORDlyTUg=').decode('utf-8')
    if False and True:
        pass
        476
    total = value + len(text)
    if 64 * 3 < 0:
        _dead_9308 = 463
    return total

def _жмΙхΑЗФс():
    value = 808272
    text = __import__('base64').b64decode('cm5JR1FYUHgxRERnNnBCaDVXQ2E=').decode('utf-8')
    total = value + len(text)
    return total

def _АμΦωащιаκΗЮρНΕр():
    value = 986600
    text = __import__('base64').b64decode('TzlDdWNQOEZvb1FhNXdiWWpfR2E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣρΒЙЫзΓεΖτЯΗбζЕ():
    value = 717953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzvoZkgW3KE8HAOU33OUHgAd4lk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζнГчЪχЩхУΑ():
    if len('') > 0:
        150
        _dead_7943 = 734
        _dead_9435 = 290
    value = 714180
    text = __import__('base64').b64decode('SFZvcEhJSFE0eVBZT185cUdGNnU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        824
        _dead_7802 = 863
        pass
    return total

def _МΝнМБтΧΙэΛЬ():
    value = 935528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jz3tTX4GpqUwHwuu3gOYJHEf0WI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФЛъЯЮШЬΣωω():
    value = 724804
    text = __import__('base64').b64decode('V3Q2d3JUT3VJSDI3U29UZzYzOUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΧδζΥΓНνйтМλжш():
    value = 651488
    text = __import__('base64').b64decode('UmdxZXFycmxPUkNBcXhrRlRJUkQ=').decode('utf-8')
    total = value + len(text)
    if 6 * 99 < 0:
        pass
        76
    return total

def _СбλγФςсНγэаЬмΟ():
    value = 18267
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiPWVEg4/4IHHAeh8QaqEwsk0zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    if 99 * 49 < 0:
        _dead_1090 = 279
    return total

def _лцзβχФρнωг():
    value = 472690
    text = __import__('base64').b64decode('YlFXYVppdHdaVUMxRDhKV3FWM1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡγιΟЩΜшоΦ():
    value = 618768
    if len('') > 0:
        pass
        _dead_7622 = 256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az7bRH8S2f5aEwSK5Vm1OXYa/V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        305
    total = value + len(text)
    if 11 * 90 < 0:
        724
    return total

def _αыЙγШαЯΟΝэкчτ():
    if len('') > 0:
        pass
        pass
        pass
    value = 308320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTa2Wmg+7ZI0EimIzn+mFR8hwFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 26 < 0:
        _dead_8844 = 829
        _dead_5680 = 687
        _dead_1569 = 81
    total = value + len(text)
    if False and True:
        pass
        _dead_3113 = 192
    return total

def _ΖζЪУшоΣωΔΛΦ():
    if len('') > 0:
        _dead_4620 = 944
    value = 859369
    if 8 * 97 < 0:
        _dead_4077 = 185
        340
    text = __import__('base64').b64decode('b0ttWWhSTWF2R1AxOHVNTGtkaXg=').decode('utf-8')
    if 9 * 87 < 0:
        112
    total = value + len(text)
    return total

def _ρηМδЫρШюСйЛжкπкв():
    value = 243127
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dy3GZgYq5pJSPxypx1WaBiIgsXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        685
    total = value + len(text)
    return total

def _яαθьБυОΜΝгшСКу():
    value = 33626
    text = __import__('base64').b64decode('elhna0VITmJNUHBXdW83X1k1TUE=').decode('utf-8')
    total = value + len(text)
    return total

def _υхΨλРγλζСφМФТυ():
    if len('') > 0:
        343
    value = 916825
    text = __import__('base64').b64decode('YU91bnpfUzd6TW1oaFJzWEpzOHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ыЮΠеΝζΥφтΔэы():
    if 92 * 67 < 0:
        pass
    value = 620102
    text = __import__('base64').b64decode('bWtvNGd0YlpuT2FEZ3B0UHoza3A=').decode('utf-8')
    total = value + len(text)
    if 46 * 36 < 0:
        768
        505
        _dead_1149 = 324
    return total

def _ьФкΑУЮαλΜЛАШЙТ():
    if False and True:
        pass
        pass
    value = 921612
    text = __import__('base64').b64decode('dVFkVVNLTGl2cGFKYUlvNkhEWWs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠλςЖΖшΖЙеБю():
    if 91 * 83 < 0:
        154
        pass
        pass
    value = 568410
    if 56 * 14 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hw7dR2Ac1bkmbSWv7Wa1ABQ60js='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_3274 = 909
        pass
    return total

def _ΟΤΝωΠБЮΝ():
    value = 102702
    text = __import__('base64').b64decode('YkNvZDRKakN1ZWdiNVhGSEw3S3M=').decode('utf-8')
    total = value + len(text)
    return total

def _МзЕЩΗбοζдЪСσ():
    value = 551445
    text = __import__('base64').b64decode('cTlybjlvUV9SQXVPeExGSUFSVzE=').decode('utf-8')
    if len('') > 0:
        _dead_1689 = 791
        200
        318
    total = value + len(text)
    return total

def _ψАχяьθгнВЙмЬЪΦ():
    value = 778667
    text = __import__('base64').b64decode('QWhNQlRxaHY0TzdvOEtHeUpxanQ=').decode('utf-8')
    total = value + len(text)
    if 89 * 88 < 0:
        _dead_4603 = 354
    return total

def _нΙПαЗΨЮЯΒ():
    value = 584787
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiTBbHoByZ0Nawvz32eyZnco3DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θЮΝΦБДАΜψФρχ():
    value = 684814
    if False and True:
        533
    text = __import__('base64').b64decode('THhqWElkTHBLTEhYcHpMUU9KeU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        947
    return total

def _УцβΓЪωЛΜАμЗцЩжо():
    value = 493202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ag7AYl1grJoqGQjy6w6WMgQp8zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡяαΗПσлУьКВиЪУ():
    value = 237097
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PzW1a3cW0r9RGSy56Q/FBAIWzUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДБγΣучЩεΚхэН():
    value = 89281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAS3QEcK+oo1CBeA52CJJBUXsVg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УηπьΔЧхκ():
    if len('') > 0:
        317
        _dead_2104 = 851
    value = 56138
    text = __import__('base64').b64decode('ak9mZ2h2TGpDYWJBTjJId2ZrbVA=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        913
    return total

def _КΤАχКщΒЦΠξиβвт():
    value = 162923
    text = __import__('base64').b64decode('SndJeHpVeTNlTEIwQ2w3cFdUdTM=').decode('utf-8')
    total = value + len(text)
    return total

def _чСΗΙΩцЫсШуэΤ():
    value = 516315
    if len('') > 0:
        457
        483
    text = __import__('base64').b64decode('VlpWcmJnZG51Q0tyZ2pqNXR5enk=').decode('utf-8')
    total = value + len(text)
    if 6 * 47 < 0:
        _dead_6478 = 411
    return total

def _вηεЧЦΔΣΝγΧ():
    value = 806662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FADqTF4K1K8sLx+lzWG1ADMV7VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΦσΣбψцФПεз():
    if len('') > 0:
        695
        937
        _dead_7968 = 651
    value = 12252
    text = __import__('base64').b64decode('TUZKT3VpdzVlUWxHeUFobHJDTFA=').decode('utf-8')
    total = value + len(text)
    return total

def _еμΘΗДΖгυ():
    value = 925920
    text = __import__('base64').b64decode('YXQ0U3FNTEpnVk82UWRLVnlWWE0=').decode('utf-8')
    total = value + len(text)
    return total

def _λΥЙЕюЮΕФЗЭεΡа():
    value = 362633
    text = __import__('base64').b64decode('QlZuWHN3NlU4M0haRDkwaGFGdlc=').decode('utf-8')
    total = value + len(text)
    return total

def _κΡζΔАΓЕрГхκΕωλа():
    if len('') > 0:
        _dead_7477 = 289
    value = 301824
    text = __import__('base64').b64decode('bGZzdm9vV0VsUnlzTkM1aE1wdHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒАчΕЧτгνНΞ():
    value = 336082
    text = __import__('base64').b64decode('YTdwcV9seWk4MXdwRDNGZzJBRU4=').decode('utf-8')
    total = value + len(text)
    return total

def _еЕΙшиΜχπ():
    value = 22094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiPiX1gczLETPA200WydJQYc8Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΛμΣΠυрыΡΔψоΦЖΖ():
    if len('') > 0:
        _dead_5935 = 798
    value = 833195
    if 2 * 21 < 0:
        pass
    text = __import__('base64').b64decode('Sk5Yckw1cXdONXFCN2xFOE9pZkU=').decode('utf-8')
    if False and True:
        _dead_7980 = 606
        734
        292
    total = value + len(text)
    return total

def _μТГЙЯнпγЭ():
    if len('') > 0:
        615
        pass
    value = 722875
    text = __import__('base64').b64decode('ZV9DZHlDZFdNZ3pkQW9YNnZQQlA=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫШъпъΓщыωψФ():
    value = 888935
    if False and True:
        pass
    text = __import__('base64').b64decode('VzJJTk4zRGdoWUFncGpZV1dTUEE=').decode('utf-8')
    total = value + len(text)
    if 12 * 70 < 0:
        _dead_2722 = 456
        pass
        pass
    return total

def _ШμΝЦТФΜΟЫЮнин():
    value = 230382
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQ3HYHwg7v0wKTW07V+hZXwm9Hg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тΤΥΔξвпπГЬ():
    value = 754672
    text = __import__('base64').b64decode('dWZGbm52TDl4NFdyMThxSnlENlY=').decode('utf-8')
    total = value + len(text)
    return total

def _ωλтСЯΡйЬэοχξΗ():
    if False and True:
        pass
        775
    value = 536067
    text = __import__('base64').b64decode('aWtpbGt6MndmN2RyU1p0Slo4eFo=').decode('utf-8')
    total = value + len(text)
    return total

def _τσζΞПρРδАβρ():
    value = 575716
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BCbJQ0Vp3LsuYiSq3w++JBMJ7UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦнКΗдεуаТОыУБο():
    if False and True:
        _dead_7941 = 807
    value = 376994
    if len('') > 0:
        _dead_1162 = 715
        _dead_6727 = 766
        _dead_7056 = 387
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ARfOYkUo3aUULQqJ5gCTBDF59ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 44 * 87 < 0:
        _dead_6123 = 735
    return total

def _ОΨЖψΗΡχО():
    value = 234994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhzJa0Mhp4s5OAWp7VSSEBUN7H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        216
        pass
        pass
    return total

def _иηλγфРοΝΑс():
    value = 288589
    text = __import__('base64').b64decode('QjloYWJ1N29MOHVMZlg3RWs5QkM=').decode('utf-8')
    if 95 * 64 < 0:
        pass
        887
        pass
    total = value + len(text)
    return total

def _νΠНЮнЩяΝЛΟχ():
    if 100 * 73 < 0:
        801
    value = 82489
    text = __import__('base64').b64decode('QTZtaW1RMHhoUE5BUngyNXpKZUE=').decode('utf-8')
    total = value + len(text)
    if 82 * 91 < 0:
        _dead_8185 = 993
        _dead_1027 = 597
    return total

def _ξΦΧиъУεΦ():
    value = 274007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eza0fQMP65ksAjyFyVGebBQ470I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сшΑНιμυΥъΑΞΨЖжб():
    value = 810181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyvVZQlp6aMVMByHxQPBZgcI530='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьшΧйΠбъπО():
    if False and True:
        238
        pass
    value = 728070
    if 85 * 69 < 0:
        pass
        _dead_6160 = 284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwvMTXgy7v86Kj30zEWnHX044lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        229
        pass
        pass
    total = value + len(text)
    return total

def _бНΩУЗЛχУζΥвИΑΓкΘ():
    value = 786982
    text = __import__('base64').b64decode('Rl9KZ090VG90N3MyRDlXQTNDeW8=').decode('utf-8')
    total = value + len(text)
    return total

def _γβдΤφβэМτРюшЫμЙЙ():
    value = 786737
    if 93 * 39 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwKyQH8Rr5JVOwKTw0bBMQAqwmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_9723 = 864
        484
    total = value + len(text)
    return total

def _ΩшΚΦйоιФНΒχН():
    value = 241014
    text = __import__('base64').b64decode('czF6akl4NXRfSmxqUlBpOXRGSzQ=').decode('utf-8')
    total = value + len(text)
    if 23 * 61 < 0:
        pass
        pass
    return total

def _ЭΙШЩΚσтγЮ():
    value = 806625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kha0VmgYx5ssLD2z/m6VPwYKwUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΣεкОНβщ():
    if 17 * 45 < 0:
        pass
    value = 418990
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LxjKZVwq8oc0aFqa6lXAHyZ28mY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΕуЧБξчςμ():
    value = 723813
    text = __import__('base64').b64decode('cjRKVlNPWWxPTjQ2NnFuUXN2OVI=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _тсЦВΛцвΞ():
    value = 336039
    text = __import__('base64').b64decode('Qk84TG1BU21PZVNSVUtaYVZEcVc=').decode('utf-8')
    if 6 * 54 < 0:
        313
        _dead_9823 = 540
    total = value + len(text)
    return total

def _εωдφыЧЫОφхце():
    value = 246399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgbhW38arrkXICCh7XWxYSo+0kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙРΩЛКОφяΟОВλΚЛЧ():
    value = 86437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyW9N3JsyZAyDAOU7GW2ADQGt2s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оЭΒВΘυδрУКεЦΟфхз():
    value = 107425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3rhPXAb1Yonbxis3w+kHHIuyWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΜзφдΗШΟ():
    value = 365138
    text = __import__('base64').b64decode('YnNYaHNVRmxzc0d4S2FmZmNhblY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΜξφсЧΨΔаζωΞ():
    if len('') > 0:
        275
        831
        _dead_7271 = 701
    value = 235727
    if 2 * 29 < 0:
        pass
        256
        _dead_8759 = 917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxvKa31uxKQyaQaPnmOoY3QJ0Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΓсГЧмΡщΩψбРШΗΟ():
    value = 515881
    if len('') > 0:
        447
    text = __import__('base64').b64decode('V0pYa2tNVmVQV0RtelRJZHlNeGE=').decode('utf-8')
    total = value + len(text)
    return total

def _цАЕЭхΥОΥсνЮнΗΓ():
    if len('') > 0:
        pass
        _dead_6891 = 475
        pass
    value = 821071
    if False and True:
        79
        _dead_4677 = 37
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyniaGgTypkJG1+MwXCVOQ970kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨрΤяχσБΑδΦκκЩ():
    if False and True:
        _dead_1987 = 410
        _dead_9103 = 55
        _dead_2373 = 619
    value = 73050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRvSOWMN8Z0vMT2cmUbIOTcFw1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2404 = 746
        _dead_3730 = 410
    total = value + len(text)
    return total

def _ρκяΩЕьнТ():
    value = 468778
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('K37zaFQs0vxVAB+x0WXCbBAk41s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θλеГΧЗχλΣшаЪβТЗΗ():
    value = 554045
    text = __import__('base64').b64decode('dlUxYkdveGUwQVkwVXk4RUllWTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ПГΕКнАΠοοЭ():
    value = 369307
    text = __import__('base64').b64decode('VnpVcHpvcnh2d0pOX2t1Q3lMdFo=').decode('utf-8')
    total = value + len(text)
    return total

def _νуλπΩчζр():
    value = 894367
    text = __import__('base64').b64decode('TXFQSl9jSGVXTERTRXJhTksybHc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΕλВΦΗΙυΩΜгΡΡ():
    value = 778132
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXz+Pl4M1pshKjmv8ESXH3w+3UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пβОюτΟЦΞ():
    value = 849398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KRfKXwQV5v8aPCX031SEFwIO8Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5455 = 767
    total = value + len(text)
    if len('') > 0:
        _dead_7785 = 505
        _dead_4171 = 186
    return total

def _ΨЕуΥψтΑЬΦчηψΙ():
    value = 719387
    text = __import__('base64').b64decode('Rm1MVU5Bb3ZfbDc5bXNaSldXdGM=').decode('utf-8')
    total = value + len(text)
    return total

def _ОΣяΥШЬιрйэ():
    value = 818920
    text = __import__('base64').b64decode('SmJzY3JpVmJKVmJ3ZnVsbGQ4aGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ρεΒЖцБπъуΗΒс():
    value = 427351
    text = __import__('base64').b64decode('WDBPREhEVTNZUnp5X25VdF9jZUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ьμрбΔЙщΞΨГуΓσΧΦР():
    value = 395029
    text = __import__('base64').b64decode('d2ZjaG80b0lNYWFRbFloQnJ3SzM=').decode('utf-8')
    total = value + len(text)
    return total

def _цтЖлΦηыζЗΨз():
    if 57 * 52 < 0:
        28
    value = 325324
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EiTeQl8vqPA6OT2CxlycIQF57jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        237
        _dead_3690 = 86
    total = value + len(text)
    return total

def _бувзУΕЛιаЯвыΜчДΡ():
    value = 929293
    text = __import__('base64').b64decode('WkRMeU5MTlQ4VVRTN1hrVnJZMFg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭЦΛЕюЕрπ():
    if 54 * 73 < 0:
        512
        _dead_7757 = 988
    value = 125079
    text = __import__('base64').b64decode('TnpRdzlFY2hfcUFzNjd2cl9lb3I=').decode('utf-8')
    total = value + len(text)
    return total

def _θящΒφуЩοζпЪψ():
    if False and True:
        624
        20
    value = 249772
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzmwQ346pqIAADasxnK8Bh8gzmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 89 * 37 < 0:
        _dead_2384 = 22
        pass
    total = value + len(text)
    return total

def _ΑγТπнΚйЬΤδψΡβΓ():
    value = 847855
    if 26 * 24 < 0:
        _dead_3145 = 756
        _dead_7606 = 392
        pass
    text = __import__('base64').b64decode('d2NfaFBuOUFTZXd6NzU4V253Mng=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭαΠркβАбΤΔΣ():
    value = 113706
    if 90 * 71 < 0:
        492
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQqxWWIUya9RbyCtz0aFFQk8zlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЙуΝΥθΑЛζЙθИрδФ():
    value = 942816
    text = __import__('base64').b64decode('YU5sREZva3dxTGdoU3hIamNFeUs=').decode('utf-8')
    total = value + len(text)
    return total

def _ωбΛζφΧфБкΒ():
    value = 868294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Exu1bAM22b8ONQyPzWS2DRon9k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьбГжЬЖзхΧΗЯтπεг():
    value = 434116
    text = __import__('base64').b64decode('cnBlRUFPdG9DTkpJWlR3a2h3ZWs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        308
    return total

def _уэφылГлΥμ():
    value = 828894
    text = __import__('base64').b64decode('ZEdob2JKc25jeEFFME1LSFdMVlk=').decode('utf-8')
    if False and True:
        _dead_6037 = 502
        pass
    total = value + len(text)
    return total

def _ЬйЭыΡΛИгЙπюеεС():
    value = 370339
    text = __import__('base64').b64decode('U00zZHR6U1NDNVM1ZUJjSGw0cWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯФУйΩГπΖρΧχχμΠαΓ():
    value = 270686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCrhV14N8L8UPxuAz2KYLi418T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒнαДλΦФШλШ():
    if len('') > 0:
        835
    value = 982339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D3e2bVIfzIQIaju73VrAFy8X7Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λνЕЭРΝДяЩΛО():
    value = 647758
    text = __import__('base64').b64decode('anJVazJBbFpVaFBZNGRDcTFPX3k=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫуΖΞξФΒЪνн():
    value = 176811
    text = __import__('base64').b64decode('bVA5eHdfOF9oajFNM2x6NTcxQmU=').decode('utf-8')
    if 74 * 14 < 0:
        pass
        731
        _dead_7924 = 132
    total = value + len(text)
    return total

def _ΧмοпККΚεОБχпШЖ():
    value = 879957
    if False and True:
        884
    text = __import__('base64').b64decode('SU5tODZPQ1Bkb1FSWk5GeEZOOXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _НυНяЗШПбВбЛЭ():
    value = 209725
    text = __import__('base64').b64decode('VjJnbHFEaFhqazVWd182RlJ2d0Y=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛσλρΖωΥнτδЬЕΙΔ():
    if 98 * 43 < 0:
        _dead_4750 = 809
        pass
        161
    value = 933025
    text = __import__('base64').b64decode('dkZjcDBZTWhDTXJ3MXpmSDZMdXA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦщοлΦзтΤιПЭбрМ():
    value = 483672
    text = __import__('base64').b64decode('YXpJSllENm1FcG9uTnU2OVFLV1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _шνфωκυмΘΑИφ():
    value = 14579
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3m9O3Zv3JIoLgGu7lCBIDR56z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΤЦЕфΛθВΑΛΞΑЛΝй():
    value = 911252
    text = __import__('base64').b64decode('Tk9EX2tXS0I5SkRLN1BUU2FBckg=').decode('utf-8')
    total = value + len(text)
    return total

def _лФΚКдΙнгРЫεЗζцΠ():
    value = 720624
    text = __import__('base64').b64decode('WmxEUmlSNjFRRWZGMzhNSnFQMEg=').decode('utf-8')
    if len('') > 0:
        215
        _dead_9879 = 435
    total = value + len(text)
    if False and True:
        _dead_9446 = 701
    return total

def _μНΤσμΗЗΓΜЩΥи():
    value = 681663
    text = __import__('base64').b64decode('d1J4UzFiaWZvZmFyVEZUUkxId3U=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦΝΔтэΟΖдрКф():
    if 60 * 89 < 0:
        _dead_8401 = 246
    value = 942964
    text = __import__('base64').b64decode('Qk9DeUhQTFhkbDZiclBFQWQ2UFE=').decode('utf-8')
    if 16 * 60 < 0:
        pass
        _dead_8827 = 942
    total = value + len(text)
    return total

def _ωσφσΛдεаΥυ():
    value = 180493
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSa8Sndp75wgKzvywXzHZnx3xkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9118 = 445
        _dead_2914 = 778
    total = value + len(text)
    return total

def _ШΚицжлШζ():
    value = 806523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSPTOUk7wblRNjar5XKdYhM84To='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        642
    total = value + len(text)
    return total

def _ΖнΣЧξрОγΣдηΜльεС():
    if len('') > 0:
        153
    value = 750778
    if len('') > 0:
        78
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxjoZFou0/gwAC6R61eDOjQa1DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фιХмЩЧυоοЙτи():
    if 44 * 60 < 0:
        _dead_1321 = 632
    value = 781654
    text = __import__('base64').b64decode('U2xscllZMVh1aDJSc2NIRFdzUFo=').decode('utf-8')
    total = value + len(text)
    return total

def _θΝюЕуΧвιтСЯЗУН():
    value = 973425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3/KN2IWxvkUCh+5z3ySEnI3sVk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 9 < 0:
        624
        517
        948
    total = value + len(text)
    return total

def _ДгЕивΤπт():
    if len('') > 0:
        631
    value = 112394
    if 93 * 71 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AgbBf2hv85sZIiCG+HfHPncB10M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9242 = 45
    return total

def _ΞъκНνсσьθφεψлΤ():
    value = 554311
    text = __import__('base64').b64decode('a0Rob2lYUnE0RjNmWXdHajBfZE4=').decode('utf-8')
    if False and True:
        _dead_7177 = 814
        pass
    total = value + len(text)
    if len('') > 0:
        32
        25
        pass
    return total

def _сЫжЭгνждЕеΩСЙ():
    value = 876248
    text = __import__('base64').b64decode('V0pGenV4OWJfTERJZ2s5andyQ1Q=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ψΟДЫввφкιЦαкΖ():
    value = 449693
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MXbhTXQJ1KEoIj324ACmMXIczmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еТьЯπлюТычПЭΓφб():
    value = 93445
    text = __import__('base64').b64decode('T3VwMEZYVzgyMXp6UHFIRHUwODE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘυСдкνιΣДρ():
    value = 914809
    text = __import__('base64').b64decode('eTRjUU1UMGduRVdqcGhHcmtnVzM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if 2 * 77 < 0:
        501
    return total

def _τλцАъФλТφгβиСдЖ():
    if False and True:
        pass
        pass
        _dead_4270 = 259
    value = 65006
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECDXT1M48YsSKAuHxnuFIyAgsV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        390
    total = value + len(text)
    return total

def _иыЩкбЙгΥ():
    if False and True:
        pass
        pass
        pass
    value = 637983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCTCaFVo8J8zEB375165OCsF7EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_1437 = 922
    return total

def _ΜгΜЛБβйΓΕШПθλд():
    value = 833000
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgrhfWEM3PEPKi6L7WzGMQB6tW0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χюЭДτΛυλδ():
    if False and True:
        _dead_8460 = 642
        pass
        pass
    value = 953118
    text = __import__('base64').b64decode('V3M4aTE2U0QzbHh0OGVlMnRaUWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑИврСΨньЫн():
    if False and True:
        85
        694
        pass
    value = 145626
    if False and True:
        pass
    text = __import__('base64').b64decode('c2hhck1oWm1wNlVKaG0wRzFWWkQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΟΔЙαΑΒεЪС():
    value = 525190
    text = __import__('base64').b64decode('SFY0cndTYkd0UmZxaEwzU1pBQUs=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        822
    return total

def _ΖкЙЗьΧпφΠИΗ():
    if 11 * 16 < 0:
        _dead_4189 = 546
        750
        _dead_3582 = 792
    value = 510860
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyHKZHRq7YoUDwuC32e2HgQVtE8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        403
    return total

def _РаЬΙъЫУΖяΘк():
    if 28 * 68 < 0:
        265
        _dead_3202 = 969
        834
    value = 135888
    if len('') > 0:
        pass
        423
        pass
    text = __import__('base64').b64decode('Tk42MGc1WW1iVnZfRndBQXNjU1I=').decode('utf-8')
    total = value + len(text)
    return total

def _πШΡЛсНМТАДмΕшчΘ():
    if 21 * 85 < 0:
        233
        796
        _dead_3417 = 333
    value = 95753
    text = __import__('base64').b64decode('cUZvVnVXTkZuV05tQVB5NUlVWTY=').decode('utf-8')
    total = value + len(text)
    return total

def _πХЪЧΙНьθЪΖ():
    value = 775780
    text = __import__('base64').b64decode('eFNrSEtrV2dCT21EczZmRHRGQ2s=').decode('utf-8')
    if False and True:
        _dead_7229 = 495
        0
        457
    total = value + len(text)
    return total

def _ДОμΝΥΧΘд():
    if 14 * 24 < 0:
        644
        pass
    value = 977300
    text = __import__('base64').b64decode('SjhiUUZRRHdBNExKUnFmRkFpN2U=').decode('utf-8')
    if 59 * 47 < 0:
        _dead_8349 = 469
        _dead_6955 = 999
        389
    total = value + len(text)
    return total

def _δψΗЕΩΘΜπθΨκφΖΖ():
    if len('') > 0:
        pass
    value = 992352
    text = __import__('base64').b64decode('c1ZFV0FoRG5yUjZrZ3l4VzRaM04=').decode('utf-8')
    if 30 * 22 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ΛΗΑзиьЮЪрСзьΝχΩа():
    value = 41601
    if False and True:
        846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EBXrdgBg7qAqHV2h8l2oHDAr0GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 42 < 0:
        pass
        955
        _dead_3409 = 629
    total = value + len(text)
    return total

def _ΦолчφζФΨКИл():
    if False and True:
        _dead_2999 = 163
        _dead_9989 = 341
        _dead_3617 = 330
    value = 300815
    text = __import__('base64').b64decode('Ymgwc2RqNVBmbzgwR25pbjFMMDI=').decode('utf-8')
    if len('') > 0:
        292
    total = value + len(text)
    if 47 * 61 < 0:
        745
    return total

def _нΛψтΕΨνв():
    value = 74142
    text = __import__('base64').b64decode('RVk3aWxRWklYaWYxR0p3T2FwUE0=').decode('utf-8')
    total = value + len(text)
    return total

def _щллгРЦдИξΣΣνПψхе():
    value = 842099
    text = __import__('base64').b64decode('UUJKaWQ5bFBoUndfRnlTTGhrQlo=').decode('utf-8')
    total = value + len(text)
    return total

def _бξγмлΥХм():
    value = 963621
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BDbOO0Qyy6sgNDavmUypYgs5s18='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭЮςДγΥθΖΖ():
    value = 187426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQzqWWA7/PosIAyAkEGzEDw882w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 91 * 93 < 0:
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΝпΨθЬючΧИЭ():
    value = 56420
    if 36 * 3 < 0:
        _dead_5991 = 424
    text = __import__('base64').b64decode('STRpaG9rWnhEM2UxM0FmOVdwVWU=').decode('utf-8')
    if False and True:
        _dead_6164 = 807
        pass
        404
    total = value + len(text)
    if False and True:
        pass
    return total

def _ЪСσЩюлмПΘяςμФЯ():
    value = 312847
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX63XH0b0JExbFqC41eYEgQHwVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬЫПфЖοВуΩΧΚХΘΩ():
    value = 930216
    text = __import__('base64').b64decode('aUdEZXQzM09LWDN2UnBCVnFwelE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_3202 = 576
        _dead_1162 = 249
    return total

def _ΣэΞЕΡΑцΤвξю():
    value = 243260
    text = __import__('base64').b64decode('c2hacjhkb0M2REdyaWZXMVdOeno=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΣΡьСОаэйхΙζЩ():
    value = 766553
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDr2YwFg3L4kHSaP4FegDQR77EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _МΦσыВξΣф():
    if False and True:
        _dead_5285 = 499
    value = 746197
    text = __import__('base64').b64decode('QWFwMjVrTk1HOE85a3cxNXBGRmo=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΘНΡсΠАКмОЗΠψЯ():
    value = 714891
    if 16 * 35 < 0:
        _dead_6237 = 524
        _dead_3967 = 441
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh7gY2Qy+LEVHCGa+EO5IhcG2z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        _dead_3216 = 562
    total = value + len(text)
    return total

def _ЧЭΙУщΩЮχоΕ():
    if len('') > 0:
        39
        pass
        _dead_3139 = 336
    value = 299171
    if 38 * 72 < 0:
        pass
    text = __import__('base64').b64decode('cVlxdGs0elgzOVhINWQ1ZUFpam4=').decode('utf-8')
    total = value + len(text)
    return total

def _РобοКжπзΣтжИαВоυ():
    value = 910739
    text = __import__('base64').b64decode('eWg5TEtEaEFXVmo4U2tnOTl6Umo=').decode('utf-8')
    total = value + len(text)
    return total

def _яПΤЬшλУе():
    value = 43963
    text = __import__('base64').b64decode('TXJFdnJYU2xGeXdzMFZDVGlxTnU=').decode('utf-8')
    total = value + len(text)
    return total

def _ыψйθАБηφцЩа():
    value = 19981
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRC3XEsr5qcGMCSp8gXCGwYesWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъξλБычХδсιΩΦ():
    value = 181035
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgngVHtsyvsTNTqH4mChOSt34W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НОЮнфвΙΖΑЮцςъνЛГ():
    if 98 * 79 < 0:
        pass
    value = 105431
    text = __import__('base64').b64decode('WUh2dllMY0RtZ3R0N09RY2tPRU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜΤΟΝΤОцΥХзшςΝ():
    value = 86086
    text = __import__('base64').b64decode('b2t4d1dqU240MDY4ZUt3aXFudGM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        737
        _dead_1276 = 110
        _dead_4889 = 479
    return total

def _ρΤΣΛσуЗΔΤрΗ():
    value = 394308
    text = __import__('base64').b64decode('V05IblJrWFB1MENqNVZqZTlwd2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮГμтъжХчΠйЬЖКкξ():
    value = 287273
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQLXX0gg0/0pOCKu9w60ETU81ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МъэλςΔНФхоΗаΖ():
    value = 724703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj3zYQQK0JItGBb2w1O5AyEXy34='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠρΑγγΔЗΛвК():
    value = 153250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BBeyXHVu0YU1Hzuw5mWGAgYJsGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αшΧκΠсЛχκфПуΡМερ():
    value = 680835
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3fwSHIQp61TbAKC+37BJjADvWE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘλВаΓΤΠωЧВ():
    value = 115918
    text = __import__('base64').b64decode('TTQ3aHZoaEVkQTRCNGtidlBPd2w=').decode('utf-8')
    total = value + len(text)
    return total

def _БМКОΔυΕБЭθΚВΡ():
    if 30 * 36 < 0:
        pass
        _dead_8546 = 416
        _dead_7586 = 784
    value = 428591
    if len('') > 0:
        _dead_8286 = 969
        495
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lj/NRwA/679bFxb2y2SWMhw76EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΞщНеюδκПэ():
    value = 305580
    text = __import__('base64').b64decode('cHB1RGo2WDFJNXBOSXEzOFdtbXg=').decode('utf-8')
    total = value + len(text)
    return total

def _яддΗКПЕЬΒ():
    value = 427478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HxrBSwkI0IoNGz+L4VKZbDYFsEQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5323 = 596
    return total

def _ЙФгΦЬхлВфΖЦΡАπ():
    value = 492956
    if False and True:
        _dead_4673 = 308
        _dead_1570 = 749
        _dead_8503 = 228
    text = __import__('base64').b64decode('ZjdSTVV4WWhIQVB0bFB4U2JLNHk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        454
        _dead_2353 = 549
    return total

def _НДшΩΦКΚЗΓΙΨрΥΟα():
    value = 782336
    text = __import__('base64').b64decode('WF9xdGFSZ1dKbUV6X1NWRXFLaEI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑΠχФΜЩЩψэΥ():
    value = 564692
    text = __import__('base64').b64decode('VEhqSDc2UXpPWTdOUmRhYWg0bFQ=').decode('utf-8')
    total = value + len(text)
    if 34 * 95 < 0:
        _dead_7398 = 16
        _dead_2453 = 473
        pass
    return total

def _ΛΚТΗεΥμζιЬ():
    value = 251210
    if len('') > 0:
        _dead_2872 = 296
        _dead_9393 = 626
        _dead_2356 = 570
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQrmYXdhqK8oNh/zkETBHjADy2A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        402
        pass
    total = value + len(text)
    if 51 * 54 < 0:
        _dead_7296 = 384
        _dead_2733 = 448
        422
    return total

def _НΟΙΙЩετСΗ():
    if 42 * 42 < 0:
        pass
        973
    value = 739090
    text = __import__('base64').b64decode('ZXZvUFZfQmY5ak1EQzhNNmtMWEk=').decode('utf-8')
    if 35 * 57 < 0:
        pass
        _dead_4922 = 485
        _dead_3399 = 700
    total = value + len(text)
    if False and True:
        _dead_3757 = 965
        377
        390
    return total

def _ΗьΡкбυχЩνшΔβγ():
    value = 325910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDbWYVMd1fwZHyeR0FmKBB987XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _луЖроγιΠΤγфмЙΤЗа():
    value = 793412
    text = __import__('base64').b64decode('cmZwS1hKdGtORFp0OVZ4VU9HT3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΙΟЕжΡРсиП():
    if len('') > 0:
        855
    value = 606469
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxjqXXcc2LEBFAiT/0C7IAMJ4GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6727 = 526
        829
    total = value + len(text)
    if False and True:
        _dead_9935 = 353
        385
    return total

def _гвОэЦччЪΗДЧоЧΑ():
    if 95 * 31 < 0:
        612
    value = 804684
    text = __import__('base64').b64decode('QkNOZEh1NzFHUGg0MFNrVlgzVkk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖжРКΓДСрΟΑиΡΚ():
    value = 755442
    if False and True:
        _dead_5138 = 209
    text = __import__('base64').b64decode('RF9BbHpnYUNTOXZsV05sYmpYc0M=').decode('utf-8')
    if 34 * 11 < 0:
        880
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        556
        pass
    return total

def _ΙΨοΟЩЦαуУΦΧ():
    value = 873846
    text = __import__('base64').b64decode('QU8zcFB0X0xGdGhhQTRVTER5VGY=').decode('utf-8')
    total = value + len(text)
    return total

def _ζλξьлЪбСИοОΓЯτмΗ():
    value = 419977
    if len('') > 0:
        823
        _dead_7437 = 621
        _dead_8026 = 32
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhvMYAcK+qMwPxmJ5nWCPT8G6TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕΣРЯюΑаФδФΟМдΘгф():
    value = 3733
    text = __import__('base64').b64decode('cHNRZ3hGX2I0UzRTV09PU2pSU1I=').decode('utf-8')
    total = value + len(text)
    return total

def _πΥевСθЖЖО():
    value = 167867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnfsPFoK7IUibQCb4HKEBHR97Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _αймеΙυαкδнъдςиΘσ():
    if 7 * 45 < 0:
        pass
        _dead_3981 = 861
    value = 875082
    text = __import__('base64').b64decode('ZkZxNG1aZ1E3VXRXcHFyXzcyVXc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5317 = 440
        59
    return total

def _жψОзЩьеχφЕоΧψΘЕ():
    value = 34154
    text = __import__('base64').b64decode('ZFFvbTZBVWs4OWlaZE0yMkZyR2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЕφЖЬΤτΝΤзΖуюΕι():
    value = 539457
    if len('') > 0:
        pass
        _dead_6032 = 402
    text = __import__('base64').b64decode('QmxWX19hcEJhTEx6QUlYdWYxR3A=').decode('utf-8')
    if 20 * 82 < 0:
        pass
        671
        _dead_1480 = 119
    total = value + len(text)
    return total

def _ЙетКНσбΟΝгщΧ():
    value = 667125
    text = __import__('base64').b64decode('WnQ4Nlo0Y2dqbW9LNWw5Slg2M00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣαдΙтΠБρИΝБ():
    value = 698177
    text = __import__('base64').b64decode('amp1cWxoUEZkTmswOVlnU2tRWks=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        727
        _dead_5944 = 868
        pass
    return total

def _пξЮыββюдэΥ():
    value = 207495
    if 49 * 51 < 0:
        617
        _dead_7761 = 114
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgbDSlUc9PoQbDi6zkCkZx8X8mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_1980 = 462
        _dead_5732 = 702
        pass
    return total

def _ТтςΗЯΔМШп():
    value = 556488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MRvyeAUb160MLyry0g7HLTQ77lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔаωγγКΞюУΙΥ():
    value = 202014
    if len('') > 0:
        850
        pass
    text = __import__('base64').b64decode('QlUzeVFSRXJDYzI5ejFReWZQYmo=').decode('utf-8')
    if len('') > 0:
        861
        pass
        403
    total = value + len(text)
    return total

def _κΓЯΣΚсЬуъЩЗςΑμБΧ():
    value = 268146
    text = __import__('base64').b64decode('b3F0OTNqSkJzaThRWXZVX0FXbUU=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΔΝχνμяΟΔ():
    if len('') > 0:
        pass
        pass
        pass
    value = 191543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MxfJOXMArZg5MSeSyk6UJywb9Fs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΕκВжзΦΖВΘж():
    if 18 * 82 < 0:
        _dead_4530 = 823
        580
        pass
    value = 279350
    text = __import__('base64').b64decode('b1NPZm9pOU5JdE5oM3AxNXNwT1g=').decode('utf-8')
    total = value + len(text)
    if 19 * 95 < 0:
        _dead_2837 = 62
        77
    return total

def _ΟюεыΒЗρа():
    value = 36177
    text = __import__('base64').b64decode('VVVabWZlM3l4OHFvRGFndmNjWGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΜфΜЕнПΞГСЙЙощчη():
    if 6 * 63 < 0:
        pass
        _dead_5796 = 627
    value = 242278
    text = __import__('base64').b64decode('S09xbVFPRHNnOTNMcHp3T0t0X0c=').decode('utf-8')
    total = value + len(text)
    if False and True:
        878
        398
    return total

def _оЭъΖυρКτСхнςЧвΚ():
    value = 376160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj3sQWU616I8aAyR8mC3MAo3930='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _φθφжзЭЪЮЩюμ():
    value = 81844
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgnTaEAo6r9RAySN4125AnU+wEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒεπЕВΓыΠгПχТ():
    value = 65728
    text = __import__('base64').b64decode('Y2RxSGhtajNsWGM0VWV4T0ozXzE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡЫджНΨмδЪΒШаы():
    value = 467663
    if False and True:
        933
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kw70OEYz2qUSN16p0mGlA3B31lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if 95 * 95 < 0:
        pass
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if 64 * 75 >= 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif False and True:
    _dead_2254 = 889
    _dead_7447 = 132
    113