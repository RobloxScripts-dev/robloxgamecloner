#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ЙΘδлаδаГоΗΡ():
    value = 222039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwfVOmkP5KsUBQeKzE6YOBI280I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧълΧζАКЩκЫ():
    value = 603228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA23PmAG97oTKAGMx3yaGiR79Do='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шнЛθаεΞθюπДОЗΗЦΤ():
    value = 749466
    text = __import__('base64').b64decode('dTJPWVU4NFRTM3FPWnNVZTBvME8=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦЭγΩВβΚСγоζΩН():
    value = 800014
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBC1RFlvzJITHQqT0WS4LCQA1UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠοБпЫБιНН():
    if len('') > 0:
        _dead_8611 = 292
        261
        333
    value = 508984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBqzPwEr1aQUIAb6wEHIIiQH0kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        693
        pass
    total = value + len(text)
    return total

def _ОУуЖΦГъςйΣ():
    value = 405500
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAXcVwQ0zptSIAGq5GezbB0c00c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜΧМΠпгΧПХЖ():
    value = 606636
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FD3SO0c36I8vHTiM2mS7Jyoq4jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΗкзэРщχςЯнΦЗΝД():
    value = 957016
    text = __import__('base64').b64decode('WFZwOTRTMWRqemIzaGVEQXEyOEo=').decode('utf-8')
    total = value + len(text)
    return total

def _нЖΗαТδзоЙЦяъψж():
    value = 464745
    if False and True:
        986
        990
    text = __import__('base64').b64decode('Zm53X19HcXh1cm83NzFPTE41dTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮБВыЮВΨЯκНΚ():
    value = 816913
    text = __import__('base64').b64decode('VXY5MGpoYWhfMk9CZ0g3OE1sVXQ=').decode('utf-8')
    if 49 * 92 < 0:
        _dead_5918 = 367
        pass
    total = value + len(text)
    if 70 * 93 < 0:
        pass
        _dead_5381 = 423
    return total

def _φПжъГЪΞωС():
    value = 881530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCTiSHku34cOEziNkEWWbQQ26FY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2701 = 889
    total = value + len(text)
    return total

def _бкцРЮΦнЛЭщπМПи():
    value = 51452
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3ixYEAIyaInP1mZ3FXFPSkN3G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГхДшГΔЗЬπτЙЮρσ():
    value = 647722
    text = __import__('base64').b64decode('eHhpcVA0WWV5M3NfQ3dKQjFfUWs=').decode('utf-8')
    total = value + len(text)
    return total

def _βΝΥШιΞЯχΑρжюМι():
    value = 126986
    text = __import__('base64').b64decode('UkJ3dnVxaWI1Q0FReU9pQUNZYWw=').decode('utf-8')
    total = value + len(text)
    return total

def _πΜΔωЙЮαρτΦБΠ():
    value = 249692
    if False and True:
        310
    text = __import__('base64').b64decode('b09RTmNiTmsxM21RUzFrZXhQTHI=').decode('utf-8')
    total = value + len(text)
    return total

def _йоеΒαΑγЧЗε():
    value = 721679
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgPnW1o62ZlXCFfz8VOEYj0p3Ts='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яσРйνηМюнюλХьφι():
    if 37 * 47 < 0:
        711
        753
        pass
    value = 853556
    text = __import__('base64').b64decode('SXhVOXp2ZzRWS3NfeFNubkY5X1A=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛлуΞрВБэХВЯфщζя():
    value = 878771
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LT7Nan0V6a0TICaH4kC7DXM5w2U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠТлμΒυΟβЭнЦД():
    value = 143592
    text = __import__('base64').b64decode('dGhTR1dPWXRIMnZ5dzZBbTRlUks=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕыΗюΒбмсΩΛШШШ():
    value = 179221
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXzbXlItxJpbEA62/HiUMHB71mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΒмлБмрчΕβΩ():
    value = 303224
    if 34 * 69 < 0:
        466
        _dead_9130 = 639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mwnca1RhzZIFagWl7gWhGSgG9zw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψνΟЦОлхЫгБΧБЪ():
    value = 707676
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DHnWQmQt+K8bLSG05lqWBgwW3n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟρжΧψЮΞΞпЦдВΙи():
    if 4 * 63 < 0:
        _dead_5806 = 504
        _dead_9780 = 950
    value = 729870
    if len('') > 0:
        _dead_9183 = 492
        492
        600
    text = __import__('base64').b64decode('Tl9IY25ZdVFtTUhIbEhpV2VMUXM=').decode('utf-8')
    total = value + len(text)
    if 82 * 57 < 0:
        _dead_1321 = 587
        648
    return total

def _рюРрιΧμρεαХь():
    value = 517880
    text = __import__('base64').b64decode('dnQzRFVCWTY1Wl8yRWh4d2FKNFE=').decode('utf-8')
    total = value + len(text)
    return total

def _чЧνηνШΙьп():
    value = 699352
    text = __import__('base64').b64decode('QndUSDVsbGpsbjhla25EUEVUaFE=').decode('utf-8')
    total = value + len(text)
    return total

def _νЛчθςЖюЯπ():
    value = 468249
    text = __import__('base64').b64decode('VTU3dnloc1NRSEFEcGNmeFBYZVU=').decode('utf-8')
    total = value + len(text)
    return total

def _цΚтλκтБЛκУэсΡ():
    value = 658039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCbUf0YfqP81GTrz6U+CHBMOyW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СрζνβτφхбοΡзие():
    value = 883683
    text = __import__('base64').b64decode('ejVlSGpjdHJQYWxBbFNWa2tROUc=').decode('utf-8')
    total = value + len(text)
    return total

def _цэψψμЧЯхьТХЦΦЖж():
    value = 538723
    text = __import__('base64').b64decode('ZXpISUlwWUpaR09UdXgyUnFaYU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬЖτзАЯыЖцρΤ():
    value = 16256
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('InfhN3sr1JhSIAmO8HCoYCp69mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΒцηсιωΝΛΓщΦэКъЪ():
    value = 515550
    if False and True:
        _dead_3798 = 302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CS3dPFYz258HaRWG2F6jDgs+ykg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯъΟМΧйξσЙщξбυΣ():
    value = 512421
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ly79QWkIzocLFRuFmky+Gz0B7WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 49 * 82 < 0:
        _dead_8033 = 941
        pass
    return total

def _δΦщВωФэΧθфΞаЙε():
    value = 73529
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ3FOVwoz/ssNSWHwFS+JTAX3kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ъωψαυψИδφΝΒРΨ():
    value = 840456
    if False and True:
        pass
        _dead_6433 = 580
        367
    text = __import__('base64').b64decode('SFJiNzc3RTFLUlNmTUQ4OFJhRnQ=').decode('utf-8')
    total = value + len(text)
    if 30 * 72 < 0:
        _dead_9690 = 379
        736
    return total

def _ВЖжкДмСγ():
    if 15 * 95 < 0:
        pass
    value = 639255
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiD1V2hg8rELOAqX8E6+ZTMssV8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙтПжШΛМΓнкИκχИψ():
    value = 756326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwHFZFIs6oxbaRq2wVKlMREN1mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δтЖηωΦΩυ():
    value = 78592
    text = __import__('base64').b64decode('YzZ1REh2anVhR0pxTzFRb0V6MEs=').decode('utf-8')
    total = value + len(text)
    return total

def _δΒЦхъЦχгΝГЯΧοЭς():
    value = 129695
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HB/Vd3se56cLM12mxESUEisn9V8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гγψГΒХΛЙξ():
    value = 255672
    text = __import__('base64').b64decode('QjJXZGx2eXQ0aEtMOWhYNm5WY0U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭΒюЙЫшФсζη():
    value = 270050
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ijb0RVRu9rlQERWOkHWjEDUptE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьрЦτЯЫвΩηΑ():
    value = 873280
    text = __import__('base64').b64decode('TFR0MFNXMm5pcTFneTdkNkNYUHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ВХФυΤЭЮδμйхщ():
    if False and True:
        pass
        _dead_2459 = 227
        915
    value = 228648
    text = __import__('base64').b64decode('YlpiY1A4VFZLVlJDMzI2QnFKR3A=').decode('utf-8')
    if 29 * 12 < 0:
        752
    total = value + len(text)
    return total

def _ΠсγОдΖΟσιςГлаχшю():
    value = 460548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiLUeVMR3aEVHS6z32miZjI36lY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яσмΤΡυΧРЕΣΧρς():
    value = 466071
    text = __import__('base64').b64decode('aThjM3R5S3o4ckNqQ2ZxUlpQR2Y=').decode('utf-8')
    total = value + len(text)
    if 62 * 9 < 0:
        _dead_6646 = 114
        _dead_6105 = 853
        _dead_7071 = 646
    return total

def _φЯуЙΖкθλуыНηη():
    value = 485897
    text = __import__('base64').b64decode('bG16QlNFcVBjS25FcTY0MlpCV0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗЬаеЭЙνн():
    if False and True:
        pass
        _dead_6901 = 454
        pass
    value = 736883
    text = __import__('base64').b64decode('d0ZHbm1fYVBYZEdQRjFQWFVHb0c=').decode('utf-8')
    if False and True:
        _dead_5073 = 191
    total = value + len(text)
    return total

def _шСΝзыШνцЫГеэΧшφц():
    value = 41968
    text = __import__('base64').b64decode('TmlzZHZ1MW5GRXRHUjJhQzFSdUk=').decode('utf-8')
    total = value + len(text)
    return total

def _фИчςлхΥδйιΚй():
    value = 993933
    text = __import__('base64').b64decode('STZvVzIxeW1ydXUyajJJNEZJV0k=').decode('utf-8')
    total = value + len(text)
    return total

def _ХρоΨΛАσφΙΔ():
    value = 412709
    text = __import__('base64').b64decode('djBQVk9CSlNjRDY0ZFVJdkFpWHI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠяΖΑεЯζРмълη():
    value = 750889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BH3DaAlq968rBRvw53CAbHAjtTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΘвППτРЬэαСΥзнκη():
    value = 750546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LjXdQ0Mpx5gOMgWnyleoBxoW3lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫШъеνΝξλнοΘΕΓ():
    value = 952237
    text = __import__('base64').b64decode('clVWT0ZtOVhsYkZPSElod0pDalo=').decode('utf-8')
    total = value + len(text)
    return total

def _νРМοЫζэШζΚΦоΥΛД():
    value = 527572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQL9WlJq9qZQIFf7712jAnQd1W8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уСЛтρΨАΧт():
    value = 234557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxvVQ3oqqa9bLyaJ5QPHHicptkk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΘпσЬЖАГΞдροЖрй():
    value = 272987
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('dFdMemhkMnBjaHhLY205bmFJQlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤκтΗΓκΝрЬгχоν():
    value = 392993
    text = __import__('base64').b64decode('clBXREQxcW5GR1Y2ZmRQR09oYWI=').decode('utf-8')
    total = value + len(text)
    return total

def _уθтΥΞεоξΛчθΠ():
    value = 486173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ai7mdkEL2IcOHwyi7wS+YQgb03o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1296 = 463
        pass
        909
    total = value + len(text)
    return total

def _ΧАяэξВбθΔГЕН():
    value = 430835
    if False and True:
        430
        pass
    text = __import__('base64').b64decode('SW5vb05KR2dHQUExa3d3ZW43X0k=').decode('utf-8')
    if 27 * 43 < 0:
        _dead_4230 = 916
    total = value + len(text)
    return total

def _ςтΞΛюЗΧиξςцοшΕМН():
    value = 919917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhfMYUZt+IAlPl/17VWGCwgM3GE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΕΦιцЫувмΤЗкЧ():
    if False and True:
        pass
        794
    value = 86210
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ng79PXwgrqZTFAW7ykWzGQAi7E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΙИΝШЕаΕхЧπЭΘь():
    value = 695627
    if False and True:
        _dead_9137 = 605
    text = __import__('base64').b64decode('bkZnUGhhanFzc2JmQzNraXQ0ZnY=').decode('utf-8')
    total = value + len(text)
    return total

def _явΝТгψМΔЬ():
    value = 565870
    text = __import__('base64').b64decode('U0JRWkR3cmZIdEE3M3puM3hGdXY=').decode('utf-8')
    if len('') > 0:
        759
        985
    total = value + len(text)
    return total

def _ΞКРβσΗБθΔхВЕЮЛΩ():
    value = 111502
    text = __import__('base64').b64decode('bVRhd1ZIUU1xakFYQkZEenZvS2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯсВУиπыЗ():
    value = 829701
    text = __import__('base64').b64decode('WTJ0Y3lNQjNmU1J3RENXaEE4eTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΥщΧЩоψНД():
    value = 348581
    if 99 * 41 < 0:
        401
        _dead_9449 = 310
        _dead_5251 = 565
    text = __import__('base64').b64decode('WEFoQnR3emNwOHprcE9kNDYxU0o=').decode('utf-8')
    if len('') > 0:
        _dead_1909 = 797
        384
        788
    total = value + len(text)
    return total

def _ΜκИзвρχι():
    value = 728211
    text = __import__('base64').b64decode('ZU5zZzdaR2JkN1ZsRDRpRUJhSDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ωωΑъЗжкΥσТΩμ():
    value = 539597
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBvWP0Ieq7xbFSv2xlLHbHEcyEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧсЗλдЩΗЪ():
    if False and True:
        pass
        pass
    value = 800766
    text = __import__('base64').b64decode('TDhQRlVzaHBwYkpReXRwUURSNWg=').decode('utf-8')
    if False and True:
        969
        pass
        _dead_1109 = 591
    total = value + len(text)
    return total

def _МΔЙΝЖытЭЛνзДψχΧ():
    if len('') > 0:
        _dead_3849 = 437
    value = 200292
    if False and True:
        pass
        603
        810
    text = __import__('base64').b64decode('bkVUMHJJOTl5WmZiT0JKM0J6c28=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮНЦЙбΡλκψς():
    if len('') > 0:
        _dead_9632 = 145
        _dead_8393 = 991
    value = 68864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTvgeXQLqPs5aQKWxmO/LBR912Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙБДЛЮЫΨкνЩтвТΣ():
    value = 372593
    if False and True:
        _dead_1631 = 280
    text = __import__('base64').b64decode('U0I0MEk2N0hyQ0dDQWUzbDJwTms=').decode('utf-8')
    if 88 * 47 < 0:
        243
        pass
        pass
    total = value + len(text)
    return total

def _χθβиЮЭΧРΝμо():
    value = 948763
    text = __import__('base64').b64decode('SVFsemdJVHhxMmV0b29iamE5T0o=').decode('utf-8')
    if 56 * 35 < 0:
        _dead_8793 = 728
        _dead_5329 = 112
    total = value + len(text)
    return total

def _ΡзαЬвκХяθГ():
    value = 756526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw28PUZuppshPFaUn0yfHioBs28='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 64 * 76 < 0:
        283
        pass
        pass
    total = value + len(text)
    if False and True:
        _dead_4917 = 927
        291
    return total

def _ЙλΚЭЯФИυРυЯς():
    value = 959920
    text = __import__('base64').b64decode('TDZmNTNyQ2oxSnY5dVFfMk9ydXI=').decode('utf-8')
    total = value + len(text)
    return total

def _κъαЭηРπЯЦ():
    if len('') > 0:
        695
        _dead_6798 = 780
    value = 568688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LX/nRlQ6zf45OwuX7EKEPhoh7k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СΥСмЭкΛΘаΘεьз():
    value = 880967
    text = __import__('base64').b64decode('SUhTMFhndFZxRkJDREVaYkdSTTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΔкоЪэЖШ():
    if False and True:
        389
        773
    value = 895809
    text = __import__('base64').b64decode('Qzl3bGpsSms4VkxZVlpQaG9NRXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΩψщЮΜПъХθиψ():
    value = 439209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IRvcZUMMyfAxMj3z7HPGMHwq9lE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сΥΜтΒΥιΥЮ():
    value = 559811
    if False and True:
        pass
        pass
        938
    text = __import__('base64').b64decode('UkNfNFdZV2pHOElRVlZfZGxJQm0=').decode('utf-8')
    total = value + len(text)
    if 7 * 52 < 0:
        488
        pass
        _dead_6083 = 441
    return total

def _сφмЫзΘЪΔΨςшэйпж():
    value = 933423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KTfHSkAI+4QvMiv7z3ioCy12130='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣрΜЧыЧоκ():
    value = 952552
    text = __import__('base64').b64decode('S2FDdXU5RWFrNEIyY3hOc2tYM0U=').decode('utf-8')
    total = value + len(text)
    return total

def _лкЮЕкΗВеа():
    value = 195272
    text = __import__('base64').b64decode('WGhiVGgwRjVXSkR2MEJnY0ZwR1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΑбΓΩΧΧЙХпЯστиα():
    value = 955063
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jy33Vno166cRCD22zgCEbSoA4k8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζйкνζЩωφМШйστ():
    value = 492705
    text = __import__('base64').b64decode('bkNIS2lwVGwxeGZ6RXhxV0xHS00=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕХΝσνζρЪΒ():
    value = 895371
    text = __import__('base64').b64decode('bENMcXoyOXB0a3U3WVM2cEdxaU8=').decode('utf-8')
    total = value + len(text)
    return total

def _δдδΟюΒζτдΩБШъмВц():
    value = 960200
    if 18 * 4 < 0:
        _dead_1239 = 693
        pass
        _dead_6176 = 298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyDuPmgR0atRbhmF0FGfGRN3wzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оγэςкоЭςΑΒХ():
    value = 506572
    if 33 * 51 < 0:
        _dead_1656 = 107
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LQDKekkQwfkgCR732WCbFhM40jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        162
    total = value + len(text)
    if 74 * 48 < 0:
        306
        pass
    return total

def _цΤβΑнЪΥлОηкДνяЯ():
    value = 161390
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESC0Nl886IwPPlr63Fy3JQkBvEo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 27 * 3 < 0:
        680
        _dead_4029 = 881
        pass
    total = value + len(text)
    return total

def _щμщИΧοΑΓРΡЦуХЭэП():
    value = 651208
    text = __import__('base64').b64decode('eGJDSmFTaU9zcVpGaENOaHdaekg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΖевЩГμы():
    value = 909909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iwz3S0E1/4QSCSGz6Qe4FQAd4GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _дЦЙщыФΗРνЪ():
    value = 255360
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fna0eGYs+Ic5PjyM+X+YFhoVxWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жхцкψΨЖвЮφТΙιЙКГ():
    value = 861177
    text = __import__('base64').b64decode('STRPcXhDNnBiTFk3Q0RxVlpPdjM=').decode('utf-8')
    total = value + len(text)
    return total

def _оγνшНъΧЛЗБΠδυ():
    value = 681913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez7sZUk2/64iKSes0HuKHQI95mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _узЫйЙΣВзΥФлσГ():
    value = 443351
    if len('') > 0:
        _dead_1723 = 41
    text = __import__('base64').b64decode('azFKakNHRkhFNFFLYkhpRG1FbnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖξμφдδиΞδσВБНς():
    value = 111337
    text = __import__('base64').b64decode('SmpGOVhrNHZUUEk5QlBucENLZXY=').decode('utf-8')
    total = value + len(text)
    return total

def _КооШκэηхЯ():
    if len('') > 0:
        pass
    value = 403431
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ki3SQwE01oMTF1iE7macCzQW7F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яΑβСΟΕοДδλΙβ():
    value = 844682
    text = __import__('base64').b64decode('ekQ4YkhEdm9udGNqelA3eVcwOXc=').decode('utf-8')
    if 78 * 18 < 0:
        921
        771
    total = value + len(text)
    if 60 * 100 < 0:
        198
    return total

def _ΗοθгαЕЖЩЗбΑСΝв():
    value = 618119
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BC2wYkUpz7smI1ymwEKnERp3/Vo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        349
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7462 = 743
    return total

def _ЭИΗсΘвжΩ():
    if False and True:
        pass
        pass
    value = 998365
    text = __import__('base64').b64decode('TV9mc3NCeW83V0xIUjRPUnBaU1Q=').decode('utf-8')
    if len('') > 0:
        _dead_6618 = 911
        pass
        pass
    total = value + len(text)
    return total

def _ЗЫθМЦιΦΚιΧсЭ():
    if 60 * 70 < 0:
        pass
    value = 700508
    text = __import__('base64').b64decode('aktjdFozRTVnSHZzU2I4TXBQUTE=').decode('utf-8')
    if len('') > 0:
        pass
        349
    total = value + len(text)
    return total

def _χΛθζΖЭЪзЮрυХΧΩ():
    value = 756246
    if 81 * 45 < 0:
        743
        pass
    text = __import__('base64').b64decode('aU1QdjRVbmtTX3B6WWpPc1pnZmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩξЖВεЭεΩκ():
    value = 804761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDvLR2g1p4wxaAeVn1unHgsIzDw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮΠУοοаΔЧИМцюΧ():
    value = 108266
    text = __import__('base64').b64decode('YW1OVFRfdGtRaEEwWmhYN0NTUjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛΛрСΠДωМгθыещαΦ():
    value = 669027
    text = __import__('base64').b64decode('em81VXR4aXJ1NldMRzNYVjdOWTg=').decode('utf-8')
    total = value + len(text)
    return total

def _юпхАЪΤθψБΕΞφЦχ():
    if False and True:
        _dead_2771 = 590
        830
        pass
    value = 388610
    text = __import__('base64').b64decode('dFdyR19fNFoxT3RKY3RJcUlrWmY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        985
        _dead_1854 = 214
        _dead_1730 = 671
    return total

def _χЧЬдκυβйφ():
    value = 120389
    text = __import__('base64').b64decode('aGRiN0JxRE5TQXVYUlo1V1Z5dkg=').decode('utf-8')
    if len('') > 0:
        572
    total = value + len(text)
    return total

def _чзлсδΩχяΝ():
    value = 468376
    text = __import__('base64').b64decode('blI1Sm0wSlRfMXBENGxxQ1kxV00=').decode('utf-8')
    if False and True:
        _dead_6635 = 272
        490
        _dead_4506 = 283
    total = value + len(text)
    return total

def _ЫοΧΕнюΜΥΦΠЫ():
    value = 17690
    text = __import__('base64').b64decode('cXdxM2JLMUxvQ0xSUHh0Q2lHcDk=').decode('utf-8')
    total = value + len(text)
    return total

def _цИΤΜэОБАψ():
    if 7 * 75 < 0:
        638
        pass
        338
    value = 865258
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnnANksx+KAzPR2Zx3uyYj0Yxnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςсψцщоЯζ():
    if len('') > 0:
        476
    value = 221020
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhWzXXcLp5wsLi2zngWAIzIh0nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1510 = 286
    total = value + len(text)
    return total

def _ЦΝΑχХΦαгАоΗмНΟρ():
    if False and True:
        612
        pass
    value = 686385
    text = __import__('base64').b64decode('ZlVDc1dXdEZINXZ5djA3QVpWd2Y=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _δоыОηπζТΧωТлп():
    value = 78390
    if len('') > 0:
        712
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fxz0ZXs915kAIxiI/lK8FiYuyWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕοХДЗгОβЧθ():
    value = 865738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHfReEksrP8wbh6h6W+4ZzMe1VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜЙΧЩντсРгιР():
    value = 498513
    text = __import__('base64').b64decode('Qmh6V0xPOEhjamM5bFNrZFRPR0M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩХутАχΖуЩТΕнрΙЧф():
    if len('') > 0:
        pass
        _dead_6821 = 75
        473
    value = 344810
    text = __import__('base64').b64decode('aWRUUktwcnRRSWRLWmdNTm1UMk0=').decode('utf-8')
    total = value + len(text)
    return total

def _ρσνПлαΜΛΧыψο():
    value = 118478
    text = __import__('base64').b64decode('Q09vbEhydDZxdjhvdzFJUlBhWFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ШгеΥΓυдЫрΙαΤо():
    value = 29588
    text = __import__('base64').b64decode('V0dONGdQRlBBckIwbTdpRnozWG4=').decode('utf-8')
    total = value + len(text)
    if False and True:
        924
        pass
    return total

def _ΧшУαεπηЛφжΧσТь():
    if False and True:
        pass
    value = 430602
    if len('') > 0:
        pass
        _dead_4573 = 355
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAzHNnUX76VTNgX78EO0ARw1wzY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВαΛΤуРЪΟΗъЗУΔ():
    value = 2723
    text = __import__('base64').b64decode('SDN5bjVLV0lYRVJYUnJ4VUk3aWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓΟΗΓΕщιяΑБЕЯк():
    value = 579644
    text = __import__('base64').b64decode('RFdIVGtqUHBoXzZhbnBzWHJkbmQ=').decode('utf-8')
    if False and True:
        pass
        _dead_4714 = 237
    total = value + len(text)
    if 100 * 25 < 0:
        pass
        17
        pass
    return total

def _ФΤжαΨαшΓЮтγΔЕюл():
    value = 629808
    text = __import__('base64').b64decode('b1dlb2ZsUVJNOXUwanNGeWV5UG8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2895 = 496
        pass
    return total

def _ЖжмзцΜОС():
    value = 799754
    if len('') > 0:
        _dead_2895 = 980
        pass
        _dead_6166 = 239
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRe2bFcb270WBV372Q6oFxU5yn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΕЮτΞΓΖщрФςцηΤФб():
    value = 209998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KT3md1Ij65ktLQWi3QCVNy0Q1EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        150
    total = value + len(text)
    return total

def _ЫθДЬмкξσвОκЪεС():
    value = 368111
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FzjjSEtp1vslIxmI4wa3BCYd92U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χνлфцμζωβЧЕЭψ():
    value = 797545
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQWyV0dtr6QmMSGR3Ge3Byg791E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λИζчαчпЩοΧщΥХЦ():
    value = 310528
    text = __import__('base64').b64decode('UDZMQ2J0S1NBeWdUS09lRmxZcWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡИσИщПдшсΑδЩυ():
    if len('') > 0:
        2
        _dead_2785 = 834
    value = 810630
    text = __import__('base64').b64decode('aU52NmQzWUFNZ0duQzR6ZXEwQ1g=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9910 = 65
    return total

def _ЦΔбΜУσце():
    value = 225303
    text = __import__('base64').b64decode('akV2d25LbmZZRlNOb1NRZDJXV1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЮΨΦвПЖΔΠКΟΞ():
    value = 940200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCzxQ0Uspq4bMwiO8n6fN3B26jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йСθΡЗμзς():
    value = 253422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDfJO3k6zLJQNhiSnmyzMRcXvT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФжяοнРВРеλЙмξ():
    value = 301933
    if 55 * 6 < 0:
        pass
    text = __import__('base64').b64decode('UnFGQ1ZVeVRMaDA2QmRxMEVsdkY=').decode('utf-8')
    total = value + len(text)
    return total

def _цιλщЗιРλΗ():
    value = 592606
    text = __import__('base64').b64decode('dThxcHNHT25YSnJUcjk5YnQ1WlQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2383 = 949
        pass
        pass
    return total

def _σΠΛξйσΤТ():
    if len('') > 0:
        pass
        pass
        _dead_8389 = 194
    value = 420129
    text = __import__('base64').b64decode('aldMUXNKUmVmWGs1WGlyZTNtTUU=').decode('utf-8')
    total = value + len(text)
    return total

def _φЯщμДβψΩЖΕЛтΨΠΩЖ():
    if False and True:
        pass
        700
        128
    value = 229991
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IzflXnUW36QKYxf62gS9GCgO6Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬтэХчЦАγэъеΠПылΩ():
    value = 2564
    text = __import__('base64').b64decode('TTJ0R1ZqSThuSV9OYjFsdElfM24=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΤβпЙΝяΜЪκРЯщιЛр():
    if False and True:
        pass
        352
        pass
    value = 482407
    text = __import__('base64').b64decode('ZUozOEQydzFCbEMwbDBfczJtU2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЫΝΡыαερΞпкВ():
    value = 860894
    text = __import__('base64').b64decode('b1BfUUhPeDdPSUlGSm9nQlNnNWI=').decode('utf-8')
    total = value + len(text)
    return total

def _цεТВωνьДΠНοПλгхИ():
    if False and True:
        655
        pass
        _dead_2009 = 855
    value = 392005
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MnbcNloO0IApbgqX2265Iy4u50g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мΩЭδУυВУ():
    value = 610799
    if len('') > 0:
        _dead_4798 = 414
        pass
    text = __import__('base64').b64decode('amhXSFdiVnpjeFNGcVBMcVJxdDc=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _еМчΩшΞΦωΛЗУЯЩβУй():
    value = 356913
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAe1RkIy6JIyIgiw+lq5BCI85Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λРЩωсΜНКΔЛл():
    if len('') > 0:
        pass
        153
    value = 781684
    text = __import__('base64').b64decode('a1hyaENQSndHUHdNbWZIVzBYbnY=').decode('utf-8')
    total = value + len(text)
    return total

def _зλБЬмΗμщтяΑ():
    value = 159620
    text = __import__('base64').b64decode('WGEzTGxmWExmWXNCU1lSVWE1aUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ТфФГЗХθπγΓз():
    value = 480312
    text = __import__('base64').b64decode('aldDYVJmc3d6T3FJUEhnalBFU3g=').decode('utf-8')
    total = value + len(text)
    return total

def _μΗννΕБУεη():
    value = 602070
    if len('') > 0:
        927
        _dead_3482 = 18
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MzrWOQcqzbpTFTi04g+xZg8ZyTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        498
        pass
    return total

def _ΝаЦаСиъυ():
    value = 439173
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3rrfFgq6I8ZLzmzzFi/IRws/Wk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_5749 = 401
        pass
    return total

def _ξνЭΓψДыДбвΠυЗд():
    value = 779497
    if False and True:
        905
        pass
        _dead_9931 = 287
    text = __import__('base64').b64decode('aUVTd0paMHRYaHNSNmZZNWJ1N0k=').decode('utf-8')
    if False and True:
        _dead_7685 = 412
        _dead_2833 = 712
    total = value + len(text)
    return total

def _σΡσφιРθз():
    value = 334098
    text = __import__('base64').b64decode('dk5BaGlhQkNybXJPMUs1VXNGU3E=').decode('utf-8')
    total = value + len(text)
    return total

def _ШφεΩИтщцрЬΣЬ():
    value = 17102
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxDiZHBszKEWMzv233y/ICkn7nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξчιДНθаЦГσгЦΔМΠж():
    value = 520403
    text = __import__('base64').b64decode('bHlXd2dDeUhGUE5SREhZV0t0VXE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5053 = 230
    return total

def _ГВьЪзЮьсβщСсаπя():
    if False and True:
        pass
    value = 471543
    if 24 * 84 < 0:
        pass
        _dead_6390 = 26
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAXqaX8yrKclMgGlnH6oEys40Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛжЗагΧΘηκΟп():
    if len('') > 0:
        pass
        pass
    value = 264688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgjUbVID+qVXYw2PxFLBGQkG3Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 34 * 26 < 0:
        pass
    total = value + len(text)
    return total

def _ΗшχЗВαΞωΡХΘζκΓРθ():
    value = 34410
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgTIVAY99qcuAgGKzkaKLR8Mxnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘФчФнΩьεΥсΩβ():
    value = 906705
    text = __import__('base64').b64decode('cHhYQ29yaGFTMWJKRU9ZdUR6c3I=').decode('utf-8')
    total = value + len(text)
    return total

def _оеТωЯоХцΖХцМ():
    value = 419741
    if False and True:
        pass
        954
        _dead_5411 = 572
    text = __import__('base64').b64decode('c0NhZ2NEYTlmUFdZQW9ncmNieHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΩюшπΡнэЩХЕгΨθ():
    value = 437301
    if False and True:
        _dead_8207 = 912
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KzXuW0Ae1PpXb1+ZwwfDATAd73w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 12 * 62 < 0:
        453
        _dead_8182 = 943
    total = value + len(text)
    return total

def _χцсГЙΡσδ():
    if 14 * 50 < 0:
        pass
    value = 775008
    text = __import__('base64').b64decode('aDVGN3RnaWlUUjA3dmY0WEp2elg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙШпσξщИψΤрΟ():
    if len('') > 0:
        _dead_3712 = 808
        _dead_9214 = 40
    value = 473662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBXKY2Rr9bhQOReqm2m2HSo/w3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤЩΗеЫΗиЮФрψ():
    if False and True:
        _dead_2324 = 160
        pass
        pass
    value = 162816
    if False and True:
        _dead_4317 = 10
        pass
    text = __import__('base64').b64decode('WXlTZ3lpc1pGVG5XSDlZY3hROUk=').decode('utf-8')
    total = value + len(text)
    return total

def _УКуςкдΤτУйΧкй():
    if len('') > 0:
        8
        pass
    value = 552142
    text = __import__('base64').b64decode('c2VDbDdQRDNGb2p5dlFibDBLNkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨκΦЙФνεтψИσБλиБν():
    if False and True:
        _dead_3196 = 353
    value = 96135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDbHS2UMroUIYwSw/FKYPnILwT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВΖчγШъΡМче():
    value = 249739
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSr0RV5q+/tTDV2HwQOcBCQ3zlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9634 = 203
        467
    total = value + len(text)
    return total

def _ФАЗКВΧΕτЪгтΠ():
    value = 248691
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCLeT2Ior6ouLSKCmgWKGy8+4m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БэΥшΕΨΓВОаΠΡμод():
    value = 227321
    text = __import__('base64').b64decode('RlBraXRDUjE0YWJjV21lcV9zX1U=').decode('utf-8')
    total = value + len(text)
    return total

def _αΠИηмцАщ():
    value = 395728
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgTLanoL1v0ZYiuy21+hIzE7y3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρУγЭξХъβЖηЗНЖο():
    value = 607923
    text = __import__('base64').b64decode('Y2FHWGVyTjUxeGVrOFlQYVlZMlI=').decode('utf-8')
    total = value + len(text)
    if 33 * 23 < 0:
        pass
    return total

def _γΙтΥшОуючτОкт():
    value = 287384
    text = __import__('base64').b64decode('dTgyZ0Zpb2FydGxibDJyQmpsMzM=').decode('utf-8')
    total = value + len(text)
    return total

def _сфХДηхкΦгЪУΗκ():
    value = 153768
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISXdY0gb2fsMMyG28gGJJQ4NxWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жκΦаκκБтΒο():
    value = 338036
    text = __import__('base64').b64decode('ZEw5cG5lX3Y0bzk4VkxBeXRxSEU=').decode('utf-8')
    total = value + len(text)
    return total

def _ъчαиДкОМαКЫΠαπ():
    if False and True:
        720
    value = 814217
    text = __import__('base64').b64decode('R0pkU0Z2SjhWR01QdlJuQ3E4dnE=').decode('utf-8')
    total = value + len(text)
    return total

def _вΠкЗαЯпНУЖУ():
    value = 930621
    text = __import__('base64').b64decode('RVI3WndRRlFlRGR4UnVRd0JqM04=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒτЗψсЮэхθГ():
    value = 650982
    text = __import__('base64').b64decode('RFRMVFRlSTZGU1lscUdxdDU2YjQ=').decode('utf-8')
    if len('') > 0:
        439
    total = value + len(text)
    if len('') > 0:
        559
    return total

def _кчЦςΓМхΔΡцΞ():
    value = 643845
    text = __import__('base64').b64decode('ZmlhWEFUZ0ZTWWF0OHhtbkQ5VHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ФуΟЪψШИрλζмΘ():
    value = 549042
    if len('') > 0:
        _dead_3189 = 555
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bj/+V3w/zoMKaRqc5HO6BwcB/Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ιеефσжМηΠяψΒΥу():
    value = 362083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AivbRVMd0o4pEhX74nSKIzU40Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _οОЪЦбЬнЬΛИ():
    value = 85269
    text = __import__('base64').b64decode('d0lVVzdVTjVicXo5Smc1NUJIZXI=').decode('utf-8')
    if len('') > 0:
        _dead_9917 = 584
    total = value + len(text)
    return total

def _ρЙыθнЪкНσчρξιΒΡ():
    value = 217912
    text = __import__('base64').b64decode('cUpoX1FybnZMbVlXcmpJeWJCUGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥщιςΦьτΘ():
    value = 19703
    text = __import__('base64').b64decode('SEZKR3JzR1dQbzN6bnVoXzZZWTQ=').decode('utf-8')
    total = value + len(text)
    if 13 * 17 < 0:
        _dead_6917 = 978
    return total

def _τΙΙδыЪЗЭΦдΟλкΝ():
    value = 843169
    if 90 * 1 < 0:
        187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTvUYkAdp5stAFiU926DESAh8zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩηАιςЯпΣΠу():
    value = 942398
    text = __import__('base64').b64decode('dW1lT3BoSUtZYmFhcndFN2xaWjM=').decode('utf-8')
    total = value + len(text)
    return total

def _ψμΤЫθΤςλΞ():
    if len('') > 0:
        _dead_6848 = 354
    value = 926334
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgnwQn4U2aBWPiSM5n++DCkk6Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 75 * 16 < 0:
        162
    total = value + len(text)
    return total

def _зиЦрτυиνХеθωΑ():
    value = 204210
    text = __import__('base64').b64decode('V3FONnFmenA5aDBmUjdpSzBpbGw=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΓδЙψΜξЪюψΧоβΨ():
    value = 51234
    text = __import__('base64').b64decode('SUw1NE1NNHp5anE5NktwMUl2SU0=').decode('utf-8')
    if len('') > 0:
        941
        pass
    total = value + len(text)
    if False and True:
        138
    return total

def _ΘΖзМΤπЫЩхМЙъ():
    value = 591319
    text = __import__('base64').b64decode('cElEYzg4ZkpxRm1SSTlXcWtZbVc=').decode('utf-8')
    total = value + len(text)
    return total

def _цЦηКЗΑΜΛъ():
    value = 989216
    text = __import__('base64').b64decode('SFRlNFZEbDZrSHRwQ0hRVkd0Vmc=').decode('utf-8')
    total = value + len(text)
    return total

def _δЧжЙηχМΝЦΤюлΒγ():
    value = 755259
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3rQY0kL7/AiYjX6kFufDDF9xz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дλοΧΟбЕЗсυыΝд():
    value = 903103
    text = __import__('base64').b64decode('Vnc1QWN5anJlU0NYaF9QbXdCajE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙетσшβжΛВЯбнΘηΨ():
    value = 32322
    if len('') > 0:
        _dead_9806 = 583
        577
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTaxZGcc8Z8VIA2z7weaPncpsWo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψτъпоЙЖоφ():
    value = 743181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxDKPVkA6JgWECicwHG5Cy4O0Xc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 3 * 98 < 0:
        347
    return total

def _ΖνΛЬУЪОтρКωЧ():
    if False and True:
        733
        184
    value = 282718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyzrWm4y+p9XDySvw2SqIHMX7UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        888
        pass
    return total

def _ΑчφΑгАЕΖДΘлюС():
    if False and True:
        817
        286
    value = 93033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FTr1WVg72qpRCAWLkE+XDRIawmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        738
        pass
    total = value + len(text)
    return total

def _ЗοΣΗЩωНйШ():
    value = 441703
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQTOPXAzrvsLMTW75XifAg4K73o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝπОЖξΦΙΔЯυждб():
    value = 20973
    if 24 * 59 < 0:
        208
        895
    text = __import__('base64').b64decode('enJJVWZGS2VMZVNQcHU4bmdoVEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ТδРПΨаΗаΣХυυъъ():
    if 85 * 86 < 0:
        pass
    value = 197734
    text = __import__('base64').b64decode('VDBUSFFYQ0w0RjNBcTA4cWk1Uzk=').decode('utf-8')
    total = value + len(text)
    return total

def _жΩφУрΞьжππχ():
    value = 448952
    text = __import__('base64').b64decode('aWV3N3R2RW5YRUtXRzZaYjYzbjk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥНΒоячςхΧΛиВдЮ():
    value = 543697
    text = __import__('base64').b64decode('SEN0UVRiWG95bkZibHpBRWh3Mmw=').decode('utf-8')
    total = value + len(text)
    return total

def _ТЩыΚЗвЦсΝЬЯ():
    value = 196526
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH/KfEML1KdXFSebyQWvOic/4m8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        256
    return total

def _ΑяΛфβκшδΨязλмθчμ():
    value = 466321
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('WDdTMDQ4ZzNQbElFWXpVcDAzUTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘюфΠлАιΘъл():
    value = 787452
    text = __import__('base64').b64decode('SUxXMW4xOFlLaWJKSk9iYWtlT2s=').decode('utf-8')
    total = value + len(text)
    if 86 * 24 < 0:
        pass
        889
    return total

def _ТφЬςяζИЩю():
    value = 302058
    text = __import__('base64').b64decode('dTY0eElxYXVPeHRXSHJsaTJkMFY=').decode('utf-8')
    total = value + len(text)
    return total

def _иПΝΡεпΚнΣчэЩБο():
    if False and True:
        pass
        pass
        65
    value = 172639
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQnANgIe66o6PyiR0n61bXV510E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_7166 = 650
        814
    total = value + len(text)
    return total

def _ВЭσΗГωсΟЬ():
    if len('') > 0:
        756
    value = 152168
    text = __import__('base64').b64decode('Y2pyZnBudFUwRk5BWlZCN2R1VzA=').decode('utf-8')
    total = value + len(text)
    if 94 * 83 < 0:
        pass
        _dead_6609 = 870
    return total

def _АЙШнΛююχνбЪКνΦΞо():
    value = 334596
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FinhO34f1/wVbRqixE6jJiN7sXk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 80 * 51 < 0:
        pass
    return total

def _ΡΑνдΖчνсвξΘαз():
    value = 824667
    text = __import__('base64').b64decode('b1hEeVppQkxtS3JpUmNwRFU1T2w=').decode('utf-8')
    total = value + len(text)
    return total

def _ФФΜяΥЬВх():
    value = 505152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MH3DfGgQ8qxTNTj26nqoLDA4zTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωφЯРчЪβеωθαΨΚΝф():
    value = 967420
    text = __import__('base64').b64decode('T0hPVWRfaEc2MjJvTzVrZDllYVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ζзЕднεΖРξΤΔзγСм():
    if len('') > 0:
        pass
        _dead_7780 = 831
        pass
    value = 512173
    if len('') > 0:
        _dead_6259 = 711
        _dead_4585 = 179
        _dead_5116 = 842
    text = __import__('base64').b64decode('ZGhfQWIwdlZXdWdReHphcF9pRDk=').decode('utf-8')
    if False and True:
        746
        557
    total = value + len(text)
    return total

def _НсδωаΦяЩЗμΑЛКч():
    value = 640539
    text = __import__('base64').b64decode('Y0xSRjZNMllBUU1GTm5fUmhINVU=').decode('utf-8')
    if 10 * 73 < 0:
        _dead_5719 = 326
        210
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if 89 * 44 < 0:
        _dead_6366 = 722
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 70 * 85 >= 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()