#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _аЖяСуψуΧАъСΑΖΑ():
    value = 360343
    text = __import__('base64').b64decode('SXNVUERLWEVHdWVqNkhVajZSRW0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒАЪΤГЧгξνТ():
    value = 31864
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX61Q2s+969XCB2LyW6eExcE6X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фЫшΓЧЙПДγ():
    value = 836322
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCrGP2Qgp4osCTe63GnBDiY4t30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УΑхωΕэθΧζУδχЫщ():
    value = 680636
    if 2 * 66 < 0:
        _dead_5066 = 368
        779
        pass
    text = __import__('base64').b64decode('UjZmRF9McjJnY0pUSTZYVVBHTjI=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _рЩКузУцФσрЮрΧΓ():
    value = 92982
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgXoagBry6U6PSSNn3mYJhY+0EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПτьцЗΒфΥΑΡЮкЖ():
    if 25 * 99 < 0:
        _dead_7798 = 135
        223
        818
    value = 282549
    if False and True:
        pass
        604
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Enj8QWAN5JsNbFqv3XKhAAF7t1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_6479 = 398
        580
    return total

def _δлеИыХхцΝщΥк():
    value = 861996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AX/qZEscroYFLzu63F69HSQZsTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦгΦЖωΒЩεтУыШΓΦ():
    if False and True:
        pass
        _dead_6739 = 456
        _dead_5336 = 975
    value = 236852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSHQRkgx2KURFl6cwGPGHwB9yVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 10 * 91 < 0:
        445
        920
        pass
    total = value + len(text)
    if 21 * 93 < 0:
        _dead_8445 = 944
        pass
        pass
    return total

def _чфφΤΝЧДИΟε():
    value = 600666
    if 15 * 92 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MHbyS39q64FXIiyW3gG7GhN67Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЬдδоРщΕЫА():
    if False and True:
        pass
        pass
    value = 657912
    text = __import__('base64').b64decode('VEk3WlNZMHd2U1RxWVJHaGlqXzA=').decode('utf-8')
    total = value + len(text)
    if 85 * 41 < 0:
        pass
    return total

def _εНдΓМΕρссДΧКΑλχр():
    value = 335654
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('C3/nV1YX879UCASH3nqHDRYM5X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БγвΕΘШφΒркΘз():
    if False and True:
        _dead_9263 = 794
        pass
    value = 231600
    if False and True:
        _dead_5125 = 689
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTzAX34g670tFCD1x0DAEA8ryWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аΞпΑВρЪνЛЮ():
    if False and True:
        pass
        _dead_6384 = 533
    value = 196172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JibhaFUjy45VH1ec+GKYFj8G00k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΧΜЫγΨФςΚΟΚκΔφΛмВ():
    value = 459682
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxntVlM/8ZxSbzWx716xEnEL6X4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠτвкЭλиΔΒ():
    value = 934270
    text = __import__('base64').b64decode('ejZlcGd6cWluMmlOYUJSNnIxdE0=').decode('utf-8')
    total = value + len(text)
    return total

def _жХжλνΚжо():
    if 16 * 58 < 0:
        _dead_6620 = 323
        pass
        469
    value = 139987
    text = __import__('base64').b64decode('Rlg0M25lcmZWam82R0ZFSnZjR2g=').decode('utf-8')
    total = value + len(text)
    if 72 * 61 < 0:
        _dead_4577 = 973
        _dead_2716 = 169
    return total

def _пыЕΗЭЭГΥеΤΑы():
    value = 844491
    if len('') > 0:
        pass
        _dead_4383 = 817
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kh/TWmNh16c8ER/y0WOmBQsn03w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρАεйХУςдУйеΗΒ():
    if 78 * 53 < 0:
        _dead_1577 = 619
        454
    value = 435917
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PA7AdnwO34ULNQrx61C8bHUD9UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪΗнεуПзцκиАΤ():
    value = 318415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBD0SFls5/shPTir7ULFMgge4Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ωйЦРМσмΓгЩЬц():
    if False and True:
        _dead_1463 = 227
    value = 114680
    if 74 * 74 < 0:
        pass
        pass
        108
    text = __import__('base64').b64decode('dkxzYlpCUWhBYTZiVW40MUNtVEE=').decode('utf-8')
    if False and True:
        _dead_1824 = 363
        _dead_1311 = 462
        pass
    total = value + len(text)
    return total

def _хγщКхыΒнРсωολπωф():
    value = 428654
    text = __import__('base64').b64decode('cXY4azFJcWxlUEhvZnFFTDdaUFQ=').decode('utf-8')
    if len('') > 0:
        376
    total = value + len(text)
    if False and True:
        129
    return total

def _бЪЩЗμСΝΖСГеΤМЮΦ():
    value = 387852
    text = __import__('base64').b64decode('R25nek55YzVRRG5qellocWZhcnM=').decode('utf-8')
    total = value + len(text)
    return total

def _зηГДщαМдУсΨμ():
    value = 170208
    text = __import__('base64').b64decode('bmxBX1BnMUV6MjZrZlZQMDI5VEo=').decode('utf-8')
    total = value + len(text)
    return total

def _рΖбΝНСЖοΧ():
    if False and True:
        _dead_4302 = 169
        pass
    value = 256707
    if False and True:
        561
        486
        pass
    text = __import__('base64').b64decode('R2RIX19Yc01TbGEyWkVxYnJDMlM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6025 = 123
        378
    return total

def _гζσяСΗβУЪЙΝФэЬε():
    value = 986111
    text = __import__('base64').b64decode('WXM3bFl3aUtkRk5rTWY2MkhLT1U=').decode('utf-8')
    total = value + len(text)
    return total

def _УΙфБЭχиКШυ():
    value = 125111
    text = __import__('base64').b64decode('aWtSWWJFTDhPeF9tSklkcDVKNnQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ιСкящΓИЭρдΡΑφ():
    value = 907150
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nhf9bFkY7qkIIj2B3lClHi4DvX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςоЧγГйфΠΘλ():
    value = 101027
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzzrQgMJqL1XDA2r4w+iEnR+3Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аюκΝЗΒньς():
    value = 365122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IS3cVgkQyKcBBR6Z/w6+BgQ372M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 20 < 0:
        _dead_9625 = 814
    total = value + len(text)
    return total

def _ЦΤБЙχЮЙКц():
    if 12 * 7 < 0:
        _dead_1581 = 39
        318
        pass
    value = 30323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyazOVgO3YMmaQ6unWfAGRIMsUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        248
    total = value + len(text)
    return total

def _ΕРΠοςЕΗΚν():
    if False and True:
        pass
    value = 884424
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwHPZF9p/6M8Mjekn2a+MT8o/Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 8 * 69 < 0:
        _dead_3981 = 661
    return total

def _ΨχΖЦщшΝСЛ():
    value = 268304
    if 3 * 10 < 0:
        462
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwzsfFUb+YMXDV2rmlmjExwL9EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 86 * 30 < 0:
        _dead_7238 = 163
    return total

def _ζйЭъшεΩРΖЪАΧК():
    value = 124552
    text = __import__('base64').b64decode('czk1WEpwWmlwMHVBNU82MHFFZmQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъзχΣΖнбйуЛα():
    if len('') > 0:
        _dead_6320 = 150
    value = 60326
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AzrePEc9yfAkPCWNkE6vN3w6z0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _чМΟψφОΗταΓΨ():
    if len('') > 0:
        pass
        pass
    value = 82187
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCDwPGcUrLw8GRmu4F6jYwMdxkg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 79 * 51 < 0:
        _dead_8598 = 117
        pass
    total = value + len(text)
    return total

def _ψΘТΒхΒаτρΧφ():
    value = 924212
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCvLZQAYyoZbMAeH0WK0HQgY2zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κσНомδГаТΞш():
    if False and True:
        _dead_8489 = 514
    value = 938501
    if 90 * 42 < 0:
        245
        225
        _dead_5947 = 558
    text = __import__('base64').b64decode('VkJKN0RQWEFPSnBzSU1VQTVKQnE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪГπыГооМΝχоЩυсНΚ():
    value = 281172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CSzoPHwP0q0aaFaPmn2RGzUl4nk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_5822 = 182
    total = value + len(text)
    return total

def _ΨЫЕюιθΑШМеыюВ():
    if False and True:
        pass
        158
    value = 439838
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('aTRLaGVMZEVBQnNjVU9MMDhLSEs=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5569 = 429
        392
        482
    return total

def _ТБοрГΜцЗиΠ():
    value = 665384
    if False and True:
        pass
        _dead_3981 = 895
        459
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiveQ244zr4LIxic7lq9PiAQ10Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 19 * 4 < 0:
        _dead_5788 = 396
    total = value + len(text)
    return total

def _ΔсΗэъВΝλΦψнЪ():
    value = 117226
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD+1PAYY9a4KNQemm26IHAQL6D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8531 = 61
        pass
    total = value + len(text)
    return total

def _βгаψσνыδСΠΒΓνГ():
    value = 361585
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgP8PUE/zbsUPFnw7m+KHggq8Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βЙЖτξыЖлГκБοк():
    value = 634072
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxjrVgEY7KQHBRiU6lGRIH0Z/X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щЭΑЩΤτςмδХИ():
    value = 660543
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCz3dAIh2v4kKAqM/GfIYX1443c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_6682 = 343
        _dead_6514 = 592
    total = value + len(text)
    if 75 * 80 < 0:
        207
        _dead_1384 = 367
    return total

def _РΕΠаАМНΦΜФКΖЫοα():
    if False and True:
        pass
        982
    value = 562813
    text = __import__('base64').b64decode('RkRtcjdnR0FWU0FtR2diZjZpUW4=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΤΘЬзΜΔЩβξовΗщξ():
    value = 730910
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('M3fiSQQe9qYADCGQ3VGxNwgetkE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СнОτдΙΩлυ():
    value = 793764
    text = __import__('base64').b64decode('bDl0dWtRWlBldHpCN24zRkt6eEo=').decode('utf-8')
    total = value + len(text)
    return total

def _хζΗЯвИЩΟур():
    value = 960001
    text = __import__('base64').b64decode('QmJxUEhUNnFDTEFNbDBZbVNJenc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_9457 = 348
        574
    return total

def _ЫρζБиИгΘЭвГОЕνβь():
    value = 161774
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAHTOwM6y5pQAAi5/UaEFzQd1Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρшВψзпΤХΩ():
    value = 465418
    text = __import__('base64').b64decode('Rlhxc1VlcGpTeEFYRXlsUkNfX2U=').decode('utf-8')
    total = value + len(text)
    if 69 * 27 < 0:
        pass
        _dead_8362 = 252
        _dead_8272 = 888
    return total

def _ЙШνηмΗуκ():
    value = 371272
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L3zvNm429oUzLjyFy3KJAXMiw1Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мшΤлεΒψμфкХΝ():
    value = 74280
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nh/qbF4d1KBTPQus+EeRYCAjxk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _пеъοδΗρН():
    value = 448055
    text = __import__('base64').b64decode('cjZYbW1Kd09DV2RtdXNSbXVSdlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΛвνдΔΓΔмυγВьξе():
    value = 634707
    text = __import__('base64').b64decode('Y2paVTZESlR3a3Ntdk1nOG11M3M=').decode('utf-8')
    total = value + len(text)
    return total

def _οшбгГщζшΤГЬРШ():
    if len('') > 0:
        pass
        330
        _dead_8536 = 312
    value = 947025
    if 21 * 24 < 0:
        pass
        713
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dn3hd1lg5vEmNRv2w3+VGy966W0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _τΒΔηΤββРоΜы():
    value = 805181
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjnRWWYL1L8OIyGZxFuCDRF4xlY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыжΤΜФВхех():
    value = 298440
    if 88 * 28 < 0:
        356
        _dead_2397 = 133
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXzoVnYTyIwmb1aVxWnEHyg/220='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 43 * 3 < 0:
        531
    total = value + len(text)
    if len('') > 0:
        _dead_8776 = 922
        851
    return total

def _ΧιΙмΠНΦΜΘжМΙ():
    value = 433504
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhzmO0Epyo8OCFuk73uTLRI5vUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 75 * 57 < 0:
        _dead_9172 = 385
        pass
    total = value + len(text)
    return total

def _ЧπБЧξъηрВυβψГγ():
    value = 239058
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mie1REltpq5SMB6JkG/IBhcp1Hk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДюνψκйяΒиγа():
    value = 716840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DBnhWHIpq5coDQau8HynJC8o90M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гωбНΘεэθΕТТΦиаН():
    value = 238795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCzVeVgd0a43Pw6bkWGhLAA3y2I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡτШэΘШΓιν():
    value = 285384
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dxu8fWgM7K4vDCS14EOJBxYIykA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дъΟςЖηЫдьЛΩуυμТЮ():
    value = 619683
    text = __import__('base64').b64decode('bzFqUmd0YXAxVV8yUUZFR2w4TGk=').decode('utf-8')
    total = value + len(text)
    return total

def _γыΡωΦГΡшМοΗСж():
    value = 325522
    text = __import__('base64').b64decode('QmsxNHlldmFzcUh3Q0RtN056SWg=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕФчТΓΓγШΥвλп():
    value = 93298
    text = __import__('base64').b64decode('RXJGTzg4d0lZQnlqVmx3YVdaWHQ=').decode('utf-8')
    total = value + len(text)
    return total

def _уΗδΑоηΞЕΒχφкΓЩмш():
    value = 550407
    if len('') > 0:
        _dead_7785 = 837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PwzbZgEA8o0MbyuKxQ7APDE48zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝэБγυЪСΓОπплиНмЖ():
    if False and True:
        320
        pass
    value = 96185
    text = __import__('base64').b64decode('amRoNzRORDBZaG5sWjRucUJHd24=').decode('utf-8')
    total = value + len(text)
    return total

def _ПεяΡнμАтЯ():
    value = 232362
    text = __import__('base64').b64decode('dTVlelhBMUJqaFVnT01rNzdnVlo=').decode('utf-8')
    total = value + len(text)
    return total

def _ШδιчЙпСΔЪЭΛСΠ():
    value = 302355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiHMZQQTrbEVPQj6nX+TPiEbw2o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖАΨжПЫσъц():
    value = 427243
    text = __import__('base64').b64decode('Qkp6SFZoMVZwVmJzajByM2tMZkg=').decode('utf-8')
    total = value + len(text)
    return total

def _ψдУгХθЭπκвΤΝγΘрХ():
    if False and True:
        641
        _dead_8422 = 896
    value = 303784
    text = __import__('base64').b64decode('ZUdxUGNCNGNKV0VSTlMwSGlkWWs=').decode('utf-8')
    if 26 * 55 < 0:
        _dead_8135 = 858
        _dead_7936 = 991
        pass
    total = value + len(text)
    if False and True:
        pass
        57
    return total

def _ΜνЩНΖЦςЦ():
    value = 427574
    text = __import__('base64').b64decode('ZlU3NXE2VmVUSGJCd0gwNlFORTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑызУβТэθΩФк():
    value = 34162
    text = __import__('base64').b64decode('bkNhRlFvZ0xuR1ZGU2hOUzFQVDE=').decode('utf-8')
    total = value + len(text)
    return total

def _ьСΨКπырЭЖ():
    value = 886535
    text = __import__('base64').b64decode('aHd4UU9DRWRETjVzbGltR1BTRXE=').decode('utf-8')
    total = value + len(text)
    return total

def _ШχфευмαΜзΞΒ():
    value = 675149
    text = __import__('base64').b64decode('aHMzSVAwalN0d2R0aE1PZ01XbTc=').decode('utf-8')
    if len('') > 0:
        _dead_6108 = 947
        652
        _dead_3318 = 576
    total = value + len(text)
    return total

def _ЙΡэмоαΝЕтлγЭ():
    value = 625765
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyXcfWBhx6tWHwiG6geaAiYN3mc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        97
    total = value + len(text)
    return total

def _ЛΙΦуЦΗΤКьц():
    value = 156706
    text = __import__('base64').b64decode('QVhpeTZkSGlGa204OU5uekJKcl8=').decode('utf-8')
    if 31 * 54 < 0:
        pass
        _dead_4059 = 191
        pass
    total = value + len(text)
    if False and True:
        _dead_7460 = 761
    return total

def _ГаΖЬЯЖЛΙмоТβ():
    value = 878049
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fh3jXmEPxI0ZNAL12UyxLHYk7Vg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бΒшГаРΦμнлЗδу():
    value = 153772
    text = __import__('base64').b64decode('UDBzUVdCNWNZdGpyd2dPbUp6eE0=').decode('utf-8')
    total = value + len(text)
    return total

def _ГдμицбνΡΔгη():
    value = 686992
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHfdYH5r17orb1mc8gO4MBA59EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 6 * 77 < 0:
        929
        684
    total = value + len(text)
    return total

def _ωДΞнлТалкУΘвмтφ():
    value = 990263
    text = __import__('base64').b64decode('WkZYRVJTVmpacGY3RUxSZGVHRUE=').decode('utf-8')
    if len('') > 0:
        _dead_5770 = 329
        _dead_5187 = 938
    total = value + len(text)
    return total

def _ΜьчзΒΒЗьΤΖфУЧы():
    value = 661983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MBbjflIR06VWCQqsnV+fGjR9/j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΕпЯβцЗояШδМйΧΩж():
    if 94 * 2 < 0:
        pass
        pass
    value = 190050
    if 8 * 11 < 0:
        _dead_2313 = 150
        157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAnGSGQR5IAmPV+S7HTGZSsJ0kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΙΔΛтБЮеЩчШхх():
    if False and True:
        916
        pass
    value = 848265
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDe2Pn1qqKFaODiTz325BwYGx0M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 21 * 1 < 0:
        pass
        pass
        pass
    return total

def _уΓОмвησπΩЩΝшХ():
    if False and True:
        _dead_6370 = 614
        _dead_7695 = 58
        _dead_5585 = 532
    value = 700108
    if 65 * 29 < 0:
        _dead_4408 = 166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACS9OkNt06UgOCmc2QejPAMX3Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΞННьΜОМ():
    value = 907147
    text = __import__('base64').b64decode('S3MyWDhOVkN5bGxwb1lWeFNxVzA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЭйщεΠьъκгУЦЪБ():
    value = 867315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCzSOQdu/btaIAKK+nSaGSkH02o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εЮλуςМπЗТрΑ():
    value = 992670
    if 73 * 83 < 0:
        pass
        _dead_1363 = 39
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AwrmQmkt9qsXMimS5GCnZjINyzw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖЧΣюΖшоьлнДЫ():
    value = 726889
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nn61b0YP+o8Ubz370gSUYSAY62w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗψьМβωмΕРΜбΟиμα():
    if False and True:
        pass
    value = 820316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAD1VgAByo0QIACz416/ByMG9mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_6167 = 49
        pass
        580
    return total

def _ΟтνхΣГγщρБ():
    value = 276020
    if 6 * 11 < 0:
        pass
        _dead_9502 = 852
        885
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhrSQAI7qrsLIzWHmFu6ABYNt0o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρйΛΜуΨΨΜпфЛпΟн():
    if 20 * 45 < 0:
        316
        pass
    value = 317279
    if False and True:
        pass
        _dead_8039 = 586
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AyfHfXk9wYsCaQeV5V23Bn0j42U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        41
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        95
        _dead_7548 = 459
    return total

def _ζцШЧБУДОδ():
    value = 549022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ningd3oUzachLQaywGGUMwQH520='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФθΠΧΥσчμ():
    if 14 * 19 < 0:
        820
    value = 787012
    if 24 * 50 < 0:
        723
        _dead_5664 = 402
        10
    text = __import__('base64').b64decode('bllBc192V3dhUzZJWExOX09zV0U=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4327 = 384
    total = value + len(text)
    return total

def _ицуцдςοщюΨсцΕн():
    if 48 * 28 < 0:
        pass
        pass
        pass
    value = 135018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxjGV1w03acTIlyt2kSnAC0M1mI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_9586 = 755
    total = value + len(text)
    return total

def _θЕΙσΜκΞЪΩπΖΣ():
    value = 33106
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQfDf1lp7ZEqagSNxkegYykJ1l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3789 = 509
        568
        pass
    total = value + len(text)
    return total

def _ЦГιЖζφμβ():
    if 10 * 72 < 0:
        pass
        398
        615
    value = 407037
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('YURsQkpCZkpfWW9zcWFYTHU5Nlc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _ЧГΡтжугμΚы():
    value = 297480
    if False and True:
        pass
        112
    text = __import__('base64').b64decode('Zl93Z0dTZ29MeG1iSVN2OFRzeVA=').decode('utf-8')
    total = value + len(text)
    return total

def _жйВψΕЕдытГфУ():
    if len('') > 0:
        pass
        pass
        _dead_1902 = 872
    value = 774815
    if False and True:
        _dead_6932 = 458
        10
    text = __import__('base64').b64decode('Z1YyN3M0RVA5bkI3WVU3eTJkR1A=').decode('utf-8')
    if False and True:
        533
    total = value + len(text)
    if len('') > 0:
        20
        pass
    return total

def _сюδЭЫΨыАооηзνЗн():
    value = 470741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAfCXkEAz6JUOw6n0GWeMhoI9j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _гιΑΔξζβΡΡΠфцκВθ():
    value = 947857
    text = __import__('base64').b64decode('TXdVdUpMM283dGJaZWJlX1h2ang=').decode('utf-8')
    if len('') > 0:
        pass
        8
    total = value + len(text)
    return total

def _κХиσзΣαΧЖτЛЭпΦΟ():
    if False and True:
        265
    value = 874351
    if len('') > 0:
        246
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBi8Onoj9p8oHwiQ4mKHNgg1vUE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        542
        pass
        777
    return total

def _ПХΦΤΒμЧВ():
    value = 884184
    text = __import__('base64').b64decode('el9TYklib2dWUzFTUExXOVlpZVg=').decode('utf-8')
    total = value + len(text)
    return total

def _РВэЭФςТтъЭφφ():
    value = 170664
    if False and True:
        370
    text = __import__('base64').b64decode('UmZQYnJHR2lLdHdzQjlwMU9KWmQ=').decode('utf-8')
    if 60 * 62 < 0:
        714
        _dead_9877 = 330
    total = value + len(text)
    if False and True:
        pass
        _dead_5434 = 566
    return total

def _ΘδъОЫраМзТ():
    value = 742315
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBj+b3AWqfAqbD7y40OVYjM46n4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χявωБΘТξ():
    value = 813763
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FxfhZGQJ+6NTbBqm7UGpIQM34EU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒΜКτБνΡгιο():
    value = 467532
    text = __import__('base64').b64decode('dDJoX3VESGFodTdjWjZhYVFsWGs=').decode('utf-8')
    total = value + len(text)
    return total

def _γсШФПЫтγНΟΖξэН():
    value = 232620
    if False and True:
        499
    text = __import__('base64').b64decode('V054QWFCZXBJM0t3ZGxGQkJLWGs=').decode('utf-8')
    if len('') > 0:
        _dead_5662 = 230
        _dead_6033 = 789
    total = value + len(text)
    return total

def _βνξжфΙΘКбΧΖЧчΩи():
    value = 231955
    if len('') > 0:
        431
        _dead_1306 = 233
    text = __import__('base64').b64decode('eFdVOWpaVEJSZHF3QV9GSU8wRnk=').decode('utf-8')
    if len('') > 0:
        373
        277
        307
    total = value + len(text)
    return total

def _ςшгΥωсγβΝДεдиЙ():
    value = 270468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Niy0QHgK964lFl2c/gSJGRQc5kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АяЮПΩΩιοЭΥυБςΠЫа():
    value = 173492
    text = __import__('base64').b64decode('eUV3Q1ZJamJFQnlQWnRZZWxBSWE=').decode('utf-8')
    if 78 * 58 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _юλыяаσξΑвЕШδ():
    if len('') > 0:
        pass
        665
        pass
    value = 127152
    if 52 * 25 < 0:
        _dead_3934 = 607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('J3/eewQc+YJQN1f02gGYMzwa430='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2836 = 241
        pass
        976
    return total

def _щοοΣЖщηρСаΘΧ():
    value = 262662
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KX3iOkQP2P4yHSKv3QC+JxwstU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _нηχэШЬЕΜфщωЦχФ():
    value = 891283
    text = __import__('base64').b64decode('QUdhamlEaTB5RzlJUWRYZzZyb0E=').decode('utf-8')
    total = value + len(text)
    return total

def _γхΑΧаХТЬΨНЧН():
    value = 817424
    if len('') > 0:
        606
        165
        185
    text = __import__('base64').b64decode('VmdxSUNLNlM4VHVKeUZfaGk0Uzg=').decode('utf-8')
    total = value + len(text)
    return total

def _рачхВтБΧμФЬκяь():
    value = 258015
    if len('') > 0:
        _dead_8232 = 631
        533
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyvNfmgR9IQXMAqW8m+lMikt6Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_8178 = 8
        pass
    total = value + len(text)
    return total

def _ЖдΓκΟЪκЗз():
    value = 981541
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KCrvPXcor6oWPQiZ926CHiI58Gk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чκЗΗΤΜψΟйωвΣ():
    if len('') > 0:
        105
        pass
        pass
    value = 804870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwPdY1c166QQbin3zWGSMAAs6j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4052 = 790
        pass
        243
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _эγΒЬΩАцδΙΨлТκ():
    value = 262906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyToWHYK+P41CBebynyVAwkFyU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_3374 = 243
        927
    total = value + len(text)
    return total

def _ячАΧУωзχΖУССΨΕЛЗ():
    value = 367473
    text = __import__('base64').b64decode('Ukhkb2lfM0swd1R5ZXZnUlVjRkE=').decode('utf-8')
    if False and True:
        291
        pass
    total = value + len(text)
    return total

def _цшτηщжΥφαщЧзцΒ():
    if False and True:
        _dead_7025 = 349
    value = 519246
    if 4 * 3 < 0:
        _dead_8062 = 945
    text = __import__('base64').b64decode('UFlFNE13bmRhb25RbjlXOFI1eUU=').decode('utf-8')
    total = value + len(text)
    return total

def _РйЫзПяъθΠХпПΛИщ():
    value = 908699
    text = __import__('base64').b64decode('ZEttYmswb0M1UDVGdmpnbXdmZ2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ШыςαьыφεэуИфπхФΑ():
    value = 510789
    text = __import__('base64').b64decode('STd5RlExOUlpVl9TWEpVaE1LY1E=').decode('utf-8')
    if 88 * 66 < 0:
        _dead_3698 = 182
        _dead_5397 = 972
        238
    total = value + len(text)
    return total

def _ШФЯЗиζБЙΕΡΧРΒΝЯα():
    value = 638951
    text = __import__('base64').b64decode('RkVvbGhpT1NmSTI0OVdGeW0xZU0=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ыАЗХрΖτφ():
    if len('') > 0:
        pass
    value = 907573
    text = __import__('base64').b64decode('ZnpxWW5kYmswdl9TV3d0UnlibUE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕΓЛяΛχΑλВγδΖψθ():
    value = 825869
    if 27 * 15 < 0:
        284
        pass
        pass
    text = __import__('base64').b64decode('S3JqYTc0Y2Jqb2FzeFRlUEJTeUg=').decode('utf-8')
    total = value + len(text)
    return total

def _эηΘЪυбυτу():
    if False and True:
        160
    value = 498432
    text = __import__('base64').b64decode('cFM2QjFYSXZnZjVLOHkzTXVfck8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯгωΠядВХαэУиΞЦЛ():
    value = 827931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kwa9dl03r5EFN1iSzlWVBCMn0Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3043 = 242
        _dead_3468 = 694
    total = value + len(text)
    return total

def _ωΛЦзПНΤЧδАсН():
    value = 214364
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRDnPFVp6YwmaR2k+lzICxIl6jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙяЕЖЖИптγшγд():
    if len('') > 0:
        727
        pass
        916
    value = 315544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXjzZGkS7qoCDQS3kXeiMhE6zkU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АнЦΕΦЖчЧФΕиаК():
    value = 164018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB3IPwgh/LArCQe7+3O7HwF7yVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДшΖμТωЦθЗΔ():
    if False and True:
        _dead_4362 = 906
    value = 141410
    if 68 * 64 < 0:
        _dead_6674 = 265
        277
    text = __import__('base64').b64decode('eHdtZEY2d0lUX1RRUjRxcW1HNEg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕЛφцъОΡΘ():
    if False and True:
        _dead_8998 = 175
        pass
        981
    value = 415707
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAnTQ2A4zLopK1yR7meCJwk2/G0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖКΛпИΚмрΖПН():
    value = 564525
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cwn3NnRuxI4KLjj7w1ijLSB97WU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨДξЬΤβΦνωЖтц():
    value = 16749
    text = __import__('base64').b64decode('Wm9HY2ttOHVHNGs5S0ZZazdXUzg=').decode('utf-8')
    if len('') > 0:
        pass
        467
        _dead_8853 = 370
    total = value + len(text)
    if 1 * 35 < 0:
        _dead_9700 = 431
        603
        pass
    return total

def _шмσжРУκΒθ():
    if 54 * 70 < 0:
        _dead_7947 = 259
    value = 10689
    if False and True:
        _dead_7889 = 887
        pass
        208
    text = __import__('base64').b64decode('d1BZbGFiZlB4X1BJbGViTFlzeW4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        510
    print(__import__('base64').b64decode('IA==').decode('utf-8'))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()