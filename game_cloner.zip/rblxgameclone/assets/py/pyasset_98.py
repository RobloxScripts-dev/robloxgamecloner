#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ΞяЖμЫΡγАИбΜ():
    value = 610978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwbOO1c7/f0aExer+HK7JjEZt2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υпбΑхЪХεфчЦэЦΠЦ():
    value = 764975
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBjeYGVg34ULPhmzn1LEbQsa81w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖДΧгξЭуΑ():
    value = 2294
    text = __import__('base64').b64decode('Y3pIWE5HWF9ZOVdxQTJERXZBWTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _юυΟеμΓпх():
    if len('') > 0:
        pass
        pass
    value = 830334
    text = __import__('base64').b64decode('TVVrRUF1ZWpfSl8zVVNGUDRPUHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ъυЩζОЮΗЕШτщΛщ():
    if False and True:
        857
        pass
    value = 228800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DT/UWkgfzrorHT6o2kWSDiEr/Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АхГπΠюВжθκфзлНσ():
    value = 984543
    text = __import__('base64').b64decode('emN2MTJnckN0TVlockY4U2hycFA=').decode('utf-8')
    total = value + len(text)
    return total

def _юζΟβυΖΩξ():
    if len('') > 0:
        301
        _dead_2786 = 57
        _dead_3350 = 414
    value = 215417
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzfqNlU//4BbOA2PzQCjCwEt71s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_9338 = 858
    total = value + len(text)
    return total

def _оΓνСΠэΜΝΖΝΜТζ():
    value = 333112
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PDiyb14qxoQPPyGJxmPBIgEi5l4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _внЖΓφцΦΛθхΧνэ():
    value = 738065
    if 39 * 96 < 0:
        _dead_5551 = 291
    text = __import__('base64').b64decode('ZDBfS2JjaHRuYUhBU2RpQWJ5WkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖиХдθХпΑρйМб():
    if False and True:
        _dead_6084 = 550
        117
    value = 678389
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQm0f14qrfkiaV6F7FSGJwAH9kw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        809
        pass
        pass
    return total

def _ΠЯЗчыфбφ():
    value = 15467
    if False and True:
        481
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwPbQ1wt86sPGF6izgKeI3wozjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        122
        pass
        979
    return total

def _хΦυΦЕςΠдмΠбВТΘςО():
    value = 971052
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HTnve2gD2L5TMCuzwWCAOBc+xj4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕφюАЩπζАьηТюΗчΓ():
    value = 284635
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCrOewAp/6UANAmo5g+fFSoKsk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_7062 = 973
        888
    total = value + len(text)
    return total

def _ЪΤХНФΤЕьζχРφщцФδ():
    value = 773693
    text = __import__('base64').b64decode('U0dzN01wbDFlUUd1dkhhQnF2WDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪиДΞΜωοДмФσИ():
    value = 577076
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBzteWkG5I4yNSGB+w++MyEf5X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БКЗЩДχсъ():
    value = 399018
    text = __import__('base64').b64decode('eUpzV3hsRHdVcVRUb1ZHVGlibU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙθρъφйΨЯΧхβΕΕ():
    value = 214799
    text = __import__('base64').b64decode('VEV6dDYweW1ubEtROXRmT3FodGY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        448
        _dead_9696 = 789
    return total

def _ΥΦрщВСхчξμяр():
    if 70 * 53 < 0:
        pass
    value = 434714
    text = __import__('base64').b64decode('dUI5VFF2X0paTFVjUHVrYm9vTTE=').decode('utf-8')
    if len('') > 0:
        650
        _dead_2104 = 137
        pass
    total = value + len(text)
    if False and True:
        394
    return total

def _ΛлыΡыЛГщСδοωπБυ():
    value = 673560
    text = __import__('base64').b64decode('TXBlWHJ4dkk3M0hnSzFxb29GVFI=').decode('utf-8')
    total = value + len(text)
    return total

def _БМшйаЧшшςсγАг():
    value = 704805
    if False and True:
        _dead_6711 = 464
        _dead_1024 = 261
        873
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSq3SnVs34crHluB2n66OXc16lw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        _dead_1540 = 886
        _dead_5396 = 75
    total = value + len(text)
    return total

def _ΜΥσιΕδЩОΓδρиГЙЦХ():
    if False and True:
        _dead_4277 = 51
        _dead_9538 = 815
        pass
    value = 277322
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('czBXNGNUdXFfYVZzNDZ0N0RxS0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕЯΜЯСΖюσσДЗλΦιλ():
    value = 562137
    if 78 * 92 < 0:
        _dead_9714 = 181
        508
        _dead_4350 = 962
    text = __import__('base64').b64decode('WUlyTl9LSWZ3QTVsNzlJX2t5dUc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЬДΖЗΜоТипИΠЫЧΧ():
    if len('') > 0:
        686
        _dead_6291 = 169
    value = 648740
    text = __import__('base64').b64decode('bjR6ZVNHZ24wTG1la1ozdjl2X0I=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if False and True:
        pass
    return total

def _пτшΔкεΕφэπΒъ():
    value = 337675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTu9fXo4ypkgOTyX+lC+LnM3sH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δяΘкеЬЕюοМ():
    if False and True:
        pass
    value = 56020
    text = __import__('base64').b64decode('cWI3S2tXYk5pSEtUd3h5YmYybUk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        364
        737
        _dead_6640 = 287
    return total

def _гυωΛузГХΞпΓбΤΧ():
    value = 484363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiDWa0YU14QXFSSi2kbCFnw67ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТЯΖβΞσжΔΡуΝΚφΘА():
    if 42 * 78 < 0:
        pass
        pass
        382
    value = 146347
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiTARksh9LAiPwasnWmEFTQM7mU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МΕΙΒЕзΗщΘ():
    value = 980672
    text = __import__('base64').b64decode('ZHJRSXZxaXZhY2pvSUJ2Nnpwdlk=').decode('utf-8')
    total = value + len(text)
    return total

def _ωζЦγΛиΟΙΝ():
    if len('') > 0:
        pass
    value = 153882
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXnrTAQOzoNWbz6C4Xu+B3R65j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γгΣйπСюλФЩ():
    value = 6339
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IxbRWUIh9LoBHCmHnVOmBHd9zF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2914 = 206
    total = value + len(text)
    return total

def _ЭΦЦэΧЙгοΡоκβ():
    if False and True:
        _dead_7743 = 554
    value = 832334
    if 74 * 37 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DADVP0Fr749UGxf6zk+IHwIWzjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        356
        _dead_1726 = 949
        283
    return total

def _пСББχпКъЙ():
    value = 575024
    text = __import__('base64').b64decode('cmJPbTVoOUM4WjZTMFlfWk56VlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ρΘΛкЯωПΥυρщЙΩι():
    value = 83022
    if len('') > 0:
        _dead_9082 = 251
    text = __import__('base64').b64decode('c01hVXlNd2Rmc3NVdXpLYXlrQmU=').decode('utf-8')
    if 20 * 43 < 0:
        _dead_9410 = 723
    total = value + len(text)
    return total

def _ΜКйВДшΦτδшЙΖσ():
    value = 151422
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzjGYWVp/5JSaiGF2WO4GS4EyG0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зΥЫγυцЛцКχВ():
    value = 913591
    if False and True:
        pass
        109
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FAr3b0cvxPlWaBvy6WCqMjQ/0ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΧэДтδЦъΜаЛΤсвГи():
    if False and True:
        pass
        _dead_8466 = 537
        422
    value = 29837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('P37VfXIK+vgwHjC0+kfDOgMEtGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓярИЧЗΣΛХξэяΨτ():
    value = 611704
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kzy3VlVhrqQhbh6P43jDPCMFzH8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 36 * 52 < 0:
        _dead_7469 = 579
    return total

def _ΕЖПμпХсГЧНо():
    value = 812548
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BA7yfUUr3P4aIFaQ5EWxGDYH4D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛПζКΣΡсцу():
    value = 42776
    text = __import__('base64').b64decode('cThvcE5IVURoOUFqV3lIY1VWd04=').decode('utf-8')
    total = value + len(text)
    return total

def _δхнаЫйπрτожΧзα():
    value = 803374
    if len('') > 0:
        _dead_3969 = 164
    text = __import__('base64').b64decode('c0hEZWtGbTdpSVlvaldjQ1B1dmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚШОΙбъщМΠΦОΞ():
    value = 766610
    text = __import__('base64').b64decode('Z3lwbG1Bb2VKZUhHOHFITWFvNG0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟωДΥκШωυπУЛ():
    value = 444290
    if len('') > 0:
        560
        pass
        _dead_7745 = 652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgbhPVk3p7oHPj2mnQSKGH1812Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чВЖвΤпΛθЦ():
    value = 845524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jza2O18q8qE6Hhf04U7AZjMewEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рπЖιЩЛпАΩр():
    value = 300692
    text = __import__('base64').b64decode('UElEZVE5Y3k4NkpuczdNdGhEWHE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _λΤгψЩΒφЧАуΒпΔи():
    value = 762376
    text = __import__('base64').b64decode('QXdlZ05LY3RzQzZOWWxkRTVpVlU=').decode('utf-8')
    total = value + len(text)
    if 16 * 77 < 0:
        _dead_9478 = 171
    return total

def _σЪΡΕΡпπсчψГΚΨФε():
    value = 716299
    text = __import__('base64').b64decode('VjhQam5SNmlLSk1zenZXOEVOUjI=').decode('utf-8')
    if False and True:
        _dead_5307 = 298
    total = value + len(text)
    return total

def _юΡКлИзыνНчτρΗцр():
    if len('') > 0:
        14
        _dead_2545 = 36
    value = 826437
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgHobEhq2JowPi20w2mzbCgm3UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 58 * 10 < 0:
        _dead_9665 = 55
        pass
    return total

def _γυЗνβоБμкδм():
    if False and True:
        _dead_1352 = 969
    value = 744906
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhnrSEIayoEILA6l/QeAHgge8E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΥнХΥснχф():
    value = 740504
    text = __import__('base64').b64decode('Z3BxU0VaeDVhUkJrcEJlem0wS0c=').decode('utf-8')
    if len('') > 0:
        pass
        225
        _dead_3937 = 137
    total = value + len(text)
    return total

def _ωδьЖВШζфРПюэюΛ():
    if len('') > 0:
        pass
    value = 165022
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDbzWl4vqa8KBRyJ+1uEYBQ2vVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        334
    total = value + len(text)
    return total

def _РоэЯΝЙΡлΓСПμκΤΟ():
    value = 186330
    text = __import__('base64').b64decode('VXNlYTlndFd5RURHemJfNmFQSGk=').decode('utf-8')
    if False and True:
        318
        pass
    total = value + len(text)
    return total

def _ЮΗПογΔЭГьΑΩαΓεΦ():
    value = 875431
    if len('') > 0:
        170
    text = __import__('base64').b64decode('UWdENWhja3Y0enY1cXpqT3VDQVE=').decode('utf-8')
    if False and True:
        394
        _dead_8539 = 130
        895
    total = value + len(text)
    return total

def _ΚъρсиЗΡЪЗр():
    value = 590284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HALQR1VhzqFTHiSi2VWTDncg3UM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цПыьАВлΖσΟςΖЯχуζ():
    if 56 * 15 < 0:
        pass
        _dead_6395 = 647
        pass
    value = 142229
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhbVNwRg970FYiir23WzICIr9Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РΣькЬэΨΜξшΣбэξΟЗ():
    value = 10349
    text = __import__('base64').b64decode('dDNRV1pKemMwVlZKZVRlNkRpYTQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛеΦмРШхтИУωΟλэкс():
    value = 160296
    text = __import__('base64').b64decode('V01QV0tkcGxVUV8xTk1ySXhwMGk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΕтЩФγζЫΙяюМД():
    if False and True:
        _dead_3296 = 619
    value = 979221
    text = __import__('base64').b64decode('WEtTM0QxS0oydWgzVUR6cERzV28=').decode('utf-8')
    if False and True:
        pass
        379
        210
    total = value + len(text)
    return total

def _ПГЮЮςΡΖЖБλКСБшЧ():
    value = 951554
    if False and True:
        990
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAzBXgkPz588EzuM+3PEZDEe/lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШКΠэпЭйσΓΕχ():
    if 29 * 16 < 0:
        pass
        pass
    value = 129779
    text = __import__('base64').b64decode('QzZRTGR2UmN6ajFvTXV3ZldmcTQ=').decode('utf-8')
    if 21 * 42 < 0:
        522
    total = value + len(text)
    if len('') > 0:
        827
    return total

def _μнкгкτЩлШнеЛБΤβΥ():
    value = 911478
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LB7JXkkf7oY2DDWH2UGpOwp/9Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛмОυΞщнЯ():
    value = 284307
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MjfBW3kV1ppaKR+h+WPJJQB9w2E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДорΔДΩΖΩΠν():
    value = 702978
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nwb9eXsT+v4gHBnwml6iDBY50EE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_8292 = 849
    return total

def _ыςΙяесΛщ():
    value = 368538
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAnOZlI03a45GD/zylOJZywE3T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΦЫЛΩСиκΩниθσЖл():
    value = 193403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KiTIal1p9KEAIgOQxQS7JgMctEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _БΛПЛепфДРΕЦЛ():
    value = 544568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eg3VNlQS3L4TEjer/VzCZi4Yxnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АЗζюсеΖΒЕЧАξЗ():
    if 98 * 76 < 0:
        pass
    value = 21523
    if len('') > 0:
        _dead_9165 = 191
        _dead_4971 = 51
        _dead_4666 = 503
    text = __import__('base64').b64decode('d2Q0OTJWeERhUE1PeExrU3l0amY=').decode('utf-8')
    if False and True:
        _dead_4918 = 741
    total = value + len(text)
    return total

def _ωАλγЯΛБзЬуБм():
    value = 854962
    text = __import__('base64').b64decode('d2tLeUhBQ2g0OGlnNHhKdHBuZXM=').decode('utf-8')
    if 44 * 73 < 0:
        pass
        133
        _dead_6291 = 773
    total = value + len(text)
    return total

def _ΗψОвΖБΟγЗЫдΜохςи():
    value = 467612
    text = __import__('base64').b64decode('TWZ1Q3M0R1VhbkhqdW1mVkpHS3E=').decode('utf-8')
    total = value + len(text)
    return total

def _мФрэСООХОΝщΞΛ():
    value = 583628
    if len('') > 0:
        _dead_4130 = 6
    text = __import__('base64').b64decode('ZWJSYWtfM0hDdU5XUGJLblBQOVI=').decode('utf-8')
    total = value + len(text)
    return total

def _πзкζΡЕйΚпΙДГ():
    value = 880748
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iw72XUIx8IYgHSOP/XybJAg3/F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мощκιφПЫжψшфя():
    value = 924597
    text = __import__('base64').b64decode('eGFNUWZHUHVZdWwwYW5Lb0JEV1U=').decode('utf-8')
    if False and True:
        410
        113
        _dead_6308 = 122
    total = value + len(text)
    if 15 * 97 < 0:
        _dead_3679 = 107
        pass
    return total

def _зГΡЙЪΔΝδΝβψЭ():
    value = 146326
    text = __import__('base64').b64decode('UFM1RWFRZkVEWTZoY09FaVU3b0s=').decode('utf-8')
    total = value + len(text)
    return total

def _йнмρμΒΤэЧΝфс():
    value = 1649
    text = __import__('base64').b64decode('YkdXbWRpM1RmUFNMQzZLbVlGUjI=').decode('utf-8')
    total = value + len(text)
    return total

def _хΣΜΖмЕЕСыΑλЭΕγМ():
    value = 359335
    text = __import__('base64').b64decode('bHRoTUNLUE4zYllFMUQ1SHJOZks=').decode('utf-8')
    total = value + len(text)
    return total

def _сμпσзЦΧЩΨ():
    value = 639053
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('An7JVkQJ3Ks1Pi2v7wWFEyl3t2w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηΡчыςнЯΓрЗ():
    value = 132297
    if 20 * 14 < 0:
        425
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHrRf2Jrq7ETMjv38AOnLCc17jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 51 * 34 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _χИмΦКйсΘЧ():
    value = 70293
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSTTWlYdp4MlL1uay3GnHRE192M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МλЗνσУбЧΥτЛΧΡУ():
    value = 928964
    if False and True:
        pass
    text = __import__('base64').b64decode('eVpEX25fTDV1N0lJOWptcHBPXzk=').decode('utf-8')
    if 100 * 73 < 0:
        pass
        pass
    total = value + len(text)
    return total

def _ρЦΔΜюΥюΔПζ():
    value = 503701
    text = __import__('base64').b64decode('ZWNDbldTZnVBY1oxNFBkZ2JyOFY=').decode('utf-8')
    total = value + len(text)
    return total

def _βТΠГЦДΘшБЯОμ():
    value = 589796
    if False and True:
        pass
        843
    text = __import__('base64').b64decode('WDR4SUFoZmRydE1QOTNrcjljbjM=').decode('utf-8')
    if 34 * 29 < 0:
        pass
    total = value + len(text)
    return total

def _οΜэлΤΞκωρΦгщь():
    value = 926372
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQbVW2Iby6Mtbwupm2+kBAt+0Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1548 = 37
        _dead_8439 = 61
    total = value + len(text)
    return total

def _ЪЦΘыБαΓωΩнчкζΨч():
    if False and True:
        pass
        pass
        pass
    value = 611689
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiHMZV4o+Z8wCD+L7gOjYCB282U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        882
    total = value + len(text)
    return total

def _ТΠΚюλДРο():
    if len('') > 0:
        pass
    value = 247048
    if False and True:
        _dead_8064 = 909
        779
    text = __import__('base64').b64decode('cDlKQk9hbzdSU2poMnhJdDBUOHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫεσБΙоΛн():
    value = 964821
    text = __import__('base64').b64decode('S0Zla0NFalJtdG9HMG0xVDU0am8=').decode('utf-8')
    if False and True:
        pass
        _dead_2687 = 535
        194
    total = value + len(text)
    return total

def _МΩшΔΠрпПи():
    value = 960238
    text = __import__('base64').b64decode('Z3c4bjIyTlZubXdZcWw5Nl9kRlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣЯΤТТдбμυΛшчΥшц():
    value = 658020
    text = __import__('base64').b64decode('TFZBb3JNMzFCZTQ5NFo0X3RiTzI=').decode('utf-8')
    total = value + len(text)
    return total

def _НгиαθΖΚяνΝйρλУσ():
    value = 1767
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBXISHwhq7wtOwiMmmmmJzZ59kY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χИСσγκρЪШСХ():
    if len('') > 0:
        950
        pass
    value = 859937
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyO8eXgJzaMUNV2K62S4AgAAyGQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΚМвΕμЭςдΛЬв():
    if False and True:
        pass
        411
    value = 307943
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSrQYF0VzpotFAWS+A7FHgoht1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        868
        _dead_1748 = 524
        pass
    return total

def _σкВЩθеОжПлΤξμ():
    value = 50397
    if False and True:
        _dead_8486 = 429
        971
    text = __import__('base64').b64decode('ZFRjeUZfUjY1T29lcU1BWldVdDE=').decode('utf-8')
    if 12 * 44 < 0:
        _dead_1915 = 204
        pass
    total = value + len(text)
    if 3 * 75 < 0:
        _dead_1472 = 421
        453
    return total

def _σжюΕъАгΒηΚыБчО():
    if len('') > 0:
        60
        _dead_1473 = 750
    value = 740270
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAXRPXIzzoYTNxiF8n6WJiQW0Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 2 * 7 < 0:
        683
        _dead_5648 = 809
    return total

def _зυζΨΔУЯОτчζа():
    if False and True:
        837
    value = 605157
    if False and True:
        _dead_7411 = 667
        453
        _dead_2923 = 469
    text = __import__('base64').b64decode('QU1Ua25jMFlwVFFPQ2FhbmJfRFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ВцЕιЧЮμд():
    value = 153986
    if 43 * 6 < 0:
        _dead_3790 = 586
        pass
        _dead_3309 = 191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABDnOmJrr5oRbAmw33+GCxw14Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 55 < 0:
        387
    total = value + len(text)
    return total

def _ЗпΑεΑδΟσηΘхГρбГы():
    value = 284007
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChexO1AJ1ow3LhmMkUSIBCgl6GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ТΕшйЦмйΘζκо():
    value = 791653
    text = __import__('base64').b64decode('Qkp4ZG1Wa0t1dG9tazNiRlpFaFU=').decode('utf-8')
    total = value + len(text)
    return total

def _ИτμюцεςоΒЮ():
    value = 984296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSDATH40+6wXABaqmmW3IXYX21E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эНцЬЪαЗлОЙхЕΞЙΞω():
    value = 925015
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('In7QZAM756wUGCqz2US5BxIEwW8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 95 * 58 < 0:
        482
    return total

def _эцλЛΛшгМκшваО():
    if 53 * 23 < 0:
        pass
        pass
    value = 885951
    text = __import__('base64').b64decode('aDBpMVFkV0lYbXRNYTNvSnlydWI=').decode('utf-8')
    total = value + len(text)
    if 12 * 1 < 0:
        _dead_6101 = 146
        _dead_5745 = 378
        _dead_9780 = 973
    return total

def _σОδКТΔΥЭυсАкψч():
    value = 955871
    text = __import__('base64').b64decode('V3Y2RFdjX1c5XzIzaWFiRGhLVHA=').decode('utf-8')
    total = value + len(text)
    return total

def _нСΓНΓΘΛΖ():
    value = 131520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyDzdF4vqrsELAmpmFOTPiknxmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓяψΩβΚБψςΟΤЯФΟΩ():
    if False and True:
        _dead_1557 = 931
        _dead_2395 = 472
    value = 329942
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwPrV18G948HFguCzVS5EAQiz2Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДЫхфΘАреАШΘΝЩΥЗ():
    value = 484473
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxbXXEAKya42Ch6v+mHCJnwl61o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χЩЕЬΩнΦи():
    value = 588597
    if 82 * 65 < 0:
        539
        pass
        pass
    text = __import__('base64').b64decode('U0pNZ21tYm05MEJJWjczTUFrdTM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓкЛЭΛλяКαУ():
    value = 260703
    text = __import__('base64').b64decode('dTBJVmp3R1lTODM1MUpMb0dzXzE=').decode('utf-8')
    total = value + len(text)
    return total

def _оВСвИдрчψЩчуЪ():
    if False and True:
        347
        439
        pass
    value = 989814
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NCL1Xlxt3Pk8MCGx7XiXIHci8XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 19 * 56 < 0:
        pass
        _dead_5716 = 926
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_5087 = 883
        150
    return total

def _АЙЖТРγхΚ():
    value = 346802
    if False and True:
        369
        11
        _dead_2623 = 201
    text = __import__('base64').b64decode('Zmh6d3RuNUdBdTZiWmlTR0E2VHA=').decode('utf-8')
    total = value + len(text)
    return total

def _спΜοБΓХπфЛгΧΔ():
    value = 891698
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DgrHS3Qu2YcPLw2W33mzBxV/3Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фγБМΒκЮЙηιΞΚШр():
    value = 82958
    text = __import__('base64').b64decode('d2tqT1ltcGt3b0EzMkxaOFlhdE4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝκЖΛλекΜтιΓаπΦσΞ():
    value = 162160
    text = __import__('base64').b64decode('cWJ6dkk1c3VTRUVZTFRDaVVQUWQ=').decode('utf-8')
    total = value + len(text)
    if 42 * 16 < 0:
        436
    return total

def _юыσиуыфφЭλΖΥСШΓλ():
    value = 46247
    if len('') > 0:
        _dead_2988 = 846
    text = __import__('base64').b64decode('endnMWFNSFJjWFVZNW5NOVJhQ1I=').decode('utf-8')
    total = value + len(text)
    return total

def _КηγгЕΙЮлΣΙТК():
    value = 707025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyzVaHkGrr0TMCyswHiFOQYI4Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РοНΥΘΥζоШДλΨЦшω():
    value = 452796
    if len('') > 0:
        _dead_4826 = 675
        _dead_1844 = 92
    text = __import__('base64').b64decode('QmdGVFpJZTJYSFhHOTlGNzFIN0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЕвТΩЬУΩΝΚΨчЧЭМю():
    value = 153186
    if False and True:
        546
        pass
    text = __import__('base64').b64decode('QXB4dTQ4TkZSQ3VrdnRxSG1OeXA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖΒсΑЯкгяПрьиЛьаΒ():
    value = 166676
    text = __import__('base64').b64decode('eFEyNUR1ejZDX3gySUJyaFNKSkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _УκРжхιмΧЖ():
    value = 176279
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwrUemNoxKVVEleynF+cMAo70Us='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МмшωеОПΓζПι():
    value = 44931
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EAjpYXYN+bhTIgGF0HKZDCgcvWc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПμИΚηοΝρρб():
    if len('') > 0:
        _dead_9190 = 624
        _dead_4522 = 142
    value = 906884
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az3GPQEjq7sNayLx0AfFJnUj43w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        194
        _dead_8720 = 470
    return total

def _ΠЦЖеΝΔΛΛΝΞ():
    value = 620266
    text = __import__('base64').b64decode('ZDVHSXhSWXZTQ2ZvSzk5dEZCaDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ГζΩσыуиΗИВжцфΨΟ():
    value = 88798
    if len('') > 0:
        _dead_1187 = 156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiTHYQE9q7snYiCSxFWaAnx6wlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 72 * 23 < 0:
        _dead_8684 = 372
        492
        pass
    return total

def _ШΓξφΚνθψδυ():
    if False and True:
        pass
    value = 517133
    text = __import__('base64').b64decode('dFBra1NVVVNQMTZrVkJNczBCc2c=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮαЩΜςЦылаАЦсАψ():
    value = 546622
    if False and True:
        200
        _dead_4365 = 617
        _dead_3138 = 506
    text = __import__('base64').b64decode('T2dxU2xCSnk5TUJMTVBQNEEwOHc=').decode('utf-8')
    total = value + len(text)
    return total

def _θτтйγΧφы():
    value = 148487
    text = __import__('base64').b64decode('bzBkaVZibXJuZnFNY05URUJRT2U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЕΟоΒδΘехεЧММЙжΒМ():
    value = 555608
    if len('') > 0:
        950
    text = __import__('base64').b64decode('WmhmSHBDaUlrMUhIRmZpMjFSdWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ζΙуΥкυХНз():
    value = 298520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAnCV3UJ57wBMV6w2XuhCzc8smY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 18 * 52 < 0:
        pass
    return total

def _ЩΘМΦφΙщΣηΝ():
    value = 412801
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQeyQUMg5KQAKQWpzXynFi89zkM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΧΩΦθГςШМ():
    value = 200732
    text = __import__('base64').b64decode('RXhKV2ZfZ1dvaVhUS0x2OGQzVlg=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    return total

def _УΒчΑχΣΟлЪьοЩσВ():
    value = 429955
    if False and True:
        _dead_2450 = 642
        _dead_3032 = 540
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHnWZ1YW7o0AOQazmkC3Ayog80Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_8723 = 826
        _dead_4914 = 892
    return total

def _вΚζβяаΜцлσзЖζ():
    value = 90415
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dw3meQku8oFWAh6wygW4JCgYsT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧтмρΤрΟЗкЫбρΦΣзВ():
    value = 970141
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('cFV6ZmxHcWlMZmozUXpnZm94a0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΙΜΡχХуΥк():
    value = 245028
    text = __import__('base64').b64decode('dDQ1N3NvSEZQdTZ4NlFBNEU4aGk=').decode('utf-8')
    total = value + len(text)
    return total

def _цΒςНАΣΛЪΣыфЧгЗΑ():
    value = 916919
    text = __import__('base64').b64decode('UVVFUzNkOW5rNXIyb3d4UGpNRGs=').decode('utf-8')
    total = value + len(text)
    return total

def _ъдИЗηБфΤισΗЗ():
    value = 227127
    if len('') > 0:
        284
        _dead_3545 = 180
        _dead_2445 = 696
    text = __import__('base64').b64decode('WUs0Y2VjakxWTVZlcTBISGd1V24=').decode('utf-8')
    total = value + len(text)
    return total

def _шщΟцφПηΞипг():
    value = 431177
    text = __import__('base64').b64decode('Z05GRUp1VHMyNVI4R3FSTU5KdUk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚЗρπмΜβΝй():
    value = 888186
    text = __import__('base64').b64decode('TXpYdHJ3TkhacGRNamRCWUl0d28=').decode('utf-8')
    total = value + len(text)
    return total

def _сςΚΜΑнΑоνэмμ():
    if 2 * 50 < 0:
        374
    value = 734614
    text = __import__('base64').b64decode('R3pNRUEwQVNLRURXdU9mSXJOM2Y=').decode('utf-8')
    total = value + len(text)
    return total

def _эλжΥОЪхτ():
    value = 597521
    text = __import__('base64').b64decode('aEZjdHVQVjdJZ2Q4SXR0WlphdGE=').decode('utf-8')
    total = value + len(text)
    return total

def _σЕεΝНοΗοΠМ():
    value = 340191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB/CaHsr7pcEHhyO23GdIgMJs0U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γνаОγСεеμφПДΗςж():
    value = 560691
    text = __import__('base64').b64decode('TVNlcklwYzdCUnA4SjRJQUkzMTg=').decode('utf-8')
    total = value + len(text)
    return total

def _ыΟεКяЫьΞ():
    if 51 * 95 < 0:
        _dead_3484 = 767
        pass
        496
    value = 243047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KnbyZUQR56JVAguSn1KnLSwi4UQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _εдЭΞΧεΝЖ():
    value = 565068
    text = __import__('base64').b64decode('WllHVzNkUk9nWHVfVHd0YUJOOU0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪНЪгаΖщКρбκйеЪΝ():
    if 32 * 60 < 0:
        _dead_6641 = 758
        _dead_4022 = 535
    value = 944806
    if 94 * 95 < 0:
        _dead_1497 = 183
        _dead_8706 = 256
        822
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyrwSVMKzfkCHCL73n6oAnYX418='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡндΖΟЬхδ():
    value = 740157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cgy8SkAT0octCSr37VSSAjV41kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 73 * 72 < 0:
        pass
        664
    return total

def _офвУбγηВИψЫΠВ():
    value = 886660
    if False and True:
        _dead_7710 = 145
        pass
    text = __import__('base64').b64decode('UWdjSDFheG5QMmNoZjg3Z1h1amY=').decode('utf-8')
    total = value + len(text)
    if 29 * 48 < 0:
        pass
    return total

def _дяцαыπяΥΥЗНΟШΥγς():
    if 53 * 67 < 0:
        _dead_4318 = 410
        pass
        pass
    value = 723363
    text = __import__('base64').b64decode('S3lmTEJDa3EwSVZRSl9ZMW1ERDk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧУγПГΖЮПμΒпх():
    value = 717853
    if len('') > 0:
        pass
        932
    text = __import__('base64').b64decode('RHlEZ0lhdkNtMENiRG5VU0hCRmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬοΕВΘΑцжшΣ():
    value = 881260
    text = __import__('base64').b64decode('WWtkSzZ0RjlHX1ZlRkpIb3lMdVE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠЫовиЧРмж():
    value = 924627
    text = __import__('base64').b64decode('cEFJc0ZlNzZ5ZFoxckNPN2pfY3o=').decode('utf-8')
    total = value + len(text)
    return total

def _шοθЙΦнηшΛнζΦшас():
    value = 105108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgHeOwc436EsPgq7nX2dbHwYxng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йэЖξλъцйСζкΔГиπ():
    value = 340809
    if 51 * 94 < 0:
        pass
        _dead_4727 = 922
        591
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABr1eEcr0ZsJPw3y2kK1GCk+6l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚΙЦжЬжУШω():
    value = 900167
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JijpXXYJ9r8BFyqE43KCBQQs500='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        479
    return total

def _λαОΠρΩЪфЛδΙια():
    value = 231038
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQ2ze24NrJgzE1iskV6SGj165Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ущжОХΗЖыΡΖЯξΒЕ():
    value = 853340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQfeRwgO/LwNIyaK/E6YBTUN4kQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦΛьмεСΖΘбхΖшЮπΛ():
    value = 472302
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LiTnREgPp/stAyizy0SjGAQJ62s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗΣГκЯΕβΑаΒъΥК():
    value = 672180
    if 53 * 46 < 0:
        _dead_6606 = 902
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQrgbWEN9aA7PCOn4nK8PTwCtUc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 13 * 69 < 0:
        pass
        _dead_9996 = 218
        344
    return total

def _ηТκдСΕРдοжаΟЭПΝО():
    value = 612902
    text = __import__('base64').b64decode('STRtejE5eFlwWTZETmFkdm0xbnk=').decode('utf-8')
    total = value + len(text)
    return total

def _мяΓщсκТΩΤωГщМы():
    value = 367159
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHnMNmsuyvAPEiS25XPGbBU85kU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кυτччΞΑзЩЮΨΝ():
    value = 156973
    text = __import__('base64').b64decode('UHhzQkFLR3YzVjV0YksyNlJXd1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮшσΝЭДРΧΔβΜκбπΕ():
    value = 202810
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAe9eHwR069WMVeL4l+bYRIu/ls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АΚλξнΣΠΕВξЯ():
    value = 672300
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhnPRVkN2acXOzX7nmG/BnEb7n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_3974 = 734
    return total

def _ΚαγΗηλφα():
    value = 106741
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHnLQmsA/IYNDj21n2+AEHINsVY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кзОЩΡжжюыД():
    value = 240296
    text = __import__('base64').b64decode('bkt2emZUbEdfXzkyTWw1UTZfNEE=').decode('utf-8')
    if False and True:
        498
        _dead_6959 = 505
    total = value + len(text)
    return total

def _ИΟйΧηΥМвйиЦйУУη():
    if 21 * 74 < 0:
        859
        483
    value = 761880
    text = __import__('base64').b64decode('UUI2OE01MzdlRWVGaDRpWDM0QVI=').decode('utf-8')
    if False and True:
        307
        pass
    total = value + len(text)
    return total

def _ЬйαΩвъшΞχδу():
    value = 445375
    text = __import__('base64').b64decode('S2RlcllsNUJOSE1vVGN3dU1VZlA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        981
    return total

def _йνΟХχАΝΥСβмКηд():
    value = 343517
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHf1dmg31/oKDyGJwUOhFRA43ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 70 * 27 < 0:
        _dead_8518 = 650
    total = value + len(text)
    return total

def _яΔЭρυνВΛСζетΗΙΑ():
    if False and True:
        618
        562
    value = 805870
    text = __import__('base64').b64decode('cTNWQjQxYnVXWVB0UmZYRWR6ZmM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_9074 = 612
        _dead_8135 = 410
        pass
    return total

def _θροНнГыηψл():
    value = 949717
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx7GWGkTzaUZFS6InFzFE3QYvXY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒоΙмυжхклΞэяυ():
    if False and True:
        _dead_4485 = 205
        pass
        pass
    value = 408571
    if 42 * 10 < 0:
        170
        584
        pass
    text = __import__('base64').b64decode('dDNmNHBvS3RaYm05ZURhR2UxbGw=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _юλРδΔсΟоцθ():
    value = 61460
    if 79 * 95 < 0:
        732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnexaHAQrfAPaz+NmWeRZj885Ws='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        870
        _dead_9985 = 35
        467
    total = value + len(text)
    return total

def _нХβνТΙψσψΑ():
    if len('') > 0:
        734
        287
    value = 738061
    if 99 * 25 < 0:
        pass
        682
        pass
    text = __import__('base64').b64decode('WktJNnpTTTJ5bXBnb1g4eEV4U0o=').decode('utf-8')
    total = value + len(text)
    return total

def _εΕβςВидъ():
    value = 371941
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzbzYXga6IE2bSKM8Q+1ITcj1GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _абΦбрФыΕΑз():
    value = 636717
    text = __import__('base64').b64decode('Zzh0V1ZNbmJpQlhhRUVEN1JPNzU=').decode('utf-8')
    total = value + len(text)
    return total

def _ыτкΦδαυв():
    value = 661795
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HA3SQVsy+5E8IAeg3VGkYTwq9ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        174
        pass
    total = value + len(text)
    return total

def _ыНЛΥЖбΕВΞгννΡФ():
    if False and True:
        pass
        455
    value = 21700
    text = __import__('base64').b64decode('eWo0cmRJNFFsRFBiX0JPNlZpc2M=').decode('utf-8')
    if len('') > 0:
        pass
        pass
    total = value + len(text)
    if False and True:
        845
        pass
    return total

def _ΠрΜЖιЧКΞАэφеПб():
    value = 103640
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HH3xQmcM9b9VEzCL2GeEGRwl4Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        326
        _dead_4361 = 600
    return total

def _сΧвχнζФΦΨзΚСЖ():
    value = 459608
    text = __import__('base64').b64decode('eHlUT1EzMlJmaGVXMFBlMVFuZ3c=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_2152 = 987
        702
    return total

def _СгЧξземъξοΘлКοζΛ():
    value = 409800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXznN1Jt5JpWEwr7+3SqZgp972Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МЯθювΦАзηнΜΜΙ():
    value = 944846
    text = __import__('base64').b64decode('RGlhaDl1SGs4U1hUZndxb0FQWnM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜНπкеΚиоΗΧЖгξμЕз():
    value = 960047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQS9TFw81p0CCw6m0lKiJRUq7zo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 25 * 99 < 0:
        963
        pass
    return total

def _γАζσпмжйгΦθ():
    if False and True:
        _dead_9263 = 348
        pass
        114
    value = 252182
    text = __import__('base64').b64decode('c3VqeVJ4d3cxVFoyWWJpaldwUkQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_5045 = 391
        pass
    return total

def _ΣεςΧфοГΠΖьπйНЯ():
    value = 301625
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzrGXkIyzLgnHQuozHLIGC0Fwlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4709 = 660
    return total

def _зγΖШцХСхЫО():
    value = 193734
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mwi3bHMt+KkRGQak306SMzEBxUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩΟдЧΗгΔЮτΨЮοΣΚ():
    value = 620925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EyDJQnY+7oQyMS6uwkO/Ax8q/Ec='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
        pass
    return total

def _ςШΑξАΩΚΦфпФл():
    value = 431902
    text = __import__('base64').b64decode('ZHhUSXkyV1lTMFFpSDJkdEtaN2s=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if len('') > 0:
        _dead_4378 = 847
        _dead_8879 = 971
        pass
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()