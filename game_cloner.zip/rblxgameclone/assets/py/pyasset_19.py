#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__(__import__('base64').b64decode('cmFuZG9t').decode('utf-8'))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _БВэΕΟεэζхиъСШΩ():
    value = 739461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESHyYQkG+6MUNViv6nSlOXQ58kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        321
    return total

def _νбтЬЕУЦζΨтриΑ():
    value = 205105
    text = __import__('base64').b64decode('cHhZbmVVdGNvdHdVOE9SOVZYcjk=').decode('utf-8')
    total = value + len(text)
    if 17 * 81 < 0:
        _dead_2314 = 839
    return total

def _ИΝЩЖΥйτΟΗхυя():
    if False and True:
        pass
    value = 633319
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRfMd14T2Z81Ihnz2V23GgsMzWM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жσВΛэХηΟмΨщМВιΙ():
    value = 467782
    text = __import__('base64').b64decode('aEcyRzRSRWo2M05JcEpuQjM2NUY=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1873 = 744
        _dead_5732 = 517
        _dead_6106 = 161
    return total

def _еСΙЯКΕдΕΕ():
    value = 960444
    if 73 * 86 < 0:
        _dead_7960 = 253
        3
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx/vdlsuqYk8MCOl/3/JYjYL5Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 32 * 60 < 0:
        144
        570
        pass
    total = value + len(text)
    return total

def _жкΞГιΛЕиЩБпδРлш():
    value = 897696
    text = __import__('base64').b64decode('VGxHajBVRmFTR25KTF9UOU9lMlM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨφοςКыαЕд():
    value = 72343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kwv1Y1go579RE1yy3kyVZz8ssl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡΔΕΔнкЮЩй():
    value = 19883
    text = __import__('base64').b64decode('VEN0bUhiQmZhQ2t2c3ZiYzROMHk=').decode('utf-8')
    total = value + len(text)
    return total

def _ГλΖκюЮВтωАΡρηЧξ():
    if 10 * 28 < 0:
        414
        _dead_2023 = 557
    value = 166865
    if len('') > 0:
        201
        pass
    text = __import__('base64').b64decode('aWVTSl94eVZva0NmMURyZEFOZU0=').decode('utf-8')
    total = value + len(text)
    return total

def _γΣЮЛйλеιΩγΡАЛщвэ():
    value = 453928
    text = __import__('base64').b64decode('b09QV0Q0OXVMN3BuSXhFd2hSVXI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣξΒυрνМгпжб():
    value = 60750
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IAPLYGUKxpgECAarmlfGLTV862s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оιкЧπΨθЩшЖυ():
    value = 878077
    text = __import__('base64').b64decode('aGJvTkl0VGZRZEFXYmFSZnkzaHA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖσЗвЙКСЧ():
    value = 903283
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DiPRaQUyxrs7Izyb+3yqPwAOt08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИηнζбκηΜт():
    if False and True:
        pass
        787
    value = 384106
    text = __import__('base64').b64decode('UnJTNmRmZm5DREl2c01ETXh5anU=').decode('utf-8')
    if False and True:
        _dead_5422 = 353
        328
        294
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_3784 = 724
        _dead_3546 = 5
    return total

def _ЩρμЧЖАЦхγηο():
    if len('') > 0:
        pass
    value = 521058
    text = __import__('base64').b64decode('ZXRubnJSRHpXcTNMUVlVNEdpU1M=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        _dead_1664 = 707
    return total

def _ЕФΧдфУФуМЮЮПииΘ():
    value = 148166
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('E3vhaUE8roMnNRbw+ma5ZTEb6E0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 74 * 75 < 0:
        pass
    return total

def _ιΕРΙЬмьл():
    value = 314427
    text = __import__('base64').b64decode('UlBLYktmeGtSWjRuMlQ0M0IxZzc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡιζыμнзеνΗгΩθПη():
    value = 764025
    if len('') > 0:
        _dead_2600 = 17
        966
    text = __import__('base64').b64decode('UXRJNW1KbzZlZ1doNm1EWkNIT1k=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_2988 = 45
        189
    return total

def _ъΚЧγюлЪαЦΚАγ():
    value = 822296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('H3/XVAU12ackMgqPmVSWBh186F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞгоЛЙмθжΘ():
    value = 642152
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HynXSV0JqZhQHD6n7XjFAzF46jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жДыκνИРяΠτ():
    if False and True:
        pass
        793
        pass
    value = 12370
    text = __import__('base64').b64decode('dlZRSklfR3NTTTM4TWpXdV9VVng=').decode('utf-8')
    total = value + len(text)
    return total

def _σΜΗЦξЙρΠΓькЙπΕυ():
    value = 981613
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3z8WVwg5vkobjmF3X2GEAR2tmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξШАФаХΥщРΠш():
    value = 804384
    if len('') > 0:
        pass
        _dead_4528 = 621
        198
    text = __import__('base64').b64decode('VkRVNEhRMW5rdTBCblZiTVNRM3A=').decode('utf-8')
    total = value + len(text)
    return total

def _ωГκЬхκрцБ():
    value = 565870
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQKzN2U3p/85EwCZ/26+ZwEOxTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩВΨБΥΧшпΓЯмψ():
    value = 875950
    if len('') > 0:
        190
        pass
        934
    text = __import__('base64').b64decode('YXd4X2o0MEExVUxpY1E5SDJwN0w=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        839
    total = value + len(text)
    if 72 * 36 < 0:
        664
        490
    return total

def _ЩйνГξЪοюъюБδЯ():
    value = 276932
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAbBf1Y0zfoObQL6wFqWA3J21Fg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шСпшТСΨрΛрοЧЯ():
    if 3 * 41 < 0:
        pass
        171
        pass
    value = 432393
    text = __import__('base64').b64decode('Q0JoQzZTRUdsR1hoVzROSGdnSDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ррΖЗгНзЙ():
    if len('') > 0:
        pass
        pass
    value = 467539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MhbXY2MI9IYqbRyp33y6AAMq6HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1197 = 784
    total = value + len(text)
    return total

def _тЗОцрθэЬДπξпР():
    value = 215237
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mzq0egMU+v8JIxe10WWbPQ01w0Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖтТκΑЦъμЖшЙЬын():
    value = 694463
    text = __import__('base64').b64decode('ZFZWbUFaand0NEhGMno1S09LNWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫюйΓξлΒψΗΚΔЙΤшГ():
    value = 492505
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASy3Yng9zLkGYhuaxQCkbRAAwDg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χΝσцзьνуμ():
    value = 727508
    text = __import__('base64').b64decode('SU9aUmZWaWVjS0YxV2Y3bkxGQ08=').decode('utf-8')
    total = value + len(text)
    return total

def _ХρНХκЗυбΑБсξΡ():
    value = 144945
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTaxYlIbyo0kNgSX0kSXEXV85lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πρЦщЛТШАωЮЕАυьΥ():
    if False and True:
        pass
        468
        999
    value = 21652
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NAjpPgU3qp0tYj2VnUTDMg0OsUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σЕΙчРεбффΖΖОоЩ():
    value = 803492
    if len('') > 0:
        _dead_2397 = 727
        _dead_5493 = 737
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETnIf2Ie0Llablm2+Xy/CwEnwTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΓОрлВсЗБΓτезφ():
    value = 239987
    if len('') > 0:
        798
        373
    text = __import__('base64').b64decode('TmtOQ3RLSmpjWDFnTmdJcWhSaWE=').decode('utf-8')
    if 81 * 19 < 0:
        pass
        pass
        _dead_1775 = 381
    total = value + len(text)
    return total

def _дχξоΗМζСΜГтЭув():
    value = 61284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTu1eWYVyZEULwmM6QGZYhUFzWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩшСυκЪЮЗς():
    if len('') > 0:
        _dead_7143 = 543
    value = 178976
    text = __import__('base64').b64decode('ck42Wl8yV19EcFo3NE5xcXJIS2w=').decode('utf-8')
    total = value + len(text)
    if False and True:
        864
        pass
    return total

def _ΖЕΘσЙЯЮХнЖЭΨ():
    value = 959789
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDXMZHU26pc1YiiT7lK5YXIE60I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧφсΤλВЦδΚτзθакχр():
    value = 313364
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IyPdPGgG1IIJKV+H71qIOQkYw08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЗХйщλЬИοМαЯγΝГΝ():
    value = 422912
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgiwQ3drxLAzAyCLxnqfDBoY1Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        442
        550
        _dead_4975 = 401
    total = value + len(text)
    return total

def _ΡхЙоииΣкП():
    if len('') > 0:
        _dead_1795 = 803
        pass
        705
    value = 959672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NB/sZ1IMqLxXOxm26gWKFSMD5Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        376
    return total

def _ςУΝΕΑσйφхΠЪσλщюН():
    if 45 * 3 < 0:
        pass
        946
    value = 790102
    text = __import__('base64').b64decode('RzZFQXpYbHhiOVJDUVljVmZmNm0=').decode('utf-8')
    if 24 * 53 < 0:
        542
        pass
    total = value + len(text)
    return total

def _γяυψИεΤсПωЪΛ():
    value = 271102
    if len('') > 0:
        pass
        _dead_8009 = 892
        _dead_5221 = 981
    text = __import__('base64').b64decode('WHBJVGRTN2tRdVRNaXVaRTVwdWw=').decode('utf-8')
    total = value + len(text)
    return total

def _δефΒφДКак():
    value = 930121
    text = __import__('base64').b64decode('UjM5SlVQY1RoSEFGYWpHOTV6MFc=').decode('utf-8')
    total = value + len(text)
    return total

def _ДκДУεзфДΡαъ():
    value = 659574
    text = __import__('base64').b64decode('QVpKZ3ljS1lFSXl0WDlabGxUb0E=').decode('utf-8')
    total = value + len(text)
    return total

def _ъчаΤыГЙзξ():
    value = 7057
    text = __import__('base64').b64decode('V2s5ZjV0ZEVVM1RsZ3VxYkFhTmc=').decode('utf-8')
    if len('') > 0:
        47
        468
        _dead_1631 = 6
    total = value + len(text)
    return total

def _ВθЩψГжΥλΘНΠξИЫуΤ():
    value = 714162
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhrbWF0X8oATABaV4FKjJT8utWI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шИРυΔрСР():
    if len('') > 0:
        pass
        786
    value = 511090
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MyfVTHtp74oKKz7xmHe2YQsk4GQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4302 = 714
        196
    total = value + len(text)
    return total

def _μЮΗαбоξТοЦтο():
    if len('') > 0:
        737
        pass
        pass
    value = 213275
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JzzVfAltyZkTAyGs/wCgYDU10Dg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 13 < 0:
        pass
        pass
    total = value + len(text)
    if 20 * 14 < 0:
        _dead_1578 = 831
        _dead_4917 = 721
        339
    return total

def _ΑбΚωαяъΤΕ():
    value = 70057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCPhV1hv94dbFRf6nlupMSMm9mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уаОихшΟрПμИФцΩИЦ():
    value = 21818
    text = __import__('base64').b64decode('UEw5cWhTdWlfSXdfNDVMQ0lsNkU=').decode('utf-8')
    total = value + len(text)
    return total

def _δуΣοФΙяЧЫсκ():
    value = 842207
    text = __import__('base64').b64decode('REtKeHl6dDZDaXFib0NWamJvcFQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_1706 = 604
        pass
        pass
    return total

def _ΕЮΤΕКηХΥπе():
    if False and True:
        878
        81
    value = 810456
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDbdP3ItqZopKym27UK1HSh+3Hs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 78 * 4 < 0:
        pass
    total = value + len(text)
    if 10 * 8 < 0:
        607
        207
        794
    return total

def _ΟΠжаЪдΞигИщζηΜЛΒ():
    value = 864561
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CRXbPkA4qp8VHVuU60KdDT8b/Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХΔЪаыГгρЙ():
    value = 791791
    text = __import__('base64').b64decode('bkNjTElscWgxV2REdjg2SnhHQ1k=').decode('utf-8')
    if 86 * 21 < 0:
        804
        _dead_8448 = 875
        pass
    total = value + len(text)
    if len('') > 0:
        724
        _dead_2213 = 911
    return total

def _АХчьΧЫюβκ():
    value = 626363
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CnfxbGk99rsRG1mA3kKEEQkq3Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΨυШсλΕчЫΠ():
    value = 926990
    text = __import__('base64').b64decode('b2dKRl9JZFEwMkdtV2JyZUlIMFI=').decode('utf-8')
    total = value + len(text)
    return total

def _йΠяγЦжПАΦβКεлΦω():
    if 59 * 51 < 0:
        703
        462
        _dead_9541 = 915
    value = 675996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh70OAkB5p08LCz13X25bTF472s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξυХыζΡалУΘп():
    if 62 * 21 < 0:
        82
    value = 773924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAbFSAQL1oBUCVySxlmKGy4a5lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эвхЭΞδΚθМΙψшυ():
    if 86 * 6 < 0:
        pass
        pass
        597
    value = 675489
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHmwbGsv7746NC6h7UfABzZ2sVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΣΨиκΗЩоΝπβΒОхФъ():
    value = 933228
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Az7tYmEL5Lkobxa3xkGdYgE2xUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _φσηΖъщэейдΛ():
    value = 856756
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jx/sTAMt1LolMTyR3H7APCki/lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΜΥΤяуФЩН():
    if 14 * 41 < 0:
        pass
    value = 94754
    text = __import__('base64').b64decode('UHhEYmM3RHNxaWs5NzQ4Vkh3R28=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ΦьЯещЕψшσИξд():
    value = 811435
    text = __import__('base64').b64decode('b2hNUlcyeVp3NngzcUZmVENqbnc=').decode('utf-8')
    if 14 * 44 < 0:
        270
        _dead_6839 = 92
        56
    total = value + len(text)
    if 93 * 16 < 0:
        pass
        970
    return total

def _ωКЖяΙФχхРΞгΝюηΦψ():
    if False and True:
        623
        832
        pass
    value = 697103
    text = __import__('base64').b64decode('UzRfZ3BXYU9zNGxWYnVsSmtNcVg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΘΦсΕАьИМΒЕΛΧ():
    value = 796025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ECK1eFw11LAyNTC64HinN30761E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зξтЪΧΠζод():
    value = 349240
    text = __import__('base64').b64decode('ZVhpbmNGcWhsdjEwU3FZZ1JZQng=').decode('utf-8')
    total = value + len(text)
    return total

def _бИЙαЭψкγΕл():
    if False and True:
        228
        589
        pass
    value = 268458
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IH71XX8pya07AjaG20KJLXIa0Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_1085 = 366
        _dead_7338 = 400
        117
    total = value + len(text)
    if 48 * 21 < 0:
        249
        pass
    return total

def _ЖΨАΔЬΗеδ():
    if len('') > 0:
        _dead_3810 = 736
        pass
    value = 133828
    if False and True:
        20
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgyyRUhp7IcRAiyL5n6mACMo6ng='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 71 * 34 < 0:
        pass
        594
    return total

def _ЙΛΛςекΦп():
    value = 885087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CQ7VY2480v0BDRv7x1ypMTQL/nw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤгηςΩдЪФуρв():
    value = 105728
    text = __import__('base64').b64decode('c3dOTzN4UkRFUDU0bVBuRFJfQXA=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    if len('') > 0:
        _dead_5022 = 820
        pass
    return total

def _ΦчкоΨλΨθфΗΠПзию():
    if 7 * 93 < 0:
        _dead_1978 = 557
        261
    value = 747218
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('By6ySldu6bwLblyP7F7EEwM9/HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪοжΘхπкοΡхяэв():
    value = 987215
    text = __import__('base64').b64decode('SUFCNnB5Mm53SDRiejFUdkRtaGk=').decode('utf-8')
    if False and True:
        pass
        pass
        884
    total = value + len(text)
    return total

def _буΚтпЛцгΡс():
    if len('') > 0:
        pass
        pass
    value = 563686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jw7FfmAjyP0paDWN23/JHSIF8GY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σУЫρπЗЙθΥΦшПξч():
    value = 571662
    text = __import__('base64').b64decode('QjFDazdOR21Hc0ZpTFlvTUt6d24=').decode('utf-8')
    total = value + len(text)
    return total

def _ШщθдΠИжωануγζ():
    value = 487743
    text = __import__('base64').b64decode('T2xBTXhvNVpOQ3JRZ3FpWTJuTWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _шΠУΞΞГΣщУфыеЖΓυ():
    value = 277922
    text = __import__('base64').b64decode('cUtwOGdpQWlOZkxNN3ZjeU94QU4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΤΜцΧжκд():
    value = 299219
    text = __import__('base64').b64decode('eWpGd2xQbmpETUpGWmpJTUwyS1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧвκиРЪΝνх():
    if len('') > 0:
        _dead_9538 = 257
        _dead_2942 = 49
        _dead_9163 = 490
    value = 555268
    if len('') > 0:
        _dead_3442 = 841
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LA3iYQgK2KczFiiKxWW6IB897mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_6689 = 477
    return total

def _χεςлЬγφζю():
    value = 639586
    text = __import__('base64').b64decode('c3FzOFlqTnYyRmd6Zll4dDV4dGs=').decode('utf-8')
    if False and True:
        _dead_6594 = 128
        pass
        532
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_5357 = 211
        557
    return total

def _хЛгΣθндЮчτхγ():
    value = 876318
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyLRTXwyq4s8ADyA3l+yAwMX0mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 31 * 71 < 0:
        _dead_8304 = 753
        _dead_2369 = 802
        475
    total = value + len(text)
    return total

def _зялВаъЯюηΞω():
    if False and True:
        pass
        _dead_7962 = 688
        pass
    value = 135462
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD3HVH0W2f1SAh+GwHi/Fisqy2g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ογуαУΝТЧΚΒфЮ():
    if False and True:
        _dead_1067 = 740
    value = 55248
    text = __import__('base64').b64decode('Tkg5WUVXTEJjazZRVGg4d1J4aVY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΚδшΙсνФβΑуθФВ():
    value = 680137
    text = __import__('base64').b64decode('SlhaQnlraGQ4UEFRVllteUl4ek4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЩпВюρоεΓа():
    value = 917664
    if len('') > 0:
        965
    text = __import__('base64').b64decode('RlloUkVZZzc4SkswSWloQUZVb00=').decode('utf-8')
    if 26 * 79 < 0:
        _dead_4011 = 596
        _dead_2012 = 230
        _dead_7533 = 773
    total = value + len(text)
    return total

def _иКЛЬЮОяаЕοΣе():
    value = 218611
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AT33Qwdq1bxTOCHz8nC4Lh866kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_2323 = 859
        797
    return total

def _ншΟГξЫξЖ():
    value = 80447
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjXTRQUN2YoIPgKi7A67BXYF43Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΒφΦнИЖΗζ():
    if False and True:
        382
        pass
    value = 539496
    text = __import__('base64').b64decode('WnBRVm9VaG83WXJvZGpVYkRBTnc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        561
        pass
    return total

def _πыςЩВΜйЛΧЕыкσйгВ():
    value = 433165
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LS2zWlswzKc6IFjyx3zHDRQLt3s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if len('xxxx') > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif len('') > 0:
    pass
    _dead_3760 = 223