#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__(__import__('base64').b64decode('c3RyaW5n').decode('utf-8'))

def _ζюПσтЮсф():
    value = 23705
    text = __import__('base64').b64decode('RUhZWGlKTFIxZElfQmhXRmg0RWY=').decode('utf-8')
    total = value + len(text)
    return total

def _нχуυХрΣθ():
    value = 914052
    text = __import__('base64').b64decode('dm9GcUtjZHNaZTRxdU9OXzRjOG8=').decode('utf-8')
    total = value + len(text)
    return total

def _шПИξΣΔΣПГТΩк():
    value = 771238
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDvWXEANyY1UMQCB5lChNR94sms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9413 = 807
        pass
        _dead_4005 = 115
    total = value + len(text)
    if False and True:
        _dead_7359 = 825
        pass
        pass
    return total

def _МηыσвΓБЕЦψМТБр():
    if False and True:
        363
        _dead_1029 = 874
        287
    value = 268309
    text = __import__('base64').b64decode('UF9xSWJmcHpUdklyUFdfd0FCY3U=').decode('utf-8')
    if 92 * 100 < 0:
        pass
    total = value + len(text)
    if 49 * 65 < 0:
        _dead_2534 = 489
        600
        _dead_9493 = 764
    return total

def _ΧЯτгδНБηΥ():
    value = 855920
    text = __import__('base64').b64decode('QkFjS09tUFVBVHNwdDZ0UFFhSVU=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ЙΟΖЗαлΤПΛадιПМж():
    if len('') > 0:
        pass
        734
    value = 992710
    text = __import__('base64').b64decode('c3J5TEV6cTlzTlhrTGo1dUlxbTk=').decode('utf-8')
    total = value + len(text)
    return total

def _дбрэмβэЫэ():
    value = 985719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EjXDSwIc+qUoMSGKy1DAbCh6yEc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙΓрРиμтγχα():
    value = 177998
    if 48 * 77 < 0:
        pass
    text = __import__('base64').b64decode('ZFBpdjVGSHExYlN0OVJzdG5HQWk=').decode('utf-8')
    total = value + len(text)
    return total

def _ГОδΘчбΧяУМΘщπеΡ():
    if len('') > 0:
        pass
        102
        277
    value = 146408
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KHfpZnc79KUBPjihyQ6FAgkO014='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аЪΥФкμδфД():
    if 97 * 89 < 0:
        522
        pass
    value = 123823
    text = __import__('base64').b64decode('VGpjOGFmWFA0OUVBbndkT3pXMHY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝΓтЛμΧμйΤщЫУь():
    value = 865191
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CgzKbAcV0vkGKlaL3XW1bAMj5UY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 41 * 6 < 0:
        _dead_6852 = 155
        pass
    return total

def _ыκИойЖωМοХ():
    if 20 * 67 < 0:
        pass
        pass
    value = 110991
    if 97 * 65 < 0:
        _dead_6342 = 271
    text = __import__('base64').b64decode('U3lTckJYVUxwendXaG9VdWpndDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ТвδаψεсЙГщХφςпξλ():
    value = 122172
    if 28 * 34 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KBbIe1AL5JkbDyatznLGIAl6wlw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        311
    return total

def _νФсΣЙΖСο():
    value = 281766
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KwTgXQk79oMpLSCw336fbSsktns='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 10 * 25 < 0:
        _dead_6657 = 580
    return total

def _ΦтΒοнДγΠβπБβ():
    value = 112395
    text = __import__('base64').b64decode('bGVCeTNWMGVxcTM0bDNxTlBHS2Y=').decode('utf-8')
    if len('') > 0:
        _dead_8515 = 156
    total = value + len(text)
    return total

def _ЮдΞΟλфθσΠЧКб():
    value = 686090
    text = __import__('base64').b64decode('RURsdUs3UGpWY1pncUlwQlh1Q1M=').decode('utf-8')
    total = value + len(text)
    return total

def _РμΡЬюбщσΚФВЭшςН():
    value = 769999
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwzqamMb+ZFQMV70mGOGEzEh/Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4449 = 513
        _dead_3013 = 938
    total = value + len(text)
    return total

def _ЗΑуЪФΚЫЗΙιаΕлΖ():
    value = 776367
    text = __import__('base64').b64decode('WUVmRGRaWTVuOXlxN2FCNnZyc0s=').decode('utf-8')
    if 4 * 45 < 0:
        pass
    total = value + len(text)
    return total

def _эμουΗНσМмщЖщ():
    if False and True:
        793
        _dead_5322 = 509
    value = 829989
    text = __import__('base64').b64decode('eWlxXzZQQkNDREdnYVFBZldxNFE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        685
    return total

def _ΧΖюΡьφйЦγΠ():
    value = 360727
    text = __import__('base64').b64decode('T3ZQQWVWUDNxOHdneGg5bGxPWUY=').decode('utf-8')
    total = value + len(text)
    return total

def _шкΕΞщΝδт():
    value = 173172
    text = __import__('base64').b64decode('RW03bEZIWDBrOVJmUUY1dkdmcDY=').decode('utf-8')
    if False and True:
        _dead_5717 = 918
        pass
    total = value + len(text)
    return total

def _ΟоΕΑΛΔνΧΨечрЕА():
    value = 781760
    text = __import__('base64').b64decode('WUpWb0xjWHZXcFVGOVp0bkNVQ2o=').decode('utf-8')
    total = value + len(text)
    if 61 * 15 < 0:
        557
        _dead_8314 = 10
    return total

def _ЮЖυьψМйечцбшкΦ():
    value = 570034
    text = __import__('base64').b64decode('c3VwSDBKRmdnRmRRZFpidEdhOV8=').decode('utf-8')
    if len('') > 0:
        _dead_1980 = 638
        _dead_2157 = 726
        _dead_3827 = 322
    total = value + len(text)
    if 92 * 80 < 0:
        pass
        _dead_7695 = 265
        307
    return total

def _ЯМодΨΘПхРЖΨΛ():
    if len('') > 0:
        534
        852
    value = 510955
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NgvwZGUu/b0lG1mnzVSIPTcA8F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξΤМυхΠвΜΩЭΚЗЪυ():
    value = 284447
    text = __import__('base64').b64decode('dzBiYnc3Z3NzZU1HdXY5RVZfb3Y=').decode('utf-8')
    total = value + len(text)
    return total

def _νДфЯхОσОΚ():
    value = 753025
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hyz2TVgQ0KUibC6Q+kHHMio7zzs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πΕнщАдввХБηМчшΒΧ():
    if 84 * 61 < 0:
        _dead_7812 = 645
    value = 266184
    text = __import__('base64').b64decode('SDNtWUU4eU5xWVZ4cDVFS2tZdFk=').decode('utf-8')
    total = value + len(text)
    return total

def _ηΨэфβηδъΧ():
    if False and True:
        _dead_3942 = 926
        pass
    value = 431355
    text = __import__('base64').b64decode('VXlyV1lpWnhROWFTQXpzUWdEcGM=').decode('utf-8')
    total = value + len(text)
    if 29 * 22 < 0:
        _dead_7486 = 368
        pass
    return total

def _ОθМчΧоньж():
    if False and True:
        pass
    value = 244061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD/GfWAzzbAIPyzwwUGhMh8WtFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠΨгдμΩασТНЙΩΦу():
    value = 177614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fw7JR3oK36YsLlqA5kXAMSQm7Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        174
        pass
        286
    return total

def _ΕызкρпφккГЕ():
    if 77 * 36 < 0:
        _dead_6344 = 885
        _dead_6283 = 765
    value = 874575
    if len('') > 0:
        _dead_4470 = 115
        _dead_6232 = 544
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DQLoOWs83Z1RFCv3zmK8JXAHsls='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бКνЖоξПхνμДфτд():
    value = 795362
    if False and True:
        pass
        296
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx/UZl4Q2LEFAzmN6VeeIyAjzGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4474 = 227
        _dead_7241 = 935
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _σБэВφШмξПι():
    value = 902148
    text = __import__('base64').b64decode('REJEYlFfRXFKejRzaVJiVFJ3OUE=').decode('utf-8')
    total = value + len(text)
    if 22 * 71 < 0:
        _dead_7194 = 77
    return total

def _ΦЮηζΩыйςъΜшуЮЩМΤ():
    value = 792386
    text = __import__('base64').b64decode('T2ZpaElPUXE2VzlPNTF5c18xM1c=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    if False and True:
        _dead_6785 = 115
        946
        pass
    return total

def _хηЮеΦΗБкйχЗючΨъ():
    value = 225750
    text = __import__('base64').b64decode('dU9VSTZlMmUxcklHbFFFR2JnRmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ψνωΔЭыΗωЧюЦСΕВε():
    if False and True:
        pass
        983
        _dead_2893 = 850
    value = 927667
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JnbQUWNh2qUbbgSI/1zHGhU4tmk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_3955 = 794
        63
        pass
    total = value + len(text)
    return total

def _ЮεεУαθΞБЮζо():
    value = 987710
    text = __import__('base64').b64decode('aEpOYkhZTTlOMUdMdndZR2R4U20=').decode('utf-8')
    total = value + len(text)
    return total

def _ΝШοζькхВΧ():
    value = 620675
    text = __import__('base64').b64decode('WkUyVGxtc3pNQXFDcERTWjBlMWg=').decode('utf-8')
    if False and True:
        _dead_6506 = 54
        _dead_4037 = 157
        pass
    total = value + len(text)
    return total

def _ξβσρмДσРУЫо():
    value = 754524
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSTbSHco24QxIg6Q2l2/LCh+1GI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 73 * 69 < 0:
        _dead_8121 = 162
        pass
        _dead_3200 = 981
    total = value + len(text)
    return total

def _цгЙПУωΡτΘΝΟжхЩζТ():
    if False and True:
        pass
        pass
    value = 674917
    text = __import__('base64').b64decode('T05zQnVjX2dTc1NkTUYyNjR6bVI=').decode('utf-8')
    if len('') > 0:
        _dead_1170 = 635
        273
        771
    total = value + len(text)
    if 50 * 41 < 0:
        73
        608
    return total

def _ТжθςψΓνΔπЖ():
    value = 690679
    text = __import__('base64').b64decode('cGRCUHpsaXlRZGI2SU9LSENxaEw=').decode('utf-8')
    if len('') > 0:
        693
    total = value + len(text)
    return total

def _ΝИΤвЭηχЯмбσρ():
    value = 14429
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('I3uwfGUs7I4yCFuW93KJEg0C0ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χεβМΔЙыОеΝχгл():
    value = 563068
    text = __import__('base64').b64decode('a1lpVFY0SzNHNHhJb0dlcFpfY1Y=').decode('utf-8')
    total = value + len(text)
    return total

def _СψЛΛВΞдтΤσЙ():
    if False and True:
        pass
        _dead_6594 = 275
    value = 184970
    if False and True:
        851
        933
        _dead_3201 = 788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRvuYV1o2PAsDS6KygepNwAC7Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖпχНУΠΔΧ():
    value = 325296
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTzxW2kw9aYOAiuw4WG8LBYMyFo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _пΟюБнσНюФЫΨΓΞуωГ():
    value = 428513
    text = __import__('base64').b64decode('UVIxZGJqbkljWFNyUXBnYUpMeHc=').decode('utf-8')
    total = value + len(text)
    return total

def _еΜЙπιΑοЩΡПΔκββχт():
    value = 132776
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KjzTYAkc74wmNyD6+F6BbQYo3G8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _еωΗжщψЛΦΡ():
    if False and True:
        _dead_8427 = 95
        pass
        pass
    value = 345656
    text = __import__('base64').b64decode('YTlFd1V3ZWRmbnprZ2h5YnM2U0I=').decode('utf-8')
    total = value + len(text)
    if 85 * 90 < 0:
        319
        _dead_3855 = 75
        _dead_8624 = 696
    return total

def _здгиξΝχжцдΩоΦ():
    value = 670021
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSrlX1wP+oFUGAb660bAPC0rz3w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖтЕΖΛζΩεВоτρωΒΦ():
    value = 366584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Knq8Vgc26/ExMDCLmn/EHQAV8Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ждΠПΣγпνΡН():
    value = 144686
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQvhYl0215gyFh+U72OXBgN342c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ьнъПΥγъοЕХК():
    value = 74654
    if len('') > 0:
        16
        276
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nz7wZHcup5EyIBiHm1vGbRcB7j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙГОΗДТызζ():
    value = 186299
    text = __import__('base64').b64decode('UVBDRG5IVjFoQVlaRDBzS2xZZXk=').decode('utf-8')
    total = value + len(text)
    return total

def _пьЯΣβεεЕκгνΦ():
    value = 938523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nn/AZFcu7JAJYj+3mUC7BxI9zUM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗΨМΕртМθΨυЙъпβ():
    value = 223878
    text = __import__('base64').b64decode('dkJ2QkJDekE3N2kwYVlkTlhvU1M=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_8482 = 219
        pass
    total = value + len(text)
    return total

def _δПΣфцНщΩЯЦΛ():
    value = 53852
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Bn23YkA2/IsvADiEzU7EGAgN0mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оξΠЯтωДШμΠ():
    if 46 * 49 < 0:
        839
        55
    value = 491146
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Pwj0On4T+KAPbCiV/wSdbCx/7Fw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫΘΧμеλБΔяοοбЬЩ():
    value = 857281
    if False and True:
        _dead_7495 = 640
    text = __import__('base64').b64decode('d3Bua0lXSkw4S3FGbHl4cnNxRDE=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ΠιυβЪЭТфΣПВ():
    if False and True:
        pass
        pass
        _dead_1218 = 899
    value = 940666
    text = __import__('base64').b64decode('Sk5zWmVjUFF3VTRMTU1xSHVmZHE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦИТагΕυβονφ():
    value = 790127
    if len('') > 0:
        258
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mj/VY0Rh+75UL1+TwFm8PBZ+skM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_7750 = 179
        559
    total = value + len(text)
    return total

def _НΧФкξЩЫιжЩЭуΨΙсσ():
    if len('') > 0:
        _dead_5522 = 33
        682
    value = 157721
    if False and True:
        _dead_3181 = 143
        _dead_3125 = 60
        _dead_9435 = 316
    text = __import__('base64').b64decode('RlROZ3VGSVk2VGNVOEtzcjQxVlU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔΖΗДэщЪΔΣД():
    if len('') > 0:
        35
        pass
        _dead_7987 = 400
    value = 33113
    if len('') > 0:
        817
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDrqN1cN7pwXKQGs2ny3bXEg12Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _γэΝξυЭΣθ():
    if len('') > 0:
        269
        906
    value = 528077
    if False and True:
        _dead_1852 = 745
        _dead_7733 = 308
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSHhegYb9Ps1ADiOmAemIhci9kg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 97 * 4 < 0:
        601
        pass
        967
    return total

def _θωΧΦΗιЫйμρΜΑНφЩ():
    value = 378837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ADnCRno97IMgaVaqxGDHMxwkzmQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цγδГфΕроЦГс():
    value = 941132
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mw3HOkAP8q0hOTi24m/DIQInw1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иРΠгщаЮΓΖΝ():
    value = 500288
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj7jfwFsx54FHiS2nQ7DPBIj7Fo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЪяΦΔеζмцΩвц():
    value = 744413
    if False and True:
        _dead_1694 = 834
        pass
    text = __import__('base64').b64decode('bjI3eEVzR21kWlFaMTNjdXhGWm0=').decode('utf-8')
    total = value + len(text)
    return total

def _εηζβЮθρяδΗψЭ():
    value = 519704
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSe1fG5t269RaFet/1jCEQQ77Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еλинφхΩБПЕТΚχц():
    value = 728936
    text = __import__('base64').b64decode('TEdCZGZ5SmVJRldNZ3R5ajRWSXM=').decode('utf-8')
    total = value + len(text)
    return total

def _ψЩΕлЮθлжтΛΑ():
    value = 27286
    text = __import__('base64').b64decode('Zzg5VFBXZnFrRlQ4dzQwMUd3Uk0=').decode('utf-8')
    if 4 * 99 < 0:
        pass
    total = value + len(text)
    return total

def _КйГНфΚεч():
    value = 185339
    if len('') > 0:
        45
        101
    text = __import__('base64').b64decode('RUNhVUNPQlUxeGNqM1dlRHZUVjc=').decode('utf-8')
    total = value + len(text)
    if 63 * 31 < 0:
        pass
        237
    return total

def _πΚБΔшδΟВКзхα():
    value = 62202
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CBzLOlkXpqU6IC7x2V6DPgou6kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        807
        _dead_5555 = 551
        pass
    total = value + len(text)
    return total

def _ΝηФобΟУНωюсЙуэ():
    value = 747056
    if 58 * 22 < 0:
        379
        155
        pass
    text = __import__('base64').b64decode('enRzT0ZveGlDZ3pQcEE0MUVHX20=').decode('utf-8')
    total = value + len(text)
    return total

def _хψжζλΣαвζшρьΜ():
    value = 616708
    if len('') > 0:
        _dead_5025 = 997
        _dead_1601 = 509
    text = __import__('base64').b64decode('eXFBRHl0YUxVd1dZV0dyWGZJS2o=').decode('utf-8')
    total = value + len(text)
    return total

def _ВФыΙΝАФМКζЧпЗτΦМ():
    value = 324693
    text = __import__('base64').b64decode('c1FvODlqWlB5aFBsWVZnc1puQWU=').decode('utf-8')
    if len('') > 0:
        54
    total = value + len(text)
    return total

def _ΞΚФΚемтλурКйΞжΝ():
    if 89 * 97 < 0:
        325
        _dead_9323 = 37
    value = 144359
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EhvnZwAR0Zw1GBigx1i2PjYfyTg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 21 * 52 < 0:
        pass
    total = value + len(text)
    return total

def _ГлДХΤщрц():
    if 93 * 53 < 0:
        417
        290
    value = 355454
    if len('') > 0:
        pass
        _dead_9215 = 801
    text = __import__('base64').b64decode('VzdMN3dCdG9XTFVtNEgyNWtDZmc=').decode('utf-8')
    total = value + len(text)
    if False and True:
        446
        275
    return total

def _ЛТзΞиτцβи():
    value = 448779
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DwjjVGQL1Pwibh+rz2aiOD0972k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВЧβΒжΖψΚσуμ():
    value = 341990
    text = __import__('base64').b64decode('bjZldFhYMFB5VXVYYjladVlPMXQ=').decode('utf-8')
    if False and True:
        pass
        _dead_4543 = 113
    total = value + len(text)
    return total

def _кΞжиεЫΜΨЖы():
    value = 101914
    if False and True:
        _dead_7938 = 429
    text = __import__('base64').b64decode('R1kzT3I2NUJfVXZQMk9xMjhxbFk=').decode('utf-8')
    total = value + len(text)
    if False and True:
        742
        _dead_8715 = 876
    return total

def _ΛЯдСЙΧзΗгшΣ():
    value = 283171
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LDb8W3Uo6aEuPBfyx1S7ZgIQ1EY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λДИΑЬВΘн():
    if False and True:
        _dead_5146 = 197
        627
    value = 489880
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxzRPVgK/5wKNyaH/wWyHnA/smk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        841
    total = value + len(text)
    if 19 * 99 < 0:
        _dead_5116 = 394
        827
        _dead_3505 = 814
    return total

def _гιлЫΥγΜМΒ():
    value = 913271
    text = __import__('base64').b64decode('U2YwU0lRMW9XNkJrc1FnYlNjbVo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        579
    return total

def _хМИпТφλцΞεН():
    if 4 * 26 < 0:
        pass
        pass
    value = 267961
    if False and True:
        182
        327
        pass
    text = __import__('base64').b64decode('ZUFObkUwUzljckpEWjBfczQ3VW4=').decode('utf-8')
    total = value + len(text)
    if 4 * 85 < 0:
        pass
        pass
        _dead_9905 = 556
    return total

def _ВЧβЖЦΦДΝξсЩяπθтΟ():
    if False and True:
        _dead_9140 = 752
        _dead_6120 = 47
    value = 76094
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQreeHsU6ZgVMl7x0lWKAAAVz2M='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖШоεΙЙуτ():
    value = 993321
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiLqW0EG9JIyPyS12UKfGXZ50FE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _джΨτωζΦЦРςЬΘоΩу():
    value = 74299
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FArJSVoA9I8UaRuKywSfGj8D53s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЛсχεσлνРφтБΚκ():
    value = 687279
    text = __import__('base64').b64decode('dVBQOGx6bG9obnBSRTZxMWhVdW8=').decode('utf-8')
    total = value + len(text)
    return total

def _ВΘпεЗдζзХρе():
    value = 295441
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CS3ObHI6+LxSExiK2gWUHjwB5UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑыФβΚεΨβйКτчц():
    value = 587280
    if 69 * 53 < 0:
        pass
        _dead_4153 = 718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PH7iS38pxvotFBbz4WSkHgw37V0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ΑнЫЕΦηΟфигκгКΠюК():
    value = 699250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzfhYlwS+bk1Ljar5VSvBXUW9Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        968
        _dead_9235 = 579
        482
    return total

def _ΒχЬφЮюГУ():
    value = 688486
    text = __import__('base64').b64decode('a0lxS0RqVlI3czVZSzY1YlVnM3E=').decode('utf-8')
    total = value + len(text)
    return total

def _СлнЩпаΔянκ():
    value = 793433
    text = __import__('base64').b64decode('REZWblUwWloxMjA3Z0FESDV6Q20=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑпΑΒμрττεМψъΩ():
    if len('') > 0:
        31
    value = 506718
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCnjTFsPyLlTbArx41GFESg1sDY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2630 = 783
        448
    total = value + len(text)
    return total

def _δцωσФβУθΤΣ():
    value = 548912
    text = __import__('base64').b64decode('YmhadVdsTnhsTjhjcVFiYzRGZ1M=').decode('utf-8')
    total = value + len(text)
    return total

def _ψΩзΒГгδЦπζяψ():
    value = 933958
    text = __import__('base64').b64decode('UlR2TnFkMmNObGRmM0pVTnZUM3A=').decode('utf-8')
    total = value + len(text)
    return total

def _бьΟΥРΡμΓ():
    value = 23523
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LXrJQWMvqrARKA2L6VKKFj8osTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЦнηκхιэψφυЮΘβЗю():
    value = 221082
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiHPYXwByq0ybgey63nJGwQHtk8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮьяЖιΥγωΗΟеψыФДЯ():
    value = 256141
    text = __import__('base64').b64decode('RTdLRW1WN3NsTXVOaXBZR01KNU8=').decode('utf-8')
    total = value + len(text)
    return total

def _хюДΧКνЬθ():
    value = 823345
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FHrBe3I+05cSagiz2HShDRw6xjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оζΒΘТςШξНυπР():
    value = 676922
    text = __import__('base64').b64decode('bkZYalZZWjZ0UGFod3d2SDFqVDE=').decode('utf-8')
    if 29 * 42 < 0:
        198
        _dead_2156 = 709
    total = value + len(text)
    return total

def _жЙЪШРηДЪИφΚΝМв():
    value = 594812
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSC0eWsS8YQ1GyyX4nWCYB8F9HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _сξОΣνбхΔж():
    value = 82661
    if len('') > 0:
        403
    text = __import__('base64').b64decode('V3dYbEhmTlFkVjBoVDhiVVFFR0w=').decode('utf-8')
    total = value + len(text)
    return total

def _σнОоαРгйМ():
    value = 153724
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD3PSlNu06UKMgO1wky7Ey8E1jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τыэшиΦЗЯзнАЕТ():
    value = 943516
    text = __import__('base64').b64decode('T0E2ZUlxdzdMcVcyMHBaMDh6ZUg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        57
    return total

def _МЩНΛэиаМδθэζЙΚμθ():
    value = 906960
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NiLgTAIuzKUSEAqh21C5OgotyWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψиМωпВгΚхяΞаΘП():
    value = 502797
    if False and True:
        116
    text = __import__('base64').b64decode('bFE0d3hheE82X204VjdnbjM4d3U=').decode('utf-8')
    total = value + len(text)
    return total

def _аΩЙΤΒζтЩСэьлμУс():
    value = 355803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DnvVUVwjqYoHGQb2wVqjZRw7zmc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηκЙиΘЮλθГЕКо():
    if 92 * 48 < 0:
        498
        pass
        548
    value = 423249
    text = __import__('base64').b64decode('RGJsRml0NzJsX25wM2xMa25Xc0g=').decode('utf-8')
    total = value + len(text)
    return total

def _БлνΝΠуΛШтΛρ():
    value = 696519
    text = __import__('base64').b64decode('cXh6cWkwcTNFZ29jV0NIZjlSN0k=').decode('utf-8')
    total = value + len(text)
    return total

def _цψΟсσΘМζШоьς():
    if len('') > 0:
        _dead_8645 = 526
    value = 895792
    if len('') > 0:
        474
        pass
        _dead_4399 = 25
    text = __import__('base64').b64decode('YkFyWUc5ek0xQWt3Sldqb2ppVE8=').decode('utf-8')
    if False and True:
        510
        pass
        pass
    total = value + len(text)
    return total

def _ЕλζΙΑюдЦрГ():
    value = 374083
    if len('') > 0:
        pass
        _dead_9839 = 937
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyWwP2cGzaRTFSGp92yiYTN91HQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        733
    total = value + len(text)
    return total

def _ΗКΕъРΥτцПπгΜЭРЫ():
    value = 762444
    if 40 * 72 < 0:
        _dead_3728 = 139
        9
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MiLgTXtr+oAKMCyN+XGvFwgI1Fc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 5 * 75 < 0:
        740
        pass
        _dead_3929 = 98
    return total

def _ΧΩΨацЩвΘэгκщΝ():
    value = 689587
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FXrRVGYu0v41PQuVnA++FSN83Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _СψρΥУεЙчб():
    value = 163261
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBjRf2479qoTAwKO0nigLiI59H8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΛψЕρФоχνзΚΞ():
    value = 892083
    text = __import__('base64').b64decode('dFdrOG1TMlBHVmk5NjRkUFg0R20=').decode('utf-8')
    total = value + len(text)
    return total

def _ттЩиеζвΚιГНЯδ():
    value = 55128
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgT2NwER668JaFeP6liqJyB44jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΞτβсбχфЬφσ():
    value = 589576
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BnvDSgEw9KUkLDuv91CjAA8A6kE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДыМзФАξΒДςЦ():
    value = 909846
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ey7PXERhr4QiGSOl2w+YFx0q9Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δСчОβлЦхΩ():
    value = 514815
    if False and True:
        786
    text = __import__('base64').b64decode('U0x0bE1MWndyZ1RyVmROSGZBNjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯПιуησЛРλБΘюА():
    if False and True:
        pass
        _dead_6563 = 568
        457
    value = 52332
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyPvT2Qy/Zs1bA2sy1TBGC0X8j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δζоуХЗВχΠиьЙСΦδΘ():
    value = 462463
    if False and True:
        618
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DAHbPgk26LE0KFiIxQedBgsW3kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        458
        986
        pass
    total = value + len(text)
    return total

def _χΡЭСЕβьβΥпИшфΣ():
    if 88 * 78 < 0:
        pass
    value = 77340
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgHQZ2U/3IMOagSRzU+aLCo49UI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        197
        _dead_1005 = 102
        pass
    total = value + len(text)
    return total

def _υΧΘырωЖЫАчТсФ():
    if 47 * 95 < 0:
        668
        323
        _dead_2805 = 256
    value = 980612
    if False and True:
        pass
    text = __import__('base64').b64decode('VEFZVWR5U0szZXR1M21qNGxmdWI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞиηьηαБπэαΟΜΥе():
    value = 163483
    text = __import__('base64').b64decode('b1VvQ3ZqUllfTmVUNkZicWtHTG8=').decode('utf-8')
    total = value + len(text)
    return total

def _ωΟеМСИЪСъςхЗь():
    value = 170894
    text = __import__('base64').b64decode('alhUTHNlM0N0ejRPOGZyUzBYQWE=').decode('utf-8')
    total = value + len(text)
    return total

def _КδКЭяλнΠΡКМε():
    value = 926104
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MAa1SGY9wZ82NRmhw3PEYyh740o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дРνеΡЗшрιж():
    value = 953706
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KSPHWls0xvgPOQOv73iDPAcD8Uc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 79 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()