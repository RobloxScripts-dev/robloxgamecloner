#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njb3'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ХΖΧзмЮЯЕβδΛЦдΘИγ():
    value = 247354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgjtT2Y9pr4wIgb18g6dDTQb3Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 81 * 26 < 0:
        pass
    return total

def _ζΘЩζΜЗΝфθЙΙχ():
    if 87 * 69 < 0:
        pass
        _dead_8403 = 214
        pass
    value = 754866
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgvpXUcqxpkRNgvyw32lZnE+zXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _хΟΔΘУΛоеνеЩщСхΔ():
    if len('') > 0:
        pass
        223
    value = 751563
    text = __import__('base64').b64decode('YWcyZGRma2Nab3UwT09ielBtWmM=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        pass
    total = value + len(text)
    return total

def _ЗиοВοсΜΞбСδуΥ():
    if len('') > 0:
        pass
    value = 143417
    if len('') > 0:
        _dead_7055 = 569
        886
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQ7HSVkJ7Lo1Pyys52emBREfzjc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩгηХΒГВИζΥ():
    if False and True:
        967
        _dead_3407 = 480
    value = 259374
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ACXLS2Mzx7waIAvznkyyYA4awWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        pass
        pass
    return total

def _ЩвчьινфТЪыпΙΗ():
    value = 239831
    if False and True:
        _dead_9000 = 226
        pass
        _dead_8910 = 92
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjrPemgarodVNFv05k+bbTwfylQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        576
        640
    total = value + len(text)
    return total

def _ρгαГΠΙтξфτπЩВΦКΣ():
    value = 477996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgHGPEkTxIMzaSD1nm6YAxAY8kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦΝЮъбЫЮДυчΕЩы():
    value = 379081
    text = __import__('base64').b64decode('dU1WRVJBaGV2YnA1Z2VxQXNISWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _язХηφΡΒψгцШЮ():
    value = 607353
    text = __import__('base64').b64decode('RGc1dUw0d09yVHJnUVFaSlhYMlo=').decode('utf-8')
    total = value + len(text)
    return total

def _иъΘΙНщЪеο():
    value = 143196
    text = __import__('base64').b64decode('dmFFdVc1RThSeUhyMU5KNkw1Wmo=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4891 = 137
    total = value + len(text)
    return total

def _РΟχΟОλдΟРΙ():
    value = 209004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAmxdGYQ+JJaPiWi/F7BHwIZ/Vc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 25 * 42 < 0:
        pass
        pass
        72
    total = value + len(text)
    return total

def _ыьΨБЪъИыРб():
    value = 756574
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MA6yQ2Iz+4QnOV2sxnm8Bwwo/XY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 30 * 51 < 0:
        _dead_1855 = 671
    return total

def _мПστοΠΠЫ():
    value = 858146
    if len('') > 0:
        203
        _dead_9080 = 359
    text = __import__('base64').b64decode('Z3hoYTNyc0NHWDgzb2JRdzB3RVM=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _οзОχυΕГΝεпγИ():
    value = 988448
    if False and True:
        992
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERn0Ylk9r/8NOAOrmQ+hYygMvDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дΦΓγΡΘАεъδуЙωяУ():
    value = 824820
    text = __import__('base64').b64decode('UUV4M2NfNlUxdjYxVGx5cVlEdW4=').decode('utf-8')
    total = value + len(text)
    return total

def _БττЙμфэжеИΞΚ():
    value = 552231
    text = __import__('base64').b64decode('cFZ6MUdrWGhWb0I4QTgwYTM2R2k=').decode('utf-8')
    total = value + len(text)
    return total

def _ωАЕΦМςГгω():
    value = 535172
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyfLP2k01P06LDeJnwSEARM56Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝατσхыейЯσ():
    value = 963835
    if 10 * 71 < 0:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Czbrfn1gx7kNDC2B+m+dJTIt9k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        443
    return total

def _рΔъμгоКδΠэтюуФ():
    value = 991753
    if False and True:
        pass
    text = __import__('base64').b64decode('aGNoTUlkS3VRX2dHaEtBNVZlQ0w=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_4641 = 387
    total = value + len(text)
    return total

def _ςувπΡЦЕαΒф():
    value = 243768
    text = __import__('base64').b64decode('VGZHbEJHQjBFUVBneGVuZzU3SEE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΔοЕεηΧУχлМаΥΟъвΞ():
    if len('') > 0:
        pass
    value = 915673
    text = __import__('base64').b64decode('RnlTYkdLVnA1Yk9NS19sdzZYdDQ=').decode('utf-8')
    if False and True:
        pass
    total = value + len(text)
    return total

def _эΚςΙХкσжм():
    if len('') > 0:
        pass
        1000
    value = 415663
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FiHbdmEN6/sZAhWX41uKYncm8mE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДыЮФъθξΗΝМУЪОΒγκ():
    if 73 * 89 < 0:
        837
    value = 186464
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LSfbSwhr9bIqbFe2mH2pGwgjt1E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_2671 = 237
        878
        pass
    total = value + len(text)
    return total

def _ςкАΜЭЭШκфьнозΘ():
    value = 153863
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JizTOFxs6qw8AleXwn2lMHN35Tw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        614
    total = value + len(text)
    return total

def _γбЕЦЦТΞαтτдψУ():
    value = 32523
    text = __import__('base64').b64decode('Z05rdXJ0aXhuUmFVSUVZTlVxQ0o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        877
        pass
    return total

def _πЬДΝΡмжθуπ():
    value = 74262
    text = __import__('base64').b64decode('TUxQYlZFOEpqVGduY2xERUpvVzQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ФИΓΕξЮмБеТчУтЛω():
    value = 924924
    if 28 * 28 < 0:
        399
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DjX2Nn08qvEOADm3mGWbJjAHzEw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оЕзофЫьσ():
    value = 617501
    text = __import__('base64').b64decode('TW5uWGdZd3ZsZHBCbEVFYmYzckk=').decode('utf-8')
    if 30 * 60 < 0:
        pass
        _dead_9425 = 513
        548
    total = value + len(text)
    return total

def _тщΜκхэιътδΤщо():
    value = 891403
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgLeYQAQ6f5SYjeNxHmKYA4c2zg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΠыЖΥξοΓеιЧΣ():
    if False and True:
        358
        pass
        pass
    value = 70265
    text = __import__('base64').b64decode('S3JRVzhOY3RqXzVHRTZzeW12amM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩьхПиιιНУυ():
    if False and True:
        _dead_7215 = 695
    value = 386998
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FA7HQkUa0v02MR2A/HK1LgAl6kM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 20 * 45 < 0:
        pass
        641
        _dead_6883 = 715
    return total

def _ИξγΜрΣлЬрРтЙнβрш():
    if 9 * 78 < 0:
        238
    value = 272903
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSjNQkUj55oOGA725kWDAQcs5zs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 63 * 9 < 0:
        pass
        pass
    return total

def _αθРпθΣэυесТЪ():
    value = 409010
    if len('') > 0:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dx69dwQjqI8hKDn3mnDDDR0o12I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χШηзοЫЧΡЪΓ():
    value = 287590
    text = __import__('base64').b64decode('TjdsS2t1bk1OMGdLem1mVUpNQ0M=').decode('utf-8')
    total = value + len(text)
    return total

def _жΣмеΝψΥИ():
    if 32 * 8 < 0:
        347
        pass
    value = 387475
    text = __import__('base64').b64decode('enc4MlZwX2t0b1FhNklDcEw1STU=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        3
        pass
        _dead_2489 = 263
    return total

def _ΗШАваΡΤШΦδ():
    value = 347314
    if len('') > 0:
        _dead_3954 = 779
        _dead_6434 = 795
        _dead_2835 = 329
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyHPT1A2qqwEOwWpxUacEzEmzWY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 38 * 68 < 0:
        _dead_5205 = 46
    return total

def _мЭуэаруияЫφубцВд():
    if len('') > 0:
        25
        _dead_9335 = 369
    value = 202976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXf1VHMPyqEpHD2b/QXCCwN211s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7202 = 472
    total = value + len(text)
    return total

def _ζμюΚδГЙвзλφэлΕ():
    value = 590222
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDvLYQUIrJsmYxz6wliDLRwE0Dw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жчΠςнΒтДБΡцИ():
    if len('') > 0:
        _dead_2047 = 528
        pass
    value = 346091
    text = __import__('base64').b64decode('bVdjRDdxQkJGaUdZR0hIdXRBbXg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        540
        pass
        _dead_5970 = 635
    return total

def _ξИΕвΩУΞΚЛΞщΥθρэш():
    value = 47225
    if len('') > 0:
        pass
        _dead_6121 = 95
    text = __import__('base64').b64decode('SlNRc0pBVUJ1aHpZaHJQRG1GYkk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8377 = 254
        81
        677
    return total

def _οψпΘЬρφдΙ():
    value = 859888
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IT7FT1kwwalTHRqX0FyRDAZ33Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _βυнгзΚςζΜЛΠσР():
    value = 551992
    if len('') > 0:
        844
        _dead_8006 = 940
        281
    text = __import__('base64').b64decode('dGxhVUlpQXd4Z2hrOGxRb1ZDUWY=').decode('utf-8')
    total = value + len(text)
    if 77 * 66 < 0:
        224
        229
        pass
    return total

def _ЧЯΧрκЗζΙЩρΩξсД():
    value = 154398
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRf3ZVYrppwnOyTxmG+CFhcj/D8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 79 * 16 < 0:
        530
        _dead_5835 = 273
        _dead_9235 = 927
    total = value + len(text)
    return total

def _КЬЗлдΦЯθ():
    value = 298499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQPIZEQz9YMKLRWEyl+SYHIhsGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дрγэеАΜЕыΖкΨ():
    value = 531421
    text = __import__('base64').b64decode('dzZQbVo4RUhQa3cwZ1FxS0dVc28=').decode('utf-8')
    total = value + len(text)
    return total

def _АЬьмОΘЮξЪЮЙыюуξ():
    value = 764833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwXRS2Bh0YRSCB+F8Xq3Yi0CtGI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΩΔξгΔιДΣЩтпΦ():
    if False and True:
        _dead_7589 = 984
        _dead_7020 = 430
        439
    value = 979386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Px69a0Y8qaETDgqk0lGWZCIO5Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_4402 = 638
        484
    return total

def _γэςΟΞΦζыгοФς():
    value = 843255
    text = __import__('base64').b64decode('aTA4alB4cEJWR2NyNFdLUTRuemk=').decode('utf-8')
    total = value + len(text)
    return total

def _υηβцΚннΗьЗΡя():
    if 56 * 58 < 0:
        407
        _dead_1038 = 78
        _dead_8451 = 448
    value = 318813
    if False and True:
        pass
        pass
    text = __import__('base64').b64decode('TDNxeVMyS2lYYzkwYkg4UEpiRUI=').decode('utf-8')
    total = value + len(text)
    if 49 * 16 < 0:
        pass
        373
        _dead_8384 = 846
    return total

def _ъКЖΞтБΖΑΙбρАСЬΙ():
    value = 773575
    if 88 * 39 < 0:
        202
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kzm1OVBs9YQWEAScynGdGhV9208='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 24 < 0:
        _dead_7198 = 713
        pass
        pass
    total = value + len(text)
    return total

def _нпНΠΒΨηъцφ():
    value = 346054
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCfVYFsGz6JREjyu7HGHHzAL1Go='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оцΙςСфγв():
    if False and True:
        pass
        pass
        _dead_4053 = 858
    value = 310648
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBjKQ2gW9pI0ICOA4FrIEAML0WM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 16 * 48 < 0:
        _dead_1522 = 604
        _dead_4518 = 958
        pass
    total = value + len(text)
    if 51 * 71 < 0:
        _dead_6427 = 907
        pass
    return total

def _ШχЯЙУДγΨЖо():
    value = 175160
    text = __import__('base64').b64decode('TFk5UXMyRHNLVzBYemd6TWVmeU4=').decode('utf-8')
    total = value + len(text)
    return total

def _θΝЦΒΙпхмφΩхТπκ():
    value = 973517
    if 49 * 26 < 0:
        _dead_5700 = 425
        _dead_2923 = 398
        263
    text = __import__('base64').b64decode('c1RYSEw4YVkwYzdrY1Z2dW9QaWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _дΡьбрчюлщζθцΦθфΕ():
    value = 981057
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IQPiYlYhqJk3aDio60yjOhEDsEs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τыжГπРЩнЭцЬьΗ():
    value = 302093
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lh3UW18U/60XaST1+gKbDh0r8Eo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 23 * 97 < 0:
        452
        pass
        745
    total = value + len(text)
    return total

def _ЛэьЛΛкσфъρсэ():
    if len('') > 0:
        _dead_5196 = 518
    value = 892748
    text = __import__('base64').b64decode('Ukt6dllGVng1Z3dUTGlmdEU0cWg=').decode('utf-8')
    total = value + len(text)
    return total

def _κдгΦчθЖВπЮυδХχΥК():
    value = 744654
    text = __import__('base64').b64decode('YkY1NkdHM3N5NU5iQjVTVUhfOUY=').decode('utf-8')
    total = value + len(text)
    return total

def _зРφΠуΓθΒ():
    value = 309623
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzvNagQO2qkVHCur/lTCOiR46Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _воШζтлЪхΜчΧВδ():
    if 31 * 88 < 0:
        _dead_1579 = 512
        _dead_3002 = 291
    value = 274219
    text = __import__('base64').b64decode('QXNMbVJ6X1gzck55cU9sMEQwSVA=').decode('utf-8')
    total = value + len(text)
    return total

def _μζюξУГΜпУЦхИ():
    value = 917740
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EHuyXAUNrJ8EOziHm2GaDisgwkA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩЙζЫσЕφνΩОυтХЩ():
    value = 998284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CijlTHRr9/wxOD+O3gGFJnIE/HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АψвΛΡφаγΝыа():
    value = 976328
    if 13 * 69 < 0:
        _dead_4384 = 203
        _dead_9141 = 510
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgO0THxtxJEOKwb1mm6gPzF522s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЫШνΓЯЕБУчμщΣ():
    value = 732788
    text = __import__('base64').b64decode('VlRnbENuSVJMQ2w3UUVRNUdoTm4=').decode('utf-8')
    total = value + len(text)
    return total

def _КнΠБзσδвщΙНШΥω():
    value = 531405
    if False and True:
        pass
        _dead_4544 = 826
    text = __import__('base64').b64decode('WW15c2lTZnI3bllqZEdVcUpwNk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΗΑЙΒГςте():
    value = 542983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESz9aQEW260GCh37/HWcIzwOzFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τДρΘηЗЗθгνлΥ():
    value = 100979
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NBrwdHkG86c2NAyo/wXIOjQIxTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χлβМЮэмΨг():
    value = 824614
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LD/0VAcy3YYENAeG8VqWAHMG7D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яРуλКЖВΛΠпχШУ():
    value = 126480
    text = __import__('base64').b64decode('YjQ3QkJnbXVEbk1uVFlRRkxLY3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪшкαюσθбΣГνп():
    value = 71783
    text = __import__('base64').b64decode('YVJ4Z0Exb1JVYlJfRFJfYTM2MVY=').decode('utf-8')
    total = value + len(text)
    return total

def _τωяζОвΨΜСыАγθЯпр():
    value = 594298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ai3bYXswqaY6KA6BnAS3PAQu4E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЖнΜЪδсБπбА():
    if len('') > 0:
        pass
        _dead_6772 = 262
        pass
    value = 484098
    if 53 * 56 < 0:
        pass
        _dead_6281 = 75
        310
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IiDte0kyz74mPyalykORGDA3y20='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΩлВВФηКрνρθΖΚΙδ():
    if len('') > 0:
        306
    value = 66411
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiD9ZgBt5/EZNACOw3mUPQE371k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 11 * 27 < 0:
        pass
        _dead_6571 = 479
        pass
    return total

def _θΕμОχГАΓБλЕσλ():
    value = 516209
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDrSYVAB6aoGFCqF4wHIIS8Wwn4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νщΝΨιнкфБъΖξЮс():
    value = 460837
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQvRSGMT+LARYxWJ+lSEYzJ44Vw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙΑωБюбκΗενψσ():
    if 5 * 69 < 0:
        _dead_8117 = 6
    value = 556473
    if 67 * 53 < 0:
        _dead_8853 = 120
    text = __import__('base64').b64decode('T3JnWW1aT25uZzZLMWlsemFVVlo=').decode('utf-8')
    total = value + len(text)
    return total

def _чЗюεсеМаъΑΓπчΨχη():
    value = 741542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDzJT39g0pIEI1ei7m+ybHIq80A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ааΟδЮхωΓΧбολсηΕ():
    value = 934872
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXbDWGcx858iFgyK7X+zFjU5wDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΩБΣζπςρГМлΑЬЬМЕ():
    if 72 * 69 < 0:
        _dead_1849 = 222
        _dead_3470 = 351
    value = 744251
    text = __import__('base64').b64decode('VWh1UGhnVkswSkR4a3dqRjNndmc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΟЕНμБОЛпыииμ():
    value = 650708
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhbdaQgQ2vk0ayur5HXBLggI90w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩыνЛδсЛУЕФяΙЮр():
    if 14 * 83 < 0:
        _dead_9649 = 744
    value = 331439
    text = __import__('base64').b64decode('Qk1vY1A3QVJVU0hCX3Fvd0xEczI=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖьΡεЛρπωαВЖКαγ():
    value = 855144
    if False and True:
        _dead_1785 = 551
    text = __import__('base64').b64decode('bkVQeDd4dkJxU2NveHFsSVhNaWI=').decode('utf-8')
    if len('') > 0:
        477
        pass
        113
    total = value + len(text)
    return total

def _ΒΦшдппРψВαкЖа():
    value = 863961
    if 79 * 49 < 0:
        421
        pass
        _dead_7974 = 18
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EATtZlAq2LpQAhv3+HO2Gn1+1F0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜςфψСЮΚДθαЙγπбБ():
    if len('') > 0:
        123
        pass
        pass
    value = 865208
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CHzGUV881pEOah6u/A/GAQ8ns2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 8 * 22 < 0:
        pass
        981
    total = value + len(text)
    return total

def _уΕМΤюТΨιуЩжмЩΗΘ():
    value = 646721
    text = __import__('base64').b64decode('V3Q0VE1VVUVRWnBHam1ON3g1dnA=').decode('utf-8')
    total = value + len(text)
    return total

def _МДОэуьшЮΑпξθο():
    if 4 * 54 < 0:
        pass
        pass
        _dead_4199 = 951
    value = 38451
    if 97 * 66 < 0:
        _dead_7405 = 500
        _dead_9602 = 298
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgrTNgI9x6wXPgSgnU+SLQsjsEg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        744
        _dead_3078 = 517
    return total

def _ΠЕДΧΓΕЕΠΓφвΜ():
    if len('') > 0:
        804
        pass
    value = 84755
    if len('') > 0:
        pass
        501
    text = __import__('base64').b64decode('UjlEeFk3d0txdGp1MGF0WFV0T1o=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _λΜπΤлΝЖω():
    if len('') > 0:
        643
        _dead_9860 = 756
        pass
    value = 528138
    text = __import__('base64').b64decode('d1RtTmVGQk1sNm9WYVRIWXBIa3c=').decode('utf-8')
    total = value + len(text)
    return total

def _ФмЭβжыΤлЦСЭλФ():
    value = 735300
    if 5 * 27 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ABrPRQgA1f4PFS6ax1ukZSAK0Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        636
        pass
    return total

def _ΟЯμΑρушоιΞПΤφПχж():
    value = 89924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AHfvVAgA+oYyNQCTxUeEIiA69Uk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯуАЯчшσωεμ():
    value = 733567
    if False and True:
        661
        pass
        _dead_8072 = 566
    text = __import__('base64').b64decode('UlRGSGJHV1E4WGVLVHYyZFJ3ZGQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮΣΓМΩκНоЫЪζичОΝ():
    value = 790055
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BwnpOmIJzr0KFAWW3UCHHQYl8EA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κЕЭхΑИнΩоυΟθΩχЬ():
    if len('') > 0:
        27
        pass
    value = 11692
    if False and True:
        _dead_8103 = 994
    text = __import__('base64').b64decode('SVc5UEtPM1VfNGtpcDZnZnBBT3E=').decode('utf-8')
    if 92 * 25 < 0:
        190
    total = value + len(text)
    return total

def _ЖνЦΟеШыεΡюЕΡψ():
    if 42 * 22 < 0:
        pass
        996
        pass
    value = 816528
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JyH1a3xt7PgpI1aQ0kODBCI682s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦγΦЪтχПрΟоΧмΕ():
    if len('') > 0:
        pass
    value = 801599
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IgT8bEJh7JIkMFinkV6EZTck3mw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μεсИкЖИдηγПлФ():
    if 53 * 76 < 0:
        381
        _dead_9524 = 919
    value = 108923
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix/8QgQu060nHACLwgGTYTw+5WA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _ЛбБЬωдгΔ():
    if 46 * 51 < 0:
        _dead_5053 = 33
        pass
        934
    value = 922311
    text = __import__('base64').b64decode('elJiUUVKdHVwVjh1cEZsbWlIaTk=').decode('utf-8')
    if 33 * 28 < 0:
        _dead_9757 = 950
        _dead_2736 = 917
        210
    total = value + len(text)
    return total

def _ζκΨαхΡйН():
    if len('') > 0:
        49
    value = 879423
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HADiRXQp9L9SC1eHmQ+dYwIkvUY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 45 * 44 < 0:
        866
        pass
    total = value + len(text)
    return total

def _УΤозсуΡΒθεЛК():
    value = 623498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3/NO0lp1L1RMwGl0HeDJwAE4Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _чΓуоοπεζЖкφюβνз():
    value = 163697
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('F3qyOHktx4ssIiOGxVqTBA55vEE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фоΗθζоηЦпαтςЮмрр():
    if len('') > 0:
        799
        37
    value = 615937
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HzveYFcqyY8AACGE5VfDHikI108='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        456
    total = value + len(text)
    if len('') > 0:
        pass
        472
        507
    return total

def _ΑИδЮеλПйΤОкУАн():
    if 61 * 6 < 0:
        _dead_8474 = 0
        pass
        _dead_7953 = 416
    value = 206655
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3rhYHMv8a8waCWzm2+qBnc21Dk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 47 * 71 < 0:
        _dead_2212 = 466
        _dead_7185 = 687
        pass
    return total

def _гФζυЗбЗцЩЖк():
    value = 408875
    text = __import__('base64').b64decode('S3BBc0p5THE2bVFrRWRUYWpRcWU=').decode('utf-8')
    if len('') > 0:
        317
        910
        693
    total = value + len(text)
    return total

def _ςЮηтΔДλЦ():
    value = 857342
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NxnlP14B/KUJMl2E43C3Ygwqtz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 5 < 0:
        pass
        _dead_6228 = 71
        pass
    total = value + len(text)
    return total

def _οДьИзюΠΓεΩΦАΕЛΠ():
    value = 9938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dif+V2c/zf0LPQK2zQTFDjQbslY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кщЧΚοβЪΕЕп():
    if len('') > 0:
        _dead_4066 = 109
    value = 210287
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PXzFPkBu7fwNMTyUwlyyMjM17z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        95
        pass
        pass
    total = value + len(text)
    return total

def _ХфЛωЕЪμЙΗутОЕολф():
    if 56 * 81 < 0:
        _dead_3098 = 575
        777
        pass
    value = 552046
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQbQeWU/2q05bSyO3HSDNxw6zmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _дуχνμαцΕβιΛмМυюγ():
    value = 418833
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwLpXEBtx4AzFjqa5XiRPg0nwzc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ищΦιЩзОщΠЖΩβьвпψ():
    value = 20542
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fjz9Ywlp8PwkCRv1wg65YxwC4Uo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        pass
    total = value + len(text)
    return total

def _НΚνысЭεЪюф():
    if False and True:
        479
    value = 144498
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FQrNfH8Y0r5bHQ2ax16oISEO3l0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нρДЧхιоκчμ():
    if len('') > 0:
        pass
        _dead_4042 = 532
    value = 53247
    if len('') > 0:
        _dead_6338 = 364
        pass
        790
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHvHaH42qIYwPiCq52+HOSgJ7T8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _МтЗИвдфρх():
    if len('') > 0:
        189
        _dead_6729 = 541
    value = 967759
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IijKeEgY2ZFUYwK3yUWkFRYL8GU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УГΗΨЮшΡШΔНΘ():
    value = 498505
    if len('') > 0:
        _dead_2712 = 323
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HSD+a14+57g1HgH13XLBDAEjtkI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УюбΘгωηдЭщζоп():
    if 89 * 16 < 0:
        pass
        784
    value = 611234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LweyYm487qMKDly32UOkLCAo92I='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _πЭыхωΧаЬΡ():
    if len('') > 0:
        pass
    value = 685857
    text = __import__('base64').b64decode('dmpwdVhINEUyQkhGSzB1X1lUbzg=').decode('utf-8')
    total = value + len(text)
    return total

def _лΨπχэψмЮЦИЮΣ():
    value = 750638
    text = __import__('base64').b64decode('ZnBHcjNzS1d1R00zOTVodGFURGg=').decode('utf-8')
    if 77 * 16 < 0:
        pass
        _dead_7213 = 765
    total = value + len(text)
    if False and True:
        pass
        _dead_6744 = 703
    return total

def _ΩцТоБΒАΨτΕξδκЫ():
    value = 798975
    text = __import__('base64').b64decode('U0xFZTd1cFRKbVhoeWo4WkFkS0s=').decode('utf-8')
    total = value + len(text)
    return total

def _ъуτΣΡΝфιΣйφбуΦх():
    if False and True:
        pass
        _dead_8860 = 656
    value = 256983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CCSyfHdo64wpaV/1+V6VOTUd5Vs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щЦΖоОθΚаЫΘЕнσ():
    value = 35154
    text = __import__('base64').b64decode('UEd1V1pFYXpHVTFVWjAyaHByZlc=').decode('utf-8')
    total = value + len(text)
    return total

def _τΘΤОΔΓИβгЦЬЩλЗσ():
    value = 85423
    text = __import__('base64').b64decode('Rk5tcm53aUF5YUVldEJrRnBobWE=').decode('utf-8')
    total = value + len(text)
    return total

def _эКБθυΦαМΘеЖиρмε():
    value = 831114
    text = __import__('base64').b64decode('cEZ5MFEwNFN5N1ZXdnpHQm9HcmI=').decode('utf-8')
    total = value + len(text)
    return total

def _кйзЮΔДЛιαΔωЬι():
    value = 571084
    text = __import__('base64').b64decode('Z2tjZXFqRThtaVFheDBQSnNSS1Y=').decode('utf-8')
    total = value + len(text)
    if 68 * 12 < 0:
        612
        pass
    return total

def _меγцЧкЕτАе():
    if 70 * 37 < 0:
        pass
    value = 504556
    text = __import__('base64').b64decode('VHhGVjdZTmlUa1dRaldJcHdSUDY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΩШАЙЙψубдх():
    value = 740293
    if 44 * 92 < 0:
        _dead_2320 = 129
        pass
        pass
    text = __import__('base64').b64decode('Szl3cmU5XzRxWEhkNTQwbmQzMTc=').decode('utf-8')
    total = value + len(text)
    return total

def _аβΗπΝЪЙЪМ():
    value = 136513
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AiO0ewEMxIYwHjqR93iCGyYcvVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 66 * 43 < 0:
        pass
    total = value + len(text)
    return total

def _ξνпьЮπкχχичцНΞκγ():
    value = 683996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PRruRl9v74o0BVa0/Xy4Hxc+w1c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΛЖчЭΖΔЭΝζ():
    value = 983089
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3jraUg0x/EHFQzyxW/CHhU29Ug='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _нбпыθеЮжЙАжжиο():
    value = 205235
    text = __import__('base64').b64decode('bEo4R2hGdHlBWFBURGQ4Smw3NEk=').decode('utf-8')
    if 87 * 53 < 0:
        _dead_2667 = 119
        pass
        _dead_8392 = 529
    total = value + len(text)
    if 66 * 61 < 0:
        pass
        pass
    return total

def _ЭдпкЯАοΘЮЫГС():
    value = 685156
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAj0aV8o774hPAa1/QGmEy8W9V4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        831
        592
        _dead_8428 = 116
    total = value + len(text)
    return total

def _ЫГуГцГцλХНμ():
    value = 783356
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JC60OVYgr/shHTf6nFKSOCAuvF4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        384
        _dead_3815 = 818
    return total

def _нЮЯБΠЯгΛгβΛАРΕβ():
    value = 198220
    text = __import__('base64').b64decode('amR4TXkwUEVRUXFIVjR6NDZReVA=').decode('utf-8')
    total = value + len(text)
    return total

def _κγОфΑςхλΠΖЯДΗ():
    value = 986263
    text = __import__('base64').b64decode('YXpRS2RWUllwbmw1WHhFWWxJUUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛЭνяХЧЧΠΝ():
    if False and True:
        pass
        357
        _dead_7080 = 431
    value = 482313
    text = __import__('base64').b64decode('TFFUcjFMcXAyanJ2a194X0ltbXE=').decode('utf-8')
    total = value + len(text)
    return total

def _σПяΜскΘТЯИеΦσΠ():
    value = 308225
    text = __import__('base64').b64decode('Smc3dTRpMzAxUmhzdnpaZTJaSkI=').decode('utf-8')
    if 65 * 93 < 0:
        247
        163
        227
    total = value + len(text)
    return total

def _ΒΦюТЫлъМεΞΨ():
    value = 619753
    text = __import__('base64').b64decode('eWthbE1iZHU4Z0xDTmZKem5feUU=').decode('utf-8')
    total = value + len(text)
    return total

def _мσΜΔСфКшхΕΥδФκ():
    value = 473891
    if 58 * 91 < 0:
        448
        916
        _dead_5669 = 423
    text = __import__('base64').b64decode('eUpUZDVrMlZpUHNoQ3RpRnJyYzU=').decode('utf-8')
    if False and True:
        _dead_1356 = 484
        pass
        20
    total = value + len(text)
    return total

def _ЦбДτЦκфЙдΓтΜЯΞЪ():
    if False and True:
        pass
        965
    value = 687864
    text = __import__('base64').b64decode('bEFidGRCRHlsdnY5QXNHQXdTcFc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        677
    return total

def _кΨρΒЗвсЛЮРφЛΔΓΔμ():
    value = 407977
    if 61 * 53 < 0:
        63
    text = __import__('base64').b64decode('TXpNbmpWOTBraXdKV0EyNnVLd2o=').decode('utf-8')
    if 71 * 95 < 0:
        _dead_8057 = 623
        _dead_3113 = 126
    total = value + len(text)
    if len('') > 0:
        pass
        _dead_7532 = 669
        _dead_5479 = 255
    return total

def _фаλлλьлЩΡЫйδζΔΔц():
    value = 129731
    text = __import__('base64').b64decode('dWNtdFdTY1I5YUZIbU44eEtpTXE=').decode('utf-8')
    if len('') > 0:
        73
        530
        375
    total = value + len(text)
    return total

def _υχрэРъЭχБПжцΤзТ():
    value = 205393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyrOaklq8r8ODQuZml6qZRw+4WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _зхΔгфоеУв():
    value = 497427
    text = __import__('base64').b64decode('a2ZDSlV6SFNIVURIdEpzelc2SnI=').decode('utf-8')
    total = value + len(text)
    return total

def _ιВУΖΛτме():
    value = 163270
    text = __import__('base64').b64decode('WnFya200VzhRTXdzTk5Td3Rnbmo=').decode('utf-8')
    total = value + len(text)
    return total

def _шьцψΔιзЪбНζ():
    value = 792415
    text = __import__('base64').b64decode('UzBrQTRiajVLakNpRUlDdWhCUXo=').decode('utf-8')
    total = value + len(text)
    return total

def _θдΟΞзщпταЛфδφЫПΖ():
    value = 262133
    if False and True:
        pass
    text = __import__('base64').b64decode('YUVGUlN2Unh5Y1NERkhJb3NBUHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒχйСμатжγγПυ():
    value = 906420
    text = __import__('base64').b64decode('dnRCdVhpR2Nud3NaN0o0Nk9WUEQ=').decode('utf-8')
    total = value + len(text)
    return total

def _βξβмπζδρΗНмхβФхн():
    if 75 * 67 < 0:
        495
        _dead_5221 = 724
        pass
    value = 833383
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CS3JTHUIyqsTDlaU8lupHz0A1jY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОХЬκΝСωотХГ():
    value = 185736
    if False and True:
        pass
    text = __import__('base64').b64decode('cFd5clpiQzF2dm0xREEwTkhfZVA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_8634 = 395
    return total

def _ЩσкхΘγчаΛой():
    value = 269316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JCbbfHYzp6APOFv3xnqjPAoayzo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыΖпΙτЙΔп():
    if False and True:
        _dead_7722 = 661
        pass
        pass
    value = 855793
    text = __import__('base64').b64decode('YU1rZzRCNXFxQ1VXOTV4NDFjZFM=').decode('utf-8')
    total = value + len(text)
    return total

def _ДбκрюνШчъ():
    value = 494136
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PCXWSUYWy6ZRGVuXmwS1OSh/yFg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уИκΡΒкдς():
    value = 120840
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JHznQ3sRq74gMQCUxEKCGD161z8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _уЙΧΘΒПеΜ():
    if 46 * 49 < 0:
        _dead_9212 = 54
        pass
    value = 90512
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQTyZ1Ur0vsUCS7053e8JzANzn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _χФЦхрЬпΜηЖЬΖαбР():
    value = 126176
    if 27 * 61 < 0:
        _dead_7540 = 733
        143
    text = __import__('base64').b64decode('em5odXNuQ0RtQzdrMUNpcGpsRFU=').decode('utf-8')
    if len('') > 0:
        _dead_9030 = 830
        _dead_6564 = 328
    total = value + len(text)
    if 46 * 15 < 0:
        _dead_6901 = 757
        _dead_6437 = 961
    return total

def _УβшЯΠщμТΣεаωΙКМ():
    value = 453883
    text = __import__('base64').b64decode('enBlMlRzMVhUbGh2Q09CWnNkMTk=').decode('utf-8')
    total = value + len(text)
    return total

def _эΕуъсζδνΖФнЮΞΔιУ():
    value = 192863
    text = __import__('base64').b64decode('bVQwNGpWUEZ5Wm1WQ2JxM1I2Ym0=').decode('utf-8')
    total = value + len(text)
    return total

def _цЩΟиκфЖωХКбΚΜγЕХ():
    value = 573568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FnrgWmkY1PoFGFunnluxFyQ8wT0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_6738 = 692
        _dead_5944 = 983
    total = value + len(text)
    return total

def _θЭуρЕЗКμ():
    value = 978284
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyTybXBu6aBaBQup4k66Nh0atlg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑЦГΤЗОЫΝΒΩγ():
    value = 844580
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhnedHUR54k2KAK6yQSzHgIH8GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤξζЛъΞЙГщВстщЩω():
    if len('') > 0:
        512
        _dead_5698 = 582
        pass
    value = 709443
    text = __import__('base64').b64decode('RVhxcTROX0JQYlBtQjFRVlRVd3g=').decode('utf-8')
    total = value + len(text)
    return total

def _васεΩгΘκЬΠοЪε():
    value = 869685
    text = __import__('base64').b64decode('STl1SDJRVzNWTXBHUUl3eWdDUm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ΠΞσΜΙεσΓ():
    value = 131426
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NynFSX0z2atQCQL3xm+yLHYb9DY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μθΔХУραιОэ():
    value = 251355
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx/GWHoKwZwPMjCbx3ObJD8cxXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9783 = 707
        485
        _dead_7684 = 209
    return total

def _ρхΣФεТцЭηР():
    value = 250675
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HCLlSgML9KAHYyqCmmaRYB8911c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        999
    total = value + len(text)
    if False and True:
        233
        pass
        _dead_8151 = 903
    return total

def _ΧЯиеΖоРЕΗФθх():
    if False and True:
        pass
        170
    value = 789562
    if len('') > 0:
        pass
        _dead_4927 = 520
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NwHMYWIcyaEAAyySnnKWFnMswTo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АШйζТΔΔΞρ():
    value = 824113
    text = __import__('base64').b64decode('ZXVzNEJFY3N2NnY2WVlHVG1lb1I=').decode('utf-8')
    total = value + len(text)
    return total

def _лДъдΥЫТьиΒНρЧЛя():
    if 48 * 68 < 0:
        921
        pass
    value = 888358
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTfrRl4P+owmCj+E5mTEZjQq3Ek='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _миПЗΩΙуεΡφ():
    if len('') > 0:
        868
    value = 532462
    text = __import__('base64').b64decode('TW9CX0JlUHl4bVRWcVk5bk1oMTI=').decode('utf-8')
    if 52 * 6 < 0:
        27
        _dead_9548 = 518
        _dead_6394 = 394
    total = value + len(text)
    return total

def _ΕыПμЛъθПΕΖκψ():
    if False and True:
        pass
    value = 769186
    if len('') > 0:
        _dead_6832 = 457
    text = __import__('base64').b64decode('TlpBVnp2WldFc2hZNFBtTjRSRXo=').decode('utf-8')
    if False and True:
        pass
        pass
        _dead_5522 = 147
    total = value + len(text)
    return total

def _хζАΜοξχшДлχρρС():
    if len('') > 0:
        40
    value = 754824
    text = __import__('base64').b64decode('UFJuMEdZZENSYmVRSkhhOWlXZmw=').decode('utf-8')
    if False and True:
        _dead_1778 = 326
        pass
    total = value + len(text)
    return total

def _ГпьΥнЛηоλУПУФΔΚф():
    value = 936196
    if 60 * 84 < 0:
        184
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQbUeQgf5KwAKSii2WOWZQ58xT8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оΩГΗΜяιКΡλжδΜδΗж():
    value = 70927
    if False and True:
        _dead_5279 = 494
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DzrIRwYN8blQbwby8G6AbS8i3WQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ВсщАΣΨγн():
    value = 716314
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ex/8fggG6/1QNCf68nmlPRwf4nc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _λьΛЭπюθΔΗΟЗ():
    value = 242867
    text = __import__('base64').b64decode('Z2lzTjRUTmwwOFlqMVdjdXdoRUo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤыπЫПОΥΑΖф():
    if False and True:
        _dead_4494 = 81
        pass
        pass
    value = 569405
    text = __import__('base64').b64decode('aXFwQk8wdVQ5Mkc5Y3FRS2l6QXQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ляΙηζпΓЪΜ():
    value = 425388
    text = __import__('base64').b64decode('QUtrZzhnTjlPbmxxTElFOXVGcVI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥхЛэΟтφпρμξруы():
    value = 87468
    if False and True:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhjAQQQV2bEEHjmq41O3PhIW9Ho='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИИЩфΙфйΟΜτьуОδ():
    value = 264321
    if False and True:
        pass
        541
        313
    text = __import__('base64').b64decode('alB1ajFHbmN5ZFFsN00yUTBhNnE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΛГжхьгζπмАЪ():
    value = 198207
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DDbsW1or3JEPCV+x2wagHwR/6l8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тГυтΠυΗрПФэΞχПУП():
    value = 669787
    text = __import__('base64').b64decode('ejdHOEZOMUp6VHNFam1vU3BNajI=').decode('utf-8')
    if 27 * 8 < 0:
        pass
        _dead_1846 = 381
        _dead_7659 = 159
    total = value + len(text)
    if 34 * 16 < 0:
        _dead_3529 = 271
    return total

def _ρπΑЛснΩЮГγ():
    value = 968157
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASHObXU3x6xVO1qAz2y+HhQayD4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 100 < 0:
        590
        _dead_3280 = 340
    total = value + len(text)
    return total

def _ΩйЖМуχЬьΜΚπюΔнШй():
    value = 236753
    text = __import__('base64').b64decode('WDRtZFJ3UHp0dlRUM0FUTGZONXg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨНфΟфэМεЫТэ():
    value = 543909
    if 85 * 27 < 0:
        867
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATbcdG49x6oRPCuh3m6IOg867kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_8060 = 96
    total = value + len(text)
    return total

def _ιаΧηГЭЦЕШθбо():
    if 41 * 53 < 0:
        154
        _dead_9559 = 808
    value = 902800
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NX23YFoK8IolKAqrzQKfGHUrx1k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЙОςςсгоΟΣ():
    value = 319996
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EXvDXkkzxqAxM1yq8WagHhV7yl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шВЗкФΑΠΒааз():
    if len('') > 0:
        _dead_7374 = 0
        347
    value = 926571
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FX3naHdo0P05OBWIkXK9Yx8c8UE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πчЭжβЮΕЫШΨваы():
    value = 537243
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BizmaVIr+IJSCT+z7gO4PBUI9ms='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8116 = 901
        155
    return total

def _ыΘЖγθПΑθΣПγρψΨθЧ():
    value = 36560
    if len('') > 0:
        _dead_2972 = 862
        444
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSy2eUA3+LwxEz+H536dFQAM52E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 19 * 69 < 0:
        _dead_2760 = 752
        599
        pass
    total = value + len(text)
    return total

def _φцщХяАθΟΡαОακпй():
    value = 709418
    text = __import__('base64').b64decode('bUJHaU1wQ3lYdXRscjR4ZVVwc1c=').decode('utf-8')
    total = value + len(text)
    return total

def _нрМхΨкςνΝΝΣВ():
    value = 372409
    text = __import__('base64').b64decode('cGlXR1RPaUF4UExkNnR5bUlBWEs=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑВВμюΝДтψΨαлΞμΕЕ():
    value = 566895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQH0SH89qJExYhqO6QCEOj943k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аОΡωщΩУΓхтъ():
    value = 439910
    text = __import__('base64').b64decode('cFk2TXVyRlJ4YjhjekdVWDFsXzI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_4514 = 443
    return total

def _гЩрЛюΠцΥΙПкМяΡяσ():
    value = 49788
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ICDgZVto95tTCDaT61m9MnUs8mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мζКΝΧывВσаΔЙЛм():
    value = 944974
    if 24 * 21 < 0:
        pass
        pass
        _dead_8333 = 354
    text = __import__('base64').b64decode('RGR3bnJXdHA1Qlk0Z1pzeWlVbFM=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        305
        pass
        pass
    return total

def _ιщΔιжаТП():
    if len('') > 0:
        163
        pass
        734
    value = 5170
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('D37tWFYV3YEuKjCtyUGhOhx7xnw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _βФΟΡыκыАΑбИ():
    value = 587496
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IBbienwf1vAaG1+u0kC9FRAHz0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _РтΠςНЧЖгΕσФ():
    value = 867149
    if 60 * 81 < 0:
        624
        648
    text = __import__('base64').b64decode('amRiN2pwdEZjbTBPanZfcjBoSEs=').decode('utf-8')
    total = value + len(text)
    return total

def _АςΔΞБΗΚψшΗЫРЪ():
    value = 192348
    text = __import__('base64').b64decode('TU9wQ2pzUXpxSHVXU3RMS1lycGk=').decode('utf-8')
    if 2 * 59 < 0:
        473
        _dead_9710 = 65
        558
    total = value + len(text)
    return total

def _νхЩопΜζΥ():
    value = 25265
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HwDvbFQszI4kEzu00HvDbHALz3k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ZQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()