#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _νλΒНΛΔργΥκчЗШАДΤ():
    value = 619701
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DTzGRn8Bq6kGA1eVwX+8bSIp7HY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΖΦВЙΨУΡдΓоΗΝφυЯ():
    if len('') > 0:
        _dead_9288 = 74
        259
        pass
    value = 513202
    if 17 * 99 < 0:
        _dead_9108 = 297
        240
        _dead_1522 = 924
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCeyQEUB5KNRFBub/nW6IQF+5zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _мГυθγПΧйΙΖКГΩΡ():
    value = 91791
    if len('') > 0:
        _dead_3094 = 287
        316
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwHzPVA29pEzEleunQ6oHCp4tXo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΘЫсξρВГΩ():
    value = 376002
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eg7JWEJr+4NUHALy8mPCIz8dt00='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _оыΛαЪзπτРιΝ():
    value = 727650
    if len('') > 0:
        125
        500
        pass
    text = __import__('base64').b64decode('cWQ1a2RRY2J2V3FvUktyM2ZOckU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        783
    return total

def _рΝчХΕХμΨЭ():
    value = 580840
    if len('') > 0:
        955
    text = __import__('base64').b64decode('d1cyaHBRN2JiNXVlN1RLcms0Mzk=').decode('utf-8')
    total = value + len(text)
    if 38 * 72 < 0:
        874
    return total

def _εφнкпμΠЩωРγШОΑ():
    value = 580863
    text = __import__('base64').b64decode('dW1HMW9vSDFSWU5INVJtQV9Kd3I=').decode('utf-8')
    total = value + len(text)
    return total

def _ξΟщеΤΗЫτχΘН():
    value = 598072
    text = __import__('base64').b64decode('RXlQS1VZNTdla0dnS0FkUjRpc0g=').decode('utf-8')
    total = value + len(text)
    if 3 * 41 < 0:
        pass
        _dead_1119 = 952
        pass
    return total

def _ΖγлΣπЖЩηф():
    value = 542315
    if len('') > 0:
        15
    text = __import__('base64').b64decode('ekNhandCa25uTDB2aWkxclhWZ18=').decode('utf-8')
    total = value + len(text)
    if 5 * 91 < 0:
        19
        743
        pass
    return total

def _ΥнΔπлЧΥлλ():
    if 30 * 9 < 0:
        490
        pass
    value = 720586
    text = __import__('base64').b64decode('VmVIenc5dk51S1dUY2k5eVlzT3U=').decode('utf-8')
    total = value + len(text)
    if 41 * 99 < 0:
        pass
        pass
    return total

def _СпЛДωчΤШ():
    value = 112865
    text = __import__('base64').b64decode('UzZnQng5Y2dYM0c0aW1XcEsyWHo=').decode('utf-8')
    total = value + len(text)
    return total

def _щΖЫνПтПСΑВТ():
    if 66 * 20 < 0:
        940
    value = 991441
    text = __import__('base64').b64decode('eDYxZ202MEFhX0dvU0RmMGhZZHY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7985 = 447
    return total

def _ιψΩτРлβНЫ():
    if False and True:
        _dead_5215 = 233
        _dead_8638 = 236
        _dead_6524 = 242
    value = 670249
    text = __import__('base64').b64decode('c0Q0UUVmcV9WYktDSEdJVXRIWVI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        28
    return total

def _αЬиΡЮъКΑ():
    value = 16330
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lyi8Oks885syAw667F6SEiYq1z0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЛΠγЗхйТΘΥПЗоСωк():
    value = 146878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwTDf1wzyf8lAiW1xX+fLXQnx14='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _щβЮΔЕшЛΡμТνεΧΩμ():
    value = 574455
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KAzJeFIN/fsSGRy342a6EwQZwF8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _цφΛЪцωШеаΞνСρ():
    value = 13557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KxfyVwUN/ZkNAx+1w3G8HiE71mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘωΤПйΗπЬач():
    value = 336733
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln3pO1Iw5/8NNjeLyXmRIg8ByHk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ГΜκΥΥчΔСЙ():
    value = 76320
    if False and True:
        _dead_4745 = 716
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lzz+PgM1/4INKzD75nKiO3Z45U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ББЛσЛХΖΙΜΡο():
    value = 918054
    if False and True:
        _dead_4355 = 642
    text = __import__('base64').b64decode('a1NvcGs3QjhuXzEwSU9HcTNWSjE=').decode('utf-8')
    if 51 * 15 < 0:
        _dead_3646 = 199
        658
    total = value + len(text)
    if False and True:
        _dead_3165 = 278
        591
    return total

def _ЮэНудΦОХч():
    if len('') > 0:
        pass
        _dead_5888 = 612
    value = 151573
    if len('') > 0:
        pass
        98
        583
    text = __import__('base64').b64decode('cHRIWDlYYmVuNFVpa21JRW1SV1U=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧνнΟςψпΨнδНΔЦΖнΜ():
    value = 32609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('B33tOlAMqYUJahaAzQGhFSQG6UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΘЖеβхΦβчΚшнЛ():
    value = 26859
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATzxVmEe57whaQew+E/HC3x36Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟвылИΟмΥΤЕΜзРНχΗ():
    value = 412343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kg3yPF8ArqALAxiw6lOYHzU14Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦдфцойГшКαβ():
    value = 206380
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgPpZGkj9PkxKCyl0myaGnYl6Ew='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 22 * 25 < 0:
        _dead_8388 = 793
    total = value + len(text)
    return total

def _ΑТЯггЯΣΔξ():
    value = 950784
    if False and True:
        _dead_4388 = 54
        _dead_2799 = 221
    text = __import__('base64').b64decode('QVlGQUhWYk5OOEIwTUxkalNvRTI=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞРЭΣΦχэΝкθ():
    if 71 * 65 < 0:
        pass
        464
        pass
    value = 213154
    if 54 * 89 < 0:
        _dead_2528 = 953
        895
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HX7WS2ggqp8AaVeH3E7HZDwk134='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_1417 = 690
        _dead_8282 = 31
        pass
    return total

def _ωπφυгΕНρΩхΜ():
    value = 745781
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ByHnYUQx07AXC1yH7HWlBAAb7Tk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςШбВμΥκы():
    value = 133179
    if 84 * 44 < 0:
        976
    text = __import__('base64').b64decode('ampLSkV1dWF3TjVSY3FYRXI1WWc=').decode('utf-8')
    if len('') > 0:
        267
    total = value + len(text)
    return total

def _ЪцΕапКφкΗрИ():
    value = 642156
    text = __import__('base64').b64decode('TjR0ckpjY0lRWDFJTHFWY2ZiVHY=').decode('utf-8')
    if 79 * 83 < 0:
        108
        _dead_8689 = 181
        _dead_8901 = 768
    total = value + len(text)
    return total

def _ЪДοгГνКыЛзρ():
    value = 541622
    text = __import__('base64').b64decode('dExlWlZIR08zdERYeFhPUkFUZ3U=').decode('utf-8')
    total = value + len(text)
    if 32 * 38 < 0:
        _dead_3170 = 169
        pass
        _dead_9191 = 115
    return total

def _уеΣρΧзΜαЬυнΗж():
    value = 817581
    text = __import__('base64').b64decode('SEhaZmpmQ0lQcGFnQkl6RGdDNkM=').decode('utf-8')
    if 16 * 50 < 0:
        _dead_8363 = 219
        _dead_9831 = 485
        _dead_9413 = 734
    total = value + len(text)
    return total

def _зηИκΔеМеЖвАЩΚκοκ():
    value = 318103
    text = __import__('base64').b64decode('dGZwVlFnU05mYVlNVzB1UjlCNGg=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨоΟτξΞЖДШ():
    value = 669303
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NXiwWFwu9qQPEgi1xnmyHSgVwkY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ρηρоХОΚКГВшπΤ():
    value = 28783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LgvFUXQr0IVXMDuN6VKBIwE44lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _Υβδмδвпб():
    value = 342231
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez7lT2MJrIkaIin7yn+oHAN662E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        707
    return total

def _ИебИχЯφηСЦяΥдΓз():
    value = 787925
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JybvVF8O3P1UNxiE2FDGDAMLyEA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤηЧпдνιЙιЬΥιЗ():
    value = 896569
    text = __import__('base64').b64decode('Z0ZneHJFc3FsMk53d2hXTmJEa0I=').decode('utf-8')
    if len('') > 0:
        991
        980
        pass
    total = value + len(text)
    if len('') > 0:
        pass
        629
    return total

def _ЕΓПΝХΞξΑ():
    value = 362125
    text = __import__('base64').b64decode('Q3VuZjZxU2wwSE44WnFGcVFud3c=').decode('utf-8')
    if 87 * 97 < 0:
        _dead_2797 = 563
        pass
    total = value + len(text)
    return total

def _ΤиΜχщωοпςΠеΞфζяξ():
    value = 644995
    text = __import__('base64').b64decode('Z3NNM1NpeTR4RjFnX1QyeEFxbHA=').decode('utf-8')
    total = value + len(text)
    return total

def _тΓшМΕαυΧωξчаз():
    value = 731933
    text = __import__('base64').b64decode('U24xU2tDTjdsT0IyeWNmS0phX3I=').decode('utf-8')
    total = value + len(text)
    return total

def _яРчЕЧбйМΛ():
    value = 915845
    text = __import__('base64').b64decode('amtkNjlBWHB4UjVWTTZlVDVlMl8=').decode('utf-8')
    total = value + len(text)
    return total

def _лψΘΣбАπφеЫ():
    value = 322108
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXjcZ1QN5r4Fazec3AKXLiYQ4Wo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЫЙЮшячсИОгп():
    value = 568423
    text = __import__('base64').b64decode('dmlIeWN4djVaNzJXTUF5ZUZNd3g=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _φъΞξчΠΣиЖπ():
    value = 597276
    if False and True:
        10
        pass
        925
    text = __import__('base64').b64decode('QXlkSVNBS1Z0SVEwdFk4YnlKaXc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЮεЩумПχΤгχσФΩ():
    if len('') > 0:
        84
        _dead_3318 = 184
    value = 159142
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FCv0T1YwwYYyNzDw8ma5ZHM/4Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КΛΛγΠΞнγπоЖ():
    value = 436201
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NDr1a0UG3a0GOxqJ0kSiBTAkvXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _νюψхтЬБЬзВПιψθо():
    value = 798073
    text = __import__('base64').b64decode('R0VSSVVMZTI1QUVFTWdBS2lZajY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΥυяяοПζйэлсоЧ():
    value = 914537
    text = __import__('base64').b64decode('QUpnTVVUenZ1b3BiOHJEenpxRXM=').decode('utf-8')
    total = value + len(text)
    return total

def _эθΞΛрМчн():
    if len('') > 0:
        pass
    value = 737219
    if 60 * 61 < 0:
        _dead_1825 = 764
    text = __import__('base64').b64decode('c0I4Y1ZYX1dFUWFZTmRyV091TEY=').decode('utf-8')
    total = value + len(text)
    return total

def _ςФоΕуωοоΕЙνξΦΖеЫ():
    value = 187129
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BjXNXAg2q4MQD1yr7nHEEzIL/j4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚфΗЗкΖтЮΓвυ():
    value = 674557
    if 60 * 61 < 0:
        _dead_3444 = 936
    text = __import__('base64').b64decode('ektxZFZLVzNzNV8ySGExNERUNV8=').decode('utf-8')
    total = value + len(text)
    return total

def _фΣХλЬΩНЛмКХЭΕпЗТ():
    value = 740379
    text = __import__('base64').b64decode('T1pIS2ZjNGxsSnd1V2lRRWJpVk8=').decode('utf-8')
    total = value + len(text)
    return total

def _ηЮуλωΖмчΠ():
    value = 934160
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JD7tTEc66ZgTawOP8ny4HgkexTs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыДΗΧΖРλΩивΥρ():
    value = 542326
    text = __import__('base64').b64decode('Zmtua3lhcGRVY3NBYkEzSFBvZkc=').decode('utf-8')
    total = value + len(text)
    return total

def _уΙγΠПЦοδЯяаΩСзУ():
    value = 954536
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MCbXR38t6qYQCgm3kFy8MxN91kI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜεΟγйщзЩсΖШΛл():
    value = 691419
    if False and True:
        _dead_7564 = 960
        560
        _dead_3875 = 798
    text = __import__('base64').b64decode('Umo1SUtxSzlWWjNGU0J0SzFZZmg=').decode('utf-8')
    if 48 * 37 < 0:
        886
        _dead_6293 = 585
    total = value + len(text)
    return total

def _ХГЦаΩΞЛбЬюΒ():
    value = 119803
    text = __import__('base64').b64decode('TzNyaXI2WnZCRjRoZGZKNUdpTTI=').decode('utf-8')
    if False and True:
        pass
        _dead_4425 = 213
        pass
    total = value + len(text)
    return total

def _дΚыуБЮЯΔ():
    value = 59498
    text = __import__('base64').b64decode('R1luM0xZem5lR2Y2RkRQUlQ4YjE=').decode('utf-8')
    total = value + len(text)
    return total

def _χΕсхемЩΝхΒΗфпоь():
    value = 370393
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAvNPVU62bwAKzmn/2W1Ag8YyVQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΜЭьυТЧΓзб():
    if False and True:
        634
    value = 717207
    if len('') > 0:
        _dead_7076 = 744
        331
        672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HHn0OAIe5ooiG1uNkUexGxo5wnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_1261 = 288
        477
    return total

def _ΤЛйрΡΡъЪχψ():
    if 71 * 39 < 0:
        599
    value = 784894
    text = __import__('base64').b64decode('VlpkNnRmYURxUmpHeXRUUGtmMUU=').decode('utf-8')
    total = value + len(text)
    if 59 * 14 < 0:
        pass
        9
        pass
    return total

def _ьлЬιДΦФχνЗτз():
    value = 877423
    text = __import__('base64').b64decode('c2VGYm5JZ0ttWVE2bmtkOURFdko=').decode('utf-8')
    total = value + len(text)
    return total

def _θдтВПξοзΧйΟΟψГЭН():
    value = 857686
    if len('') > 0:
        213
        _dead_1748 = 123
        pass
    text = __import__('base64').b64decode('Vnd0ZmxqWFlmNEptcDREUm01ZFQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦФпοгеαРЪфСфφЧ():
    if len('') > 0:
        712
        53
        pass
    value = 23089
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyDwYkZp86NWLSTw2wegDgkD/EM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЭΑсΗБШЛтЗΚЮл():
    value = 490659
    text = __import__('base64').b64decode('RHhxN0FuTTlKZUtYSk1neHFaUWU=').decode('utf-8')
    total = value + len(text)
    if False and True:
        384
        _dead_6993 = 227
    return total

def _ΔΦηаςΛЬγΟцЬΝеЪ():
    value = 490918
    text = __import__('base64').b64decode('bjZ1b2NLTVU5aXVVZ1NaRm1hRVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭшТдЯΤΩΔυюι():
    value = 315081
    if 93 * 17 < 0:
        689
        _dead_5591 = 784
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BAi9RmM13b0FGF+t8AaGEnMYsmI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        787
    total = value + len(text)
    return total

def _РажЕИпВΖыфКтφлА():
    value = 579805
    text = __import__('base64').b64decode('cW03a1ZYbHJ6TlFOeXNpWUlVS0w=').decode('utf-8')
    total = value + len(text)
    return total

def _ΞгκДЩισφгΣιδСюзт():
    value = 784783
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KXv1OEUMyvkFKAKK4gCGLXc1zkw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЧυπΕзнвδτкπβШ():
    value = 302249
    if len('') > 0:
        192
        653
        pass
    text = __import__('base64').b64decode('aXpKXzd4dzZBUXRYWnpiWE43aTE=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
        236
        pass
    return total

def _ρКВωΗΚθРκЯЗΘξ():
    value = 398762
    text = __import__('base64').b64decode('dERWRzc1ZUJrV1BuUUxGTlNrY1c=').decode('utf-8')
    total = value + len(text)
    return total

def _ΖνεЙНюνяΨμΡДД():
    if len('') > 0:
        pass
        946
    value = 478803
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwjxXF4e/JESNSv7znKVICICsFk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ебΤωΓКςΥс():
    value = 238110
    text = __import__('base64').b64decode('eGplTHlZVlBJNmxSUHh5V3g2aDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΒΤβτоеκпДъφΖΘсь():
    value = 869568
    text = __import__('base64').b64decode('bmdpZXF3Sk16c1F6NmdoY2ZlRno=').decode('utf-8')
    total = value + len(text)
    if 16 * 18 < 0:
        pass
    return total

def _ЖΧυБΝуοНвГмшΡ():
    value = 169996
    text = __import__('base64').b64decode('S0dEU3Rib25BNkYxbFZEazhuSEk=').decode('utf-8')
    total = value + len(text)
    return total

def _ΟΠνмАаΜЗЕьЬιбωΥ():
    value = 691783
    text = __import__('base64').b64decode('RVVMZzBTaDcwbVcxSVJaM3FRdHU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬΥЪΟΧжβОεЦЭΚХчоμ():
    value = 347473
    text = __import__('base64').b64decode('dE9XZDF1WjNXbW1ac1lKd1ZjZzQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        181
    return total

def _ξαшЧХμчЫλп():
    value = 338707
    text = __import__('base64').b64decode('bk9UcWVxelpMYlhpUVRPY2hBYm0=').decode('utf-8')
    total = value + len(text)
    return total

def _ЦΨκΦμΤΠдъпшБφΕ():
    value = 624878
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiTTRwIsrvAobljz0WW9DAd4zDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΥΙтΜсЪΚйβмРБΥдФН():
    value = 829402
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ISLhVGlhzboTFRuangTHDQgftl0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟЙзΙжПττЮ():
    value = 32318
    text = __import__('base64').b64decode('TnNOdGlBemJIeXV1bHEyZ3RKSkQ=').decode('utf-8')
    total = value + len(text)
    return total

def _щμΕΘЬφΜсΙЪэζнЕЕЖ():
    value = 918283
    text = __import__('base64').b64decode('TUxMY25rZkgySFdDODd3clpZcUY=').decode('utf-8')
    total = value + len(text)
    return total

def _чΤΥАШгИХΡ():
    value = 428350
    if False and True:
        _dead_6304 = 732
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NHv8RkY6z4wWHFer71SgPAs29k0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        550
    total = value + len(text)
    if 98 * 50 < 0:
        965
    return total

def _ЙςЖαξηЮбДδНш():
    value = 956769
    if False and True:
        _dead_5179 = 320
        pass
        _dead_4204 = 206
    text = __import__('base64').b64decode('REZXUFcwdmVSYldqdVZhSVpIYVA=').decode('utf-8')
    if 67 * 81 < 0:
        _dead_6435 = 803
        465
    total = value + len(text)
    return total

def _ΕЪЬЙЪеβФьоη():
    value = 992968
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiPKbVAtqZ5aPTm6wmmiZhQX4mo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 85 * 95 < 0:
        913
        _dead_2702 = 257
    total = value + len(text)
    return total

def _ΥυшгпжУζйΦΦЧ():
    value = 691733
    if len('') > 0:
        _dead_6624 = 546
        _dead_2611 = 134
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ExzgSmcb5o0gEFyy6mfJJBcqt0E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        653
        282
    return total

def _υтОЬаΨрβжΖΓΩжНС():
    value = 820424
    text = __import__('base64').b64decode('RWFZZkpBeFhNWU9WbzhIRDRVOHo=').decode('utf-8')
    total = value + len(text)
    return total

def _гΣынэΕΦДΧК():
    value = 274993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MgjtRXAY55EEEACK8F6KIA0VsTw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АξфοущξοΣЬΚκдΗлω():
    value = 307592
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IHbpegcu3aYiFBul+mSqYS4MwDc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шЕЗеΛшСγΠХρВГлб():
    if 93 * 58 < 0:
        _dead_7460 = 639
        pass
        pass
    value = 768283
    if 73 * 99 < 0:
        994
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Mz7iR1os8ZEpFimLn0CfEAE6tjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _иξУчФειЯЮΡДхП():
    value = 386701
    if 39 * 99 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DhnqZUsv54BbEAanwWebZwsXxXw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ятΨλкγСΛΟлΖЧяШ():
    if 98 * 70 < 0:
        632
    value = 78773
    text = __import__('base64').b64decode('R05XczFLamVaMno5ckg0M0d2Uzc=').decode('utf-8')
    if len('') > 0:
        896
    total = value + len(text)
    return total

def _ΟЙоЙьбАηыбЯ():
    value = 491339
    if 45 * 12 < 0:
        962
        448
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAXsTUY66JcMAw6Zzm+KEj88tWA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        394
        856
    return total

def _ИБηЗПДФОИζтя():
    value = 877186
    text = __import__('base64').b64decode('ZHR5Q0ZjbWdWckU5emMwR0RPVjk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        343
    return total

def _ьдсοοησμκдиДΠ():
    value = 82308
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JgjqdHBq/Y9XHlm1ygeJGhQ6y30='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7839 = 427
    total = value + len(text)
    return total

def _ГКΑΩэЭиИ():
    value = 398319
    text = __import__('base64').b64decode('bVA2ZGRVTEV1WG9rdWtNMmVIYjI=').decode('utf-8')
    if len('') > 0:
        _dead_6641 = 629
    total = value + len(text)
    return total

def _γДЪрдЧлΗ():
    value = 133180
    text = __import__('base64').b64decode('dGNvMWRBZ3Vzb0pJejVlWlZwVHA=').decode('utf-8')
    total = value + len(text)
    return total

def _жЗчσНЖъΘΓξЖΡлЦοΔ():
    if 15 * 14 < 0:
        _dead_2738 = 452
    value = 674748
    text = __import__('base64').b64decode('cFdkREZmaDhVd0dJcUNMXzVGVUU=').decode('utf-8')
    if 11 * 43 < 0:
        _dead_3523 = 718
        _dead_9091 = 518
    total = value + len(text)
    return total

def _ИшΙΟХΘйЧУТАдΠ():
    value = 221556
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('L37IZEYPp6lRESa2x3iKByJ/6U8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыγΥΕЙпсАфζЮжЮΝ():
    if 15 * 16 < 0:
        _dead_9120 = 236
        _dead_3937 = 220
        _dead_8341 = 350
    value = 587167
    text = __import__('base64').b64decode('VDFnSE5HN01ycHVvSklHckY5V2g=').decode('utf-8')
    total = value + len(text)
    return total

def _ДнФτσМΠγМΘ():
    if False and True:
        _dead_4763 = 584
        _dead_1172 = 930
        _dead_2839 = 416
    value = 648004
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgfnZVc48K4KER6CwnKxECkj52U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        314
        pass
        489
    total = value + len(text)
    if len('') > 0:
        444
        _dead_5073 = 902
    return total

def _шЪвЛαДδзΘН():
    value = 628077
    text = __import__('base64').b64decode('TmduX2FSY0NaY09IMWhGUmx1MVU=').decode('utf-8')
    total = value + len(text)
    return total

def _ωкΛрφΜсχρ():
    value = 314215
    text = __import__('base64').b64decode('ZWs3VWwzRHo2bzhVV2ZjZFJqYVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΧЭоξδмΡЧйбεΓθЕм():
    value = 993363
    text = __import__('base64').b64decode('clZyYkFJMHhHc09EMWEwakdrMWc=').decode('utf-8')
    total = value + len(text)
    return total

def _ехжμыюРχбЫ():
    if False and True:
        _dead_4114 = 57
        _dead_8754 = 769
        115
    value = 31655
    if len('') > 0:
        87
        pass
        pass
    text = __import__('base64').b64decode('R0NSWHpaR05GRnVDeXJuTGJUUWw=').decode('utf-8')
    if len('') > 0:
        _dead_2543 = 189
        _dead_3826 = 54
    total = value + len(text)
    return total

def _ърФΥΝьГСΥΠΨ():
    value = 564016
    text = __import__('base64').b64decode('T2VrWXg5MHVTdk1tTnRCYlhpbmk=').decode('utf-8')
    total = value + len(text)
    return total

def _εьИъНΡεбЕΕςΠЯθам():
    value = 526560
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jzj2X3MO/KkTNyXzmneXYHV4vFs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΛκДХΟЙΡЯ():
    value = 865830
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fgy9Q3wR+6tSAweOx3KkNj0/5j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДσЮМьиОЖθΚΔθ():
    value = 726901
    text = __import__('base64').b64decode('andZTzBjWmtUaUJnUlFDckJhbkQ=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _εчΟοъδЧцδН():
    value = 31243
    if len('') > 0:
        899
        _dead_2007 = 360
        114
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CiLLXF0L2qkHCyewxkOaHSo911E='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _аСсκсΚЖтпπζ():
    value = 470414
    text = __import__('base64').b64decode('WUc1aTBkbXRaamIzMERudklJSEI=').decode('utf-8')
    if 57 * 100 < 0:
        _dead_2198 = 66
        92
        pass
    total = value + len(text)
    return total

def _СΚτыфешνα():
    if False and True:
        pass
        pass
    value = 213557
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSexb2Ywp5oEPwWkwlSlHRMa3E8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 62 * 7 < 0:
        _dead_6564 = 746
    return total

def _ψжыξЛγΞЯ():
    value = 94501
    text = __import__('base64').b64decode('amZ0TkNZWmJQcldUUHpNY0dhQ00=').decode('utf-8')
    total = value + len(text)
    return total

def _ФЙИНнΨяχГΠΞΠЬЙЬП():
    value = 833591
    if len('') > 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KDXePEYs6qlRF1qix3OZLSJ4tFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΑФыοΒвТΨЦΘаФ():
    if 25 * 25 < 0:
        _dead_5930 = 922
        62
    value = 872804
    text = __import__('base64').b64decode('Z3N2bzVETFlHb0hOVzBpNldoaG0=').decode('utf-8')
    if False and True:
        354
    total = value + len(text)
    if len('') > 0:
        pass
        pass
    return total

def _юуЬИцЦθаЫУε():
    value = 852486
    if False and True:
        pass
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Fx/NaX0W1PsWEB2nxHKqZjx37jg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        771
        432
    total = value + len(text)
    return total

def _ΚАΤАШщσΧЗΝЗΨКθσ():
    if len('') > 0:
        pass
        144
    value = 443903
    if 48 * 58 < 0:
        _dead_3548 = 779
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FwnoZlkw7bA0Pieo2X6eOSZ3wUg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δΘЖФврХШ():
    value = 183970
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BADxeggQ2IkCDQm20AeCOy853Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κΘΡзΤИεуΣ():
    value = 412113
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KB/xbXQp8YYQaC2Q6UO4MRws6D4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жΒΘνвхΒΘчТЖΔь():
    value = 548856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAyxSwUK/f4CABiC/E+iHgs1zjg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_1922 = 471
        380
        508
    total = value + len(text)
    return total

def _блΝЖвΛΜСт():
    if 2 * 67 < 0:
        pass
    value = 557984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ln3oeHctzJIHMFrxnECCHzM6tz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _упБЬδξψфΕхΜхЕΔ():
    value = 83970
    if len('') > 0:
        _dead_9814 = 986
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CxzbXW4dp5gCAzyt7AGgACo7vE0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 58 * 79 < 0:
        _dead_6228 = 650
        141
    total = value + len(text)
    return total

def _цаΙΠβЕнΩХе():
    value = 659152
    text = __import__('base64').b64decode('eE1LS2N0NTJmcUw3ekU0SHZ5Njg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        646
        _dead_1624 = 683
        pass
    return total

def _УрΣκЧчΥНΠΚвй():
    if len('') > 0:
        pass
        _dead_9812 = 483
    value = 26628
    if len('') > 0:
        pass
        _dead_9114 = 639
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AznMZ35s261VIBiP/3KvYzV80n0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _кδλвνрδсй():
    value = 628071
    if len('') > 0:
        298
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Cj+9XwUpwbBbGVim7F6pIHEqwUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 36 * 99 < 0:
        pass
        864
        214
    total = value + len(text)
    return total

def _ΦуЗЭΖЪЬψ():
    value = 391322
    text = __import__('base64').b64decode('QnVqQjVHTXExYmx0QlJLZm1FMmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ΡσзьЪБλНσДДΤΤΨΔК():
    value = 828802
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NjjtN2A89ZsnagL3/Q+xHyQpwX0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЩγδЗЩПЕБΕКПР():
    value = 600127
    text = __import__('base64').b64decode('dVE1eUdkdFA1UEtwOEdoamg4VUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ъαМйОβΝкзκκΡ():
    value = 309630
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASmzOlMGrKQvagS08FelJgYY0ko='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 65 < 0:
        757
        _dead_8896 = 661
    return total

def _иΥЪςчМγξΥоοΠ():
    value = 570213
    text = __import__('base64').b64decode('ZkxSRjZ0YnlmT3dpVnZBTkdpWk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ГΠοσВЛНгШЮλКζГюЬ():
    if len('') > 0:
        263
        pass
    value = 278867
    if 29 * 85 < 0:
        _dead_8418 = 150
        pass
        _dead_6451 = 253
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iwa9TVow36BWCFeB6n23LjAYtX4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ОцщΙЙξχИιΝЫΙψΣνς():
    value = 312771
    text = __import__('base64').b64decode('SnEyRUJPOTMxZ014MzBreGx6bEU=').decode('utf-8')
    total = value + len(text)
    return total

def _δФРζАΗШЯЭσΝδΣв():
    value = 365698
    text = __import__('base64').b64decode('YlpKUWYxZVRpSHdLODdLNTlCcUY=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        860
    return total

def _вυееЖΥъЩЦзΨΧΠгχЕ():
    if False and True:
        51
    value = 905643
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQLgZkcv2akMLF2l3nWxZi8i138='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔЖΡИГжуУβΦοиЕΝ():
    value = 876546
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BybbTWgV+YoWEiD2mECaZzQ30Gs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝОЫиΩΛчЬ():
    value = 961565
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PyG3OAkb3ZoWHyb7+UW+BBo99mg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _τΤхУЬχжρЧъыΑ():
    if 65 * 51 < 0:
        _dead_3753 = 600
    value = 62869
    text = __import__('base64').b64decode('RjJTQVBfNV95RHhFTUVpMjVTYVQ=').decode('utf-8')
    if len('') > 0:
        pass
        pass
        _dead_5716 = 478
    total = value + len(text)
    if len('') > 0:
        _dead_4370 = 747
    return total

def _ЖЭЫЯсκφРρΞΚмг():
    if len('') > 0:
        940
        271
    value = 99183
    text = __import__('base64').b64decode('amEzZ2RpeXVmRWZHdk1lSW56TUM=').decode('utf-8')
    if 48 * 56 < 0:
        233
        _dead_7598 = 274
    total = value + len(text)
    if False and True:
        359
    return total

def _пУδПΣЭйзτнЧθЭ():
    value = 310560
    text = __import__('base64').b64decode('YVZ5UkFMRkN1elBSbEtHR1FfWWM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙζАσΛШνξя():
    value = 580005
    text = __import__('base64').b64decode('UzhuSW0yWG9jWG15TGlzNUdFNlQ=').decode('utf-8')
    total = value + len(text)
    return total

def _иЩжΩзαλΠΦν():
    value = 179343
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AnzIOFM66pA3aSWWwEWxbHwC7EI='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙУКрθБдЩКФΘчЛИБ():
    if len('') > 0:
        54
        _dead_8968 = 228
        pass
    value = 924619
    if len('') > 0:
        _dead_6314 = 742
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IjzNdwQKq4U6OBfz7Hu0ZB8gyVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        684
        pass
    total = value + len(text)
    if 40 * 32 < 0:
        pass
        pass
        _dead_1977 = 206
    return total

def _ωъИшΓкЬЫψцШ():
    if 80 * 42 < 0:
        _dead_8346 = 388
        862
    value = 175782
    text = __import__('base64').b64decode('ZmhfRTNYQm1EYTZVRUdQVHVrV1o=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓθЦβΠфΣБιъ():
    value = 574581
    text = __import__('base64').b64decode('WThiU0pJTmwzX3lMRFdyTW0zek0=').decode('utf-8')
    total = value + len(text)
    return total

def _луЬхтаΔОЪд():
    value = 902171
    text = __import__('base64').b64decode('anVNWUkzTERsaklHdW56XzhPako=').decode('utf-8')
    if len('') > 0:
        _dead_8512 = 443
        pass
        _dead_3241 = 249
    total = value + len(text)
    if len('') > 0:
        _dead_6430 = 904
    return total

def _πкУΚμШАЫВΣ():
    if False and True:
        pass
    value = 773719
    text = __import__('base64').b64decode('dURXVThBa0xXSTJKTmtmMnVsdWk=').decode('utf-8')
    if False and True:
        946
    total = value + len(text)
    return total

def _ЛΣЕΘΙйДеПΥΣΩШ():
    value = 215514
    if len('') > 0:
        965
    text = __import__('base64').b64decode('bVB1a2x0akRjR1BwQTlidGRSV2w=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        285
        271
    return total

def _ьΘПеΝхΚΣЦЕΘΠω():
    value = 646213
    text = __import__('base64').b64decode('eGdSb0IwajV2MHpNVGR2T0U1N2E=').decode('utf-8')
    if 25 * 5 < 0:
        _dead_3306 = 610
    total = value + len(text)
    return total

def _ВРκονйγΙш():
    value = 854519
    text = __import__('base64').b64decode('dWJFSTd2cEJlQTVqdkpyNVprNXc=').decode('utf-8')
    if len('') > 0:
        528
    total = value + len(text)
    if 6 * 64 < 0:
        189
        pass
        pass
    return total

def _ЕЩΕеΩэΔΧщΓρДσ():
    value = 954270
    text = __import__('base64').b64decode('Y19wd3lMSnVETmVaZDhaSTAwRGo=').decode('utf-8')
    total = value + len(text)
    return total

def _ВхΠΤυЩЯГЗΝъωчζαζ():
    value = 827263
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix3pYUgj9pgAGwi2xgbBEAg+tEM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        692
        _dead_1765 = 28
        pass
    total = value + len(text)
    return total

def _РцзηэηзθгдΘяχЖψ():
    value = 187430
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kibvf3403IQkLlaAkX++HBEd1j0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΤωτΠΧАХαΚΨλШψφ():
    value = 385297
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KhbvYEQX5owmIwWRylnDJSAX1lg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕηΕИθΚУнАΓΝ():
    value = 927530
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FDm3altvx68pPz2N7XevM3MC6Fk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 67 * 100 < 0:
        _dead_6154 = 192
        _dead_5691 = 272
    total = value + len(text)
    if False and True:
        686
    return total

def _ШΛσвыХΛЯтιУТъыψ():
    value = 145492
    if len('') > 0:
        333
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBDRXGc86/4VOy2562aXYDU1s2c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _фΚкРМЩБхοκк():
    value = 652165
    text = __import__('base64').b64decode('bUxPVzZiX1VDZFlFSUwyQ1JmU0w=').decode('utf-8')
    total = value + len(text)
    return total

def _лγГμΨтЪПΙСДявΛ():
    value = 19503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CjvsR2AD5KVRH1zx/1m6NgJ+818='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _эьБΨвЩΔСгμеΘ():
    value = 449153
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwbVZX1h178bCVyz3nKGYj8KskA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        169
    return total

def _φЗПΞΣаЖΗмМΦЗРΕ():
    value = 765366
    if False and True:
        pass
        _dead_6413 = 280
        pass
    text = __import__('base64').b64decode('dmtHd0tzWlhRRFEwVWVQM2tUN3o=').decode('utf-8')
    if len('') > 0:
        _dead_4876 = 884
        _dead_9195 = 791
    total = value + len(text)
    if len('') > 0:
        99
        574
        _dead_6436 = 842
    return total

def _μΑβЯЗЗΞощУчоΡЗНΒ():
    value = 30797
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PxnAaEY07r4Xa1eLymmYAB03ymM='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шдХθΙШΙΛυВ():
    value = 14629
    text = __import__('base64').b64decode('UTZCanZpZmdhbmhITGV2OXFkVXU=').decode('utf-8')
    if 57 * 8 < 0:
        776
        _dead_3387 = 327
        489
    total = value + len(text)
    return total

def _ΛмЬЛСфпдМЮуНП():
    value = 290589
    if len('') > 0:
        852
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BxfKN24r668lKSaM32GRYDUOsXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 52 * 20 < 0:
        _dead_5626 = 915
        _dead_9911 = 178
        _dead_5782 = 736
    total = value + len(text)
    return total

def _ЯФΦаΘπНΒЕβедΝΓФ():
    if False and True:
        _dead_6559 = 621
    value = 357773
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IXnMbWMr8aBWHhyNy3GdBi4AzU0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        _dead_9635 = 96
    return total

def _ΔБδпчЭμΨΧΛМΖΣΞ():
    value = 303151
    if 81 * 79 < 0:
        pass
        _dead_2603 = 54
        _dead_5062 = 195
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JwK3ZVYr8JAvERyx71mRMx088lo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_6374 = 262
        759
    total = value + len(text)
    return total

def _ΜιъвΠνλЬωΨκ():
    value = 234728
    text = __import__('base64').b64decode('WUNTU08wc1lfWllXdGl6Q2szNUk=').decode('utf-8')
    if 27 * 73 < 0:
        _dead_7107 = 735
        pass
        _dead_1190 = 349
    total = value + len(text)
    return total

def _ςюЬЕУиасЪЖ():
    value = 585842
    text = __import__('base64').b64decode('YVdGNkZXZnlacEFuMXdkY3lrUDc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЫПСЕъΦДе():
    value = 341984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PTiyV2IDx5gHMjCv3AeePRIt52A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_3147 = 954
        823
    total = value + len(text)
    return total

def _ΕСЯеχеНэЖЛ():
    value = 789904
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LguxVwkw1IQPAx2B/liyOCg303c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗЮΝзοЦаыξЙΔ():
    value = 343719
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ix3UdkFq2ZcQGCqqzleWDHMZ0VY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σъицифхЛъ():
    value = 919502
    text = __import__('base64').b64decode('U1hTQzRZSkZsVzh5akQxZGhhQ2M=').decode('utf-8')
    total = value + len(text)
    return total

def _хгРЛЪΜфбяοЫм():
    if False and True:
        pass
        _dead_7059 = 901
        493
    value = 559674
    text = __import__('base64').b64decode('eHNFRzcycE1uQmJYR2t1NUp0blA=').decode('utf-8')
    if len('') > 0:
        _dead_4566 = 284
        _dead_4391 = 905
    total = value + len(text)
    return total

def _фдХрζεΜбπыλЦςшΖ():
    if len('') > 0:
        _dead_7030 = 821
    value = 265936
    text = __import__('base64').b64decode('Z20xMW9tV0hHZFphTXNMZWl0NDg=').decode('utf-8')
    total = value + len(text)
    return total

def _МтωчΟχъыЖΧθРШΟ():
    if len('') > 0:
        pass
    value = 536466
    if False and True:
        pass
        194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kx7+QwQYpoUIaiW5kACyPCI7wWk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тρЗкПэΩЛмЬЯ():
    value = 813983
    text = __import__('base64').b64decode('REtsd0ZjcExFNFFsU3hsME5ZM08=').decode('utf-8')
    total = value + len(text)
    return total

def _вεрДЬТнЮмΤ():
    value = 320270
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LwnDRgdszpEFHV+TyQ+2E3wQ8UU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θΒВΦрβщФσ():
    value = 33386
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQW2R1g25qE0NwiVzEKjMTYq92w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _δγрАЬЧΜΒφεвΙ():
    value = 528115
    text = __import__('base64').b64decode('SWY3ek5QSU51c2dERVdxRWJBZUM=').decode('utf-8')
    if False and True:
        pass
        _dead_7980 = 656
    total = value + len(text)
    if 16 * 88 < 0:
        39
    return total

def _ΡФггΗпЗεκΘκэО():
    value = 94983
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChrJR2k88486Njn662OEZwY51jw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        731
        pass
    total = value + len(text)
    if 99 * 41 < 0:
        _dead_2873 = 838
        383
        pass
    return total

def _ΞЩтεδЯаαЮκ():
    value = 451122
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CR+0OXIV+KIEaRWn/nekGhQ85mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ХДыфυκдТΡΡЛ():
    value = 432195
    text = __import__('base64').b64decode('bGZLRUxPT2xFdGJsUk9VcmVkT28=').decode('utf-8')
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    print(__import__('base64').b64decode('ZQ==').decode('utf-8'))
if 90 | 1 > 0 and __name__ == (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('GhDpb1g3wZc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()
elif 63 * 48 < 0:
    _dead_4621 = 722