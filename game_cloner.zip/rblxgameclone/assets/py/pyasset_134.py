#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
os = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
time = __import__(__import__('base64').b64decode('dGltZQ==').decode('utf-8'))
random = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ny7qal40'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
string = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Njv2Z18+'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))

def _ςРхЯΤΕЦδΣφуΕΕа():
    value = 309751
    if len('') > 0:
        937
    text = __import__('base64').b64decode('QTdfdXJjWmJnaW9vN191TTFtQkM=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖьγИвтуΘΤЮφЯэ():
    if False and True:
        pass
        pass
    value = 560686
    if 2 * 13 < 0:
        0
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kxq8f18K94wnEwSt+lK7LggCzz4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖΟцΝЮχнΓЕωΒХЗ():
    if len('') > 0:
        709
    value = 132760
    text = __import__('base64').b64decode('WTR2Tnd6N2JLc1dfTllLakdVQTk=').decode('utf-8')
    if len('') > 0:
        pass
        291
    total = value + len(text)
    return total

def _ЦЭгιДεЗЧωфβщС():
    value = 786838
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CzbsfHNo6qM0FVyLm3+XEwQXzDo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
    total = value + len(text)
    return total

def _ΚΤκΔДΘжОх():
    value = 92984
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BhvubwcR+K83PwrykXHBGDMg1m0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ФφΩдΕΨШЬЫЩдЧΗΡτП():
    value = 163039
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dja8VFlp8PAhGB2v/l6TNzR97mA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ηυХлοНВΣюбэΜЧψиθ():
    if len('') > 0:
        254
    value = 56477
    text = __import__('base64').b64decode('eDcySVBCMkFTNURLcmp3bVc1cmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ΑεпйπБЦдиКΨччФ():
    value = 670425
    text = __import__('base64').b64decode('YVlNZkVQVmVCa1JiZ1pNYV82WG4=').decode('utf-8')
    total = value + len(text)
    return total

def _СζЬΤγцАИΝΧУΜτ():
    value = 562909
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LyTXWnhqpoc6MSyx4lC4LD07814='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        65
        54
        416
    return total

def _хΗсЯΨЯхцТэζкςа():
    value = 25648
    text = __import__('base64').b64decode('VTN4X1h0QWJWbkpmX1JQeHlRZmU=').decode('utf-8')
    total = value + len(text)
    return total

def _ПΜЫпнсΕΚГт():
    value = 523201
    if 78 * 51 < 0:
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lnz+enMv/b0TEDaXz2WJBS4ayjw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 69 * 75 < 0:
        pass
    return total

def _МЫπΧφЙΣйΔΧзВςΩΖ():
    value = 820033
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MC7xbGgLqpEvIjyL8F6YIQAjtXc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЬξΧημхЯиъДαΩсΕг():
    value = 875922
    if False and True:
        373
        389
        pass
    text = __import__('base64').b64decode('a09Xb21oTWNqYWdVNkszbmoyV1o=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        494
        _dead_1643 = 808
        pass
    return total

def _ТτЧΠЗθνΔФ():
    if 19 * 68 < 0:
        _dead_7213 = 517
    value = 472667
    text = __import__('base64').b64decode('VUdlazNfUXJ5d3NjMF9tMVZldjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ьψшщδΝЦГНБξΤπЧсШ():
    value = 154287
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('eVdmVXROR0hPb0U1MVRrQ3dBVEM=').decode('utf-8')
    if False and True:
        pass
        pass
        105
    total = value + len(text)
    return total

def _ЗхЧηПАΧмкΡЛΣουΓм():
    value = 231779
    text = __import__('base64').b64decode('bHZMU0JHcjJuRU1pREhsMnMzaEk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
        350
        _dead_1228 = 25
    return total

def _нςыΛЖΕΠк():
    if len('') > 0:
        _dead_1907 = 954
        736
    value = 167535
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KgXtSEYx26wVPj+h8XSdBgMWyGA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 35 * 52 < 0:
        _dead_5467 = 36
        pass
        _dead_2448 = 883
    return total

def _ψКοМηгΦЪЩ():
    value = 997406
    text = __import__('base64').b64decode('TWZ4NXVDUVNfX3hmWWE4Q1M0eTY=').decode('utf-8')
    total = value + len(text)
    return total

def _ъеΥτΗΘтыΦвΙΞХ():
    if 80 * 32 < 0:
        199
    value = 12860
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDmzWWgG64w8E1/y/E+yNwwn9kc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЖыЙΒмαΗψйΕΟΡщ():
    if False and True:
        605
        pass
    value = 143083
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EgriWHwO9fAtFlzxkFy0Zxw8wjs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 94 * 45 < 0:
        17
        pass
        941
    total = value + len(text)
    return total

def _НТμжзпτοнГоБΣφΜ():
    value = 315903
    text = __import__('base64').b64decode('bG83RWhpaU81RWtYcjZ3WVcwV00=').decode('utf-8')
    total = value + len(text)
    return total

def _мыбФζлсυ():
    if False and True:
        208
    value = 984395
    text = __import__('base64').b64decode('V0hFdWRFUmVQSXpsbmg1YTg4dWo=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨΛΘЪλοЬй():
    value = 546305
    text = __import__('base64').b64decode('ZDhjUmxKSG9nbG85VFVJYmJ4UVc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪΩΚχΘцΣΔΘηУβВσЩμ():
    value = 977520
    text = __import__('base64').b64decode('VXZjTmplcThreHd5MTNiZVpWVWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭхЭуΡяРД():
    value = 520139
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBjdSHU26vsbKhm57EPIYi9820Y='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ыуωψΨκСΥΞг():
    value = 933568
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MB3Md1gh9Kc8AzCy3VukO3R78F4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒαΓεжИсЦΘЙιοкЯв():
    value = 463374
    text = __import__('base64').b64decode('UjQ4MW01MDZndzdQaXB5NmdqM1g=').decode('utf-8')
    total = value + len(text)
    return total

def _ДΞΚФщΠΝеаνщЫ():
    value = 287644
    text = __import__('base64').b64decode('bEZjWW1GNXB2RlpkeTRLSk5NeVk=').decode('utf-8')
    total = value + len(text)
    return total

def _щяτыСуΜЫΣЦнψА():
    value = 738781
    text = __import__('base64').b64decode('WXVQb2FuaGhHeUJnTzhQbUFCRmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ьълнъуτβБμБ():
    value = 709774
    text = __import__('base64').b64decode('YzRIYk1xemZaTGxENHZVRFlhZGM=').decode('utf-8')
    if 87 * 57 < 0:
        pass
        36
    total = value + len(text)
    return total

def _ГΙВВδэЮΡΝТЙЩΛОЕμ():
    value = 49076
    text = __import__('base64').b64decode('cnlEOEVSOWNOZjNnTFExWGJYejQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ЖΚЮηЬХТзоρЩρьо():
    if len('') > 0:
        pass
        883
    value = 287821
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EzjnWXk62bBUKjui4WCTGi8Zyn0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йεγΩΚςΞУНШб():
    if 56 * 68 < 0:
        _dead_7307 = 680
    value = 718116
    if len('') > 0:
        pass
    text = __import__('base64').b64decode('bHRQV1V5ZWZsdVJUeERENDFrUG4=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _ЭпЛΠЩΙεцΤΚΛΔΣβ():
    value = 323735
    text = __import__('base64').b64decode('aXdJczVaRGpRT196ZDl0bFJ3S2E=').decode('utf-8')
    total = value + len(text)
    return total

def _αΦΚΗэφэФθΤМ():
    value = 732445
    text = __import__('base64').b64decode('a0Q2WFhNeGpzVVR5MV9KOUhYSDM=').decode('utf-8')
    total = value + len(text)
    return total

def _βжωΤδДюΝφσ():
    value = 601867
    text = __import__('base64').b64decode('d01yVjA5NHBleFZ1c2VxamhQQnI=').decode('utf-8')
    if False and True:
        _dead_9183 = 371
    total = value + len(text)
    if 56 * 11 < 0:
        _dead_5274 = 528
        _dead_2694 = 302
        pass
    return total

def _оοθЮΙКзλыΨ():
    value = 363048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ATrjPG4Kr4MvNQCoxX2oFScQwT4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        pass
    return total

def _яΛρЦΤΨψв():
    value = 70526
    text = __import__('base64').b64decode('c3owcVprdGl5dlpwaWZDbFRtWWw=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _ИΨςгθИΥЪЮοφЪΙβп():
    value = 761993
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSWwNmM4+ZkqIgOHzliDBzZ7wUA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟьпΗΣΚφЦωЗААυы():
    value = 67474
    if 94 * 50 < 0:
        pass
        _dead_6331 = 119
        943
    text = __import__('base64').b64decode('cXlZc0FXbGRrTjJTcW9Pb2txVXE=').decode('utf-8')
    if False and True:
        _dead_9779 = 669
    total = value + len(text)
    if 28 * 16 < 0:
        pass
        909
    return total

def _пгΔΦΡТкПгЫдАр():
    value = 30626
    text = __import__('base64').b64decode('Y242N0JCZ2dNTk1tRllNOEdiNFk=').decode('utf-8')
    total = value + len(text)
    return total

def _еΙИИлΣПвγТЧГσ():
    value = 537046
    text = __import__('base64').b64decode('cFZTV3NyMEM5RUx6WjNJbFhyelA=').decode('utf-8')
    total = value + len(text)
    if False and True:
        901
    return total

def _τΗШυюЮΖλЕΣС():
    value = 655738
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NSTXV3Aw8K0RETX6mEKgHCJ7/n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΗИΜеΨΒгυюΖЬНβ():
    value = 122532
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HDe9WwVtz6oKLSKB3Gy9PgIJ70U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΟтьΛРЬκОΜсφЧΛ():
    value = 467582
    text = __import__('base64').b64decode('R2FxclRscWhnZVFBNnB2cUUwbUM=').decode('utf-8')
    total = value + len(text)
    return total

def _ШРмхНрΦγπпВРυζсЕ():
    value = 569711
    if 55 * 20 < 0:
        29
        _dead_3171 = 938
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BgXmVgIo7Z4iCzmc8n6kZRI64Ds='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΙσеΒгΧοфХΩзΡпΡο():
    value = 126197
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Dj3IRF8Urf4RNDuT6WSAbScYsnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЯΕяПщЗθХσΝл():
    value = 986856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDf9TwYYx/kiIBazz0SYOXAjy1s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψФНрΜζψχЯΛъ():
    value = 942569
    text = __import__('base64').b64decode('SG1ndHRWOFVOWW9sOHBtanBiTXY=').decode('utf-8')
    total = value + len(text)
    return total

def _сΔХπΝФΝя():
    value = 543025
    text = __import__('base64').b64decode('VU1JaXllV0xyZjZmbjRubGM1RnQ=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_7587 = 680
        pass
        pass
    return total

def _ыΝτζрБοψΠφОуФУυο():
    value = 468400
    text = __import__('base64').b64decode('aXVadGJjemFwUmZESk1PbVh2aFg=').decode('utf-8')
    total = value + len(text)
    if False and True:
        826
        pass
    return total

def _пΧαΥΤΛЯΑржнб():
    value = 380488
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AhnJdgML560Oah+nwXScYCss/Gc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _κюμОяΧΚΛψМЩ():
    if len('') > 0:
        527
        _dead_2303 = 850
        pass
    value = 750116
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DRjuOnI4+I0vLjyu+lXEJy86y3o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_4161 = 593
    total = value + len(text)
    return total

def _ΘσπМРσЪΡЦц():
    value = 324594
    text = __import__('base64').b64decode('VmJNcUVLd0V3UVdHXzJkNVdGdTk=').decode('utf-8')
    total = value + len(text)
    return total

def _ънΙХτρсΔΨψКщ():
    value = 618194
    text = __import__('base64').b64decode('SFFPNHJRMUFUTDEyX1BCMmtTMjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _θМфЖВйауδХΖнфωьв():
    value = 479822
    if 66 * 29 < 0:
        _dead_2233 = 235
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Nj7WfVoQ+Y9XY12w70PIO3YYwWw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЕδαψηштФλМιшщΖ():
    value = 988648
    if False and True:
        408
        916
        _dead_7638 = 75
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FRvuZGJproMqLjir3mSgZzc141w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_2055 = 481
    total = value + len(text)
    return total

def _ПчφκбΤшМΧГРιб():
    value = 665186
    if len('') > 0:
        850
    text = __import__('base64').b64decode('VTUwa2RlQ3BMc2dMbFU3TUNuYVI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_5003 = 697
    return total

def _ςсεБиоОзШы():
    if len('') > 0:
        pass
        384
        362
    value = 923828
    text = __import__('base64').b64decode('d2Vwb01XYV9vd01JWTBKVkpoZU8=').decode('utf-8')
    total = value + len(text)
    if False and True:
        550
        770
    return total

def _ЬйтΩΓеρπСЪАЩоШ():
    value = 708320
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FBnAXQA90aM2NiiQy0WxASp24n8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шΙМЧОυсυЛРπцΞКζЪ():
    value = 364722
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NRfFX3wr6JsqMyeP8EfDJQ8J01w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ψеЩΞзусРΨβгοφЮФ():
    value = 900619
    text = __import__('base64').b64decode('dXZEMjVSRUFyaUdLamJtRDA0ZFM=').decode('utf-8')
    total = value + len(text)
    return total

def _пΛФνЖΝнκЦ():
    value = 245107
    if False and True:
        pass
        _dead_5056 = 13
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CXnuPAlt5IcAIFmq8QakEDwbzmA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςρΝНЕσОСШюЗΚукяП():
    value = 457334
    if False and True:
        _dead_3403 = 240
        _dead_1486 = 694
    text = __import__('base64').b64decode('djNSSno0SDFqOGVjZGJpX05kb18=').decode('utf-8')
    total = value + len(text)
    return total

def _τΖαΥиФоνΨλ():
    if 5 * 57 < 0:
        _dead_6586 = 187
        298
        _dead_5672 = 606
    value = 917976
    text = __import__('base64').b64decode('TXc0ZHJFUHpDYkRBTUNsVmllUTE=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        25
        _dead_3705 = 976
        165
    return total

def _йκЦΨСΞΓЧШΡзΧтШчр():
    value = 914507
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AXrdanQa34woP1y7zgXDGxYd9Xo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _цμХАнΧιΙκХκ():
    value = 315176
    text = __import__('base64').b64decode('azgwUmx3dmltbDFfQm1VcjQwMWU=').decode('utf-8')
    total = value + len(text)
    return total

def _ЙЬΙЮчвнфяф():
    value = 918168
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LzjASEVs5rIrKQqw43iqDA8GtFE='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _υΣΡΚλΤИшΜθя():
    value = 987087
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('A3vwSksz+YBWPASN7nW0GB147jk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΚπЦЙиςΨжзν():
    value = 405888
    text = __import__('base64').b64decode('eU1lT0I1VmZCdVoyNkVOTjdUYk4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЗΘюсΜгχГРΩυ():
    value = 322044
    if False and True:
        708
        _dead_3987 = 913
    text = __import__('base64').b64decode('WER5R3VHVTA5NnYwalpUbzlHZHI=').decode('utf-8')
    total = value + len(text)
    if 51 * 52 < 0:
        _dead_1679 = 306
        434
        pass
    return total

def _τυΣэκАΧУΦзЩ():
    value = 50628
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AAT8TGhr6PAoKwizm36xOS5262U='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _УМлАΑжμЮДьПΤΓ():
    value = 502918
    if False and True:
        493
        pass
        _dead_5803 = 20
    text = __import__('base64').b64decode('eVZTVGtfTVdsOEdtc2NHbExUNlM=').decode('utf-8')
    total = value + len(text)
    if 55 * 11 < 0:
        _dead_4129 = 342
    return total

def _еκуΕτζΣαЬцГпТТ():
    value = 62006
    if False and True:
        pass
        _dead_5442 = 953
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BHznWkgq7rACEi2WmUzCEBIh6D0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _πкΚΥΧЫпζ():
    value = 53301
    text = __import__('base64').b64decode('Zm1NQzMya1IyM2VwV0FZcDVreUk=').decode('utf-8')
    total = value + len(text)
    return total

def _τΔпсψΥХκεΨφбАε():
    value = 828483
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jxr1Qgdt2qA1DQi1z1zHHnEV6XQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        _dead_8158 = 933
        _dead_3832 = 157
    return total

def _ςΞΞΘΠΧЫεφиψθСЕь():
    value = 537984
    text = __import__('base64').b64decode('ckV1am05ckxmMHdWczdBU1BxTHo=').decode('utf-8')
    total = value + len(text)
    return total

def _γзЬςБхЮе():
    if len('') > 0:
        pass
        628
    value = 737974
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('N3jnbAUO35oNaTeC0FyZbA55438='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _рЕоΗρΠМтψσоφж():
    if False and True:
        _dead_2048 = 115
    value = 325329
    if 85 * 82 < 0:
        _dead_3540 = 450
        204
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBnPO1kR56ALbViN/WG6ZQ0NzGU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 24 * 71 < 0:
        pass
        _dead_4495 = 769
        _dead_2437 = 324
    total = value + len(text)
    return total

def _αъмзΞнΤтЭεрК():
    if len('') > 0:
        pass
    value = 957590
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LHbvOwIw0/oJDTWvx2ecHhMlxnc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
    return total

def _фΣΞиξныЛθΗΩκλ():
    value = 579250
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JxqyYkUM2os1MwyM2mGfYHcmtmo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _енνхΕΞЫχ():
    value = 620710
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('EQfrfnIc+rArKi6LnVGJZSI811k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_7776 = 151
        pass
    total = value + len(text)
    if False and True:
        pass
        _dead_9519 = 962
        26
    return total

def _яеНЧзоьθспн():
    value = 562443
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Eh+2QwYU7K8ONSSoxVSiMy829UA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_5837 = 145
        pass
        _dead_6216 = 854
    total = value + len(text)
    return total

def _эЮΤВАΖОО():
    value = 856542
    if len('') > 0:
        pass
        _dead_1335 = 168
        843
    text = __import__('base64').b64decode('bmt2ZXhWS3diMGJSd1ZBc1NwanI=').decode('utf-8')
    if len('') > 0:
        _dead_1017 = 878
        pass
        _dead_2451 = 461
    total = value + len(text)
    return total

def _ΘюЙιΟИΔАΑ():
    value = 283354
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hxb3a3UX3L1VCiqw5VSpGxZ+yTk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9954 = 419
        _dead_9801 = 456
    total = value + len(text)
    return total

def _КАИъζαиДЦГдςΤ():
    value = 105194
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AATydlgqyaA6bF+m/ULCHnI2zTc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣщΥмАΨΞεНΔлЖ():
    if 6 * 58 < 0:
        pass
        856
        36
    value = 245820
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfBPGEP6pgHKyaVxV63OTR91zY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _яТξпктЖгγγ():
    value = 53833
    text = __import__('base64').b64decode('b01xd0tRb3ZYVms1em5JalFsZWQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨχРΚжкыβщжрΖД():
    value = 35786
    text = __import__('base64').b64decode('dkpKYzk4dk1DYUtqckJwVjhYdjQ=').decode('utf-8')
    total = value + len(text)
    return total

def _зηбΗδικЪРΗяСсп():
    value = 83051
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CAXKe0hux7BUK1n68kalJg0E/j8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
        _dead_5535 = 366
    return total

def _ΟЙощΠΡζεβГаДГ():
    value = 533572
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PQCzXltv9aQuORmTnEeaHBYJxXg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _тСмЯυκРв():
    value = 72597
    text = __import__('base64').b64decode('bnNGRXRXM09RQlQ4YzI5eHZaRjg=').decode('utf-8')
    total = value + len(text)
    return total

def _ВγυςЦсΔлφжεТПеΒ():
    value = 591294
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ERy3YlQx76UFDx+pmWOeLRwi8Wc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ЮνГИОщΓΣγΟ():
    value = 936288
    if 60 * 95 < 0:
        799
        189
        _dead_5481 = 883
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HBjrdgEe+/w2HAev/2WfHX17y08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξЙСЗρΖюлЦылΔΦΗТφ():
    value = 482061
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JifHWWMM7Y4HbRqc7wG7PxofzXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _АκсШУщБΝдΓ():
    value = 247539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FSH9fEgGzKITLlur2gCWFyN+5kk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        198
    total = value + len(text)
    return total

def _λλРΩкъЕЕ():
    if 55 * 34 < 0:
        _dead_3224 = 74
    value = 727641
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ES7gaFZv9K0FEwmU/F3JNjd29Eg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξпеРтшΟдаьΠдкΖβл():
    value = 274976
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQvmX3ocr4E3AySozgCUZS8Dxnk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _θυςχшЛΨφЖшΝ():
    value = 320733
    text = __import__('base64').b64decode('VXRqb1laRmNITXRNMFd3UTZfOVM=').decode('utf-8')
    total = value + len(text)
    if False and True:
        _dead_4008 = 706
        943
    return total

def _ΕНПйПΩРΚЗплЩаЯ():
    if len('') > 0:
        840
    value = 611240
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FgHxbVUS9aMVLVe1xXWYNzY8yDs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ςΒΟЯςΕжιχАПΛιρο():
    if 69 * 55 < 0:
        557
    value = 396754
    text = __import__('base64').b64decode('cjRLS3RUNk1lOXRSM09JTkZKNEo=').decode('utf-8')
    total = value + len(text)
    return total

def _αкБЭпδνΞчεχЮ():
    value = 532316
    text = __import__('base64').b64decode('Y09oMFdFendsRFdUYkZxYThka3M=').decode('utf-8')
    total = value + len(text)
    return total

def _ΨοЬШМПμЯ():
    if 20 * 17 < 0:
        pass
        pass
        pass
    value = 323626
    text = __import__('base64').b64decode('c0ZjYjZiUWgwQWFlWXpiQ0MwVU4=').decode('utf-8')
    total = value + len(text)
    if 84 * 69 < 0:
        555
    return total

def _ИιοзΩяжζжлηξШцр():
    value = 424072
    text = __import__('base64').b64decode('YllqVlZod0dhREgzak1JSDd6Ync=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        524
        942
    return total

def _иΞΓСЮαмаЙΩбΖ():
    value = 821220
    text = __import__('base64').b64decode('TVhhTTZYaTAzSmZOSFk1TXBybEc=').decode('utf-8')
    total = value + len(text)
    return total

def _ΓЯΗРпуЯЖвςΣ():
    value = 883837
    text = __import__('base64').b64decode('YmlPN2lTTXRLbTd5ZWpzUjFpTlc=').decode('utf-8')
    total = value + len(text)
    return total

def _ЭπЗΓИчИγФдуΙ():
    value = 811462
    text = __import__('base64').b64decode('dW1fdjNTWnlLaTd2QW5QZ2pWUjc=').decode('utf-8')
    total = value + len(text)
    return total

def _ςбΛЫИΣεθμβСΥМΗ():
    value = 889212
    text = __import__('base64').b64decode('Z0M4cHJWcWx0NTBYRDVQNXVlUHM=').decode('utf-8')
    total = value + len(text)
    return total

def _ΤлλщπАΦПΝπζ():
    value = 865900
    text = __import__('base64').b64decode('cU9Sc3dha25xRUUwSlJvY2lBV1A=').decode('utf-8')
    total = value + len(text)
    return total

def _чСαβВΚΩΛЙщщбρΨΥ():
    value = 72502
    text = __import__('base64').b64decode('V3BLQmJPejhPMmxfMjJlYnBBaWI=').decode('utf-8')
    if 53 * 69 < 0:
        196
        _dead_4655 = 922
        72
    total = value + len(text)
    return total

def _ЙβжζъРрС():
    value = 245544
    if 43 * 8 < 0:
        pass
        _dead_1302 = 500
        _dead_2379 = 607
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NQTvZ3wAr5JQACmu+FSqBxU520Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        237
        _dead_8749 = 959
        _dead_6320 = 397
    total = value + len(text)
    if 2 * 31 < 0:
        970
    return total

def _αНуζσΙοζнЭΧ():
    value = 66085
    text = __import__('base64').b64decode('Q2dWU0JUSmRrVlFSVmxFRTFBZmY=').decode('utf-8')
    total = value + len(text)
    return total

def _ТоζЦΝΜιЮгВ():
    value = 669147
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HyHjQlgIz4ZbHFmy926XIBJ47Ww='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        278
    return total

def _кςщνωγщТπм():
    if False and True:
        pass
        pass
    value = 854777
    if False and True:
        pass
        60
    text = __import__('base64').b64decode('Ym0xV1hxTXNoNDNjNUNWNjNGaWc=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        106
    return total

def _ТωЯГиΕоΖ():
    value = 1186
    text = __import__('base64').b64decode('R2lRY0dDSmNuRnkxY0lVVm9Sd3U=').decode('utf-8')
    total = value + len(text)
    return total

def _сωМрЫΒхЮяшмΡкПд():
    value = 382418
    if 36 * 55 < 0:
        204
        _dead_8442 = 717
        92
    text = __import__('base64').b64decode('bW9FNFZodWlrZGI3a3BybHhVM0I=').decode('utf-8')
    total = value + len(text)
    if 79 * 41 < 0:
        _dead_6780 = 287
        280
    return total

def _νηясалУЛ():
    if 53 * 7 < 0:
        399
        pass
        pass
    value = 44503
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CimzS0YfyowXLQWPyQK/Ljc25jc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _йΖхШγΔΦΦГХВωЙъβ():
    value = 782661
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('BzrUawkz9KsoCw2rwUaWFSN9wXs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΒЗΒΩОοΘхаΚαсρπΑ():
    value = 109099
    if 38 * 98 < 0:
        781
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LBq8ZGgQ0KIJOyWmzneZLQ9271o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 81 * 39 < 0:
        pass
        pass
    total = value + len(text)
    if 87 * 40 < 0:
        _dead_9803 = 86
    return total

def _ΟзРрνДепηЧРояζЭ():
    if len('') > 0:
        pass
        pass
        _dead_3748 = 611
    value = 839586
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CDfAQGZo5vkiCRaO51iVbS4d4zk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        361
        55
        pass
    return total

def _ЦΓυБχκвΡ():
    value = 942569
    text = __import__('base64').b64decode('UjhGdVVYOENQR001RlQyaFNMZkg=').decode('utf-8')
    total = value + len(text)
    return total

def _κИнδχφυαхЗΗΙΜ():
    value = 477673
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AH3hQH9o9YsnYwWB/Xi9HwM+tUQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΝЬΨцпЖоПΘбуЕТκ():
    value = 96144
    text = __import__('base64').b64decode('VEw3MHZJdkdmM001ZUV6ZG9QNDQ=').decode('utf-8')
    total = value + len(text)
    return total

def _λАплЭκЧСΞдмλчΠБВ():
    value = 582138
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Kw63aGIWqqY6Ph2P3UaoECMJw0c='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        227
    return total

def _йΤЬЮρζмΦЪъшΖΜΣ():
    value = 115499
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HAvtQXoP1LstHAaSy3epMSZ6t1w='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КβЕυΜцУуΩνα():
    value = 367748
    text = __import__('base64').b64decode('YV9QQU5Kbm84eHJPWVhwVU1HUUg=').decode('utf-8')
    if False and True:
        123
        _dead_4263 = 630
    total = value + len(text)
    return total

def _ρюЙιюНφжΓш():
    value = 144018
    text = __import__('base64').b64decode('V01wWjRKT2VrZE91VlJjV3Blcm4=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪбОАфΠНχхΩΔЭΕ():
    value = 418364
    text = __import__('base64').b64decode('ckVweVNINGN3aTZwdzFEUVFGNlc=').decode('utf-8')
    total = value + len(text)
    return total

def _еВηцβλПΑΜρΚΕ():
    value = 728746
    text = __import__('base64').b64decode('ZEhCNXZsR2Q5RlBuSWdQZGlyZ2Q=').decode('utf-8')
    total = value + len(text)
    return total

def _ψфКлкτФЭШЭλыйВЛ():
    value = 491672
    text = __import__('base64').b64decode('UEJWX0Z5VlNhRFptc0NoSHVTSV8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЛмκεйΣΟΕεψεКИ():
    value = 915476
    text = __import__('base64').b64decode('c3JqQ01GSmQ0VnZ0b2tWb2NCR3E=').decode('utf-8')
    if 79 * 39 < 0:
        _dead_7895 = 941
    total = value + len(text)
    return total

def _мΚбрЙюΝΒшчГя():
    value = 136090
    text = __import__('base64').b64decode('WER3X3ZGd0pHVU5KZElVMk1NMHE=').decode('utf-8')
    total = value + len(text)
    return total

def _оιЗΧρлΩνхХТлс():
    value = 432178
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQvbVgM68fspEBWB43SjEHA/wno='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ДΗдАμΟσЭΦЦ():
    value = 617460
    text = __import__('base64').b64decode('WUZpMkpCNTNvRlY0Sll5T1oyS3o=').decode('utf-8')
    if False and True:
        107
        _dead_7683 = 295
    total = value + len(text)
    return total

def _ХηкχΖГбэхзЬφп():
    value = 1999
    if len('') > 0:
        pass
        pass
    text = __import__('base64').b64decode('eE9HTnlzcnNzZnN4MDdrTFdlbE4=').decode('utf-8')
    if False and True:
        _dead_1636 = 271
        pass
        pass
    total = value + len(text)
    return total

def _эΤΕОврΠΠУκТ():
    value = 997381
    text = __import__('base64').b64decode('Vl9YUFExbEs3RmIwZFpTODJYOEQ=').decode('utf-8')
    if len('') > 0:
        pass
    total = value + len(text)
    return total

def _юνΗφСВΚοмщ():
    value = 694700
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Hx32ZUZpzZk0DxWg/neCIx0m1Gw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ШьЕαΩΗЗΑбΝζЗλеΛ():
    value = 702315
    if 5 * 4 < 0:
        _dead_5114 = 468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DSD2YG4j9JgTFVem5GGWGiAm12A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        _dead_4155 = 405
    total = value + len(text)
    return total

def _εкДНзЗЧбЛеыАКз():
    value = 160761
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KyryZW4UyqcsLFam6kyDYBol/lc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _бшυмΠμΩЗπыοЭВ():
    if 3 * 75 < 0:
        _dead_3264 = 811
        _dead_8336 = 894
        468
    value = 451658
    if False and True:
        986
        350
        899
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQnwX3ADwb4FKDqp21CbLXw/yXQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔтΣЮигΒυШЛж():
    if False and True:
        _dead_6544 = 890
        _dead_8880 = 896
    value = 9769
    if False and True:
        _dead_4037 = 447
        631
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IhfdPwI9y4EpbF2k93KTGCZ7sDk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_5569 = 452
    total = value + len(text)
    return total

def _φзкчеАΞнЛηЗΗчβΞΖ():
    value = 585406
    text = __import__('base64').b64decode('aVBJQkk3Y2RDVzliU2t4ekVOaE8=').decode('utf-8')
    total = value + len(text)
    return total

def _ЯγσжσΛυνωΝπΓςук():
    if False and True:
        _dead_4789 = 125
        pass
    value = 112562
    text = __import__('base64').b64decode('cTE1SmtrQ19KUmRmbEFza05jMXk=').decode('utf-8')
    total = value + len(text)
    return total

def _ЪПιαΓыωюжпυжΖοι():
    value = 303397
    if False and True:
        pass
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyPxNgANyfsvEQGGxgXEMBJ7z08='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if 72 * 7 < 0:
        pass
        pass
    return total

def _ВОЯΑЪЫЖλаεΝβвт():
    value = 117809
    if False and True:
        854
        941
        _dead_7855 = 672
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Lw7ld0YdyJchNiXz5kyAZBoMymo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        615
        pass
    total = value + len(text)
    return total

def _ЮЬоФΤКЛнуГФэΦΠВ():
    if 80 * 34 < 0:
        530
    value = 660393
    if False and True:
        534
        409
    text = __import__('base64').b64decode('RzZ4THkwZFpvUExZUWJuTUlHNXk=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6360 = 188
        362
    return total

def _ΡиьдФКδΦθеκκЩωХ():
    value = 103942
    text = __import__('base64').b64decode('Vlp0b1R0UDAzNzlQb3kyVjRrU3I=').decode('utf-8')
    total = value + len(text)
    return total

def _εЧШФуΤρψжапΞ():
    value = 106269
    if 5 * 87 < 0:
        104
        _dead_9815 = 150
    text = __import__('base64').b64decode('WldYUzhUTkNTTllIcXZHZlpWRjI=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        _dead_6977 = 143
    return total

def _ωзхΗκфЦКЪ():
    value = 347018
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('HQjjaAMc6YkvEBaix3mJDn0N72o='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μщζЦАειΗζ():
    value = 369622
    if False and True:
        341
        _dead_1693 = 347
        688
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JhjTVnsT2fsgAzeA2FCBDAof5Wg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _жмрьЙИθгъп():
    value = 180154
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LAnUXWAu/P07PjmmzVOpID0s22k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _σΖΚфбАτзрв():
    value = 760584
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ETW8fkYy/JpTIxeZ0Vy+YzYi12A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _КЬοТпнΗсб():
    if len('') > 0:
        _dead_3846 = 180
        pass
    value = 267052
    if len('') > 0:
        pass
        pass
        240
    text = __import__('base64').b64decode('anNXQjFxelBNX0J6YVNralJ5TUk=').decode('utf-8')
    if 62 * 33 < 0:
        pass
    total = value + len(text)
    return total

def _ЬιαΦηУΩшЧβ():
    value = 296867
    if False and True:
        760
        114
    text = __import__('base64').b64decode('Q0NBZ2ZkcU8yWDR2VFFxVzcyclk=').decode('utf-8')
    if False and True:
        32
        _dead_4034 = 154
        pass
    total = value + len(text)
    if 59 * 100 < 0:
        867
    return total

def _тτПαЙυЕΘдΟξДΕΑуц():
    value = 997547
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MwrBPkQPy4ZVOBqUyVicHBAnz2Q='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        pass
        _dead_4004 = 315
        700
    total = value + len(text)
    return total

def _ΦВыΡΖтртΕΡβЧГ():
    value = 306203
    text = __import__('base64').b64decode('WnN2VDRUNUMxbFZ3b3F5bFc5Z18=').decode('utf-8')
    total = value + len(text)
    return total

def _РΡχΦЪμсЭЯΚЗкεэ():
    value = 917101
    if 26 * 47 < 0:
        pass
        _dead_3229 = 200
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KQbNekIN6qYJPFaC7U+1Gws1xUs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ПπЫЪтфхΑΑ():
    value = 734353
    if 17 * 4 < 0:
        pass
        _dead_4834 = 155
        281
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ChfXamg20JIZPTqZ91CFBCIuyVs='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _μЬяλЗλΘшртз():
    value = 267748
    text = __import__('base64').b64decode('bWVYR2E5ZzIwU2NnTnNGUnF0cUc=').decode('utf-8')
    total = value + len(text)
    return total

def _мйΣЬПбЭι():
    value = 166559
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Chz+TQktza8WKAm3mkWZOTwO8WY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        952
    total = value + len(text)
    return total

def _кЙΞυζЙΑωФЦΔξА():
    value = 544421
    text = __import__('base64').b64decode('Z21RcDFueUcxUFlJNVIwd0dfWG4=').decode('utf-8')
    total = value + len(text)
    return total

def _ΜюЙзΡθΩΩИПчУт():
    value = 771606
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyWzWmFh0fkLLQuSyUTDHwEk60g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦлμхβФψθхζλ():
    value = 755595
    if False and True:
        _dead_6229 = 725
        651
    text = __import__('base64').b64decode('VDE1X0ZEZ3VRZTFQaUVFM05jbUU=').decode('utf-8')
    total = value + len(text)
    return total

def _хлαкжыПΖНЦВ():
    value = 880468
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NhfrXAVs6b4OFVbxnmylGCR5xWg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 80 * 28 < 0:
        pass
        _dead_9760 = 180
        967
    total = value + len(text)
    if 39 * 73 < 0:
        931
    return total

def _цΙуοЪфΖδΤππΒΟГЮψ():
    value = 234258
    text = __import__('base64').b64decode('VmNfenBkb0s3VWFoRlVPT1RJalo=').decode('utf-8')
    total = value + len(text)
    if False and True:
        pass
    return total

def _ΗαыжЧГПΥΗωκХх():
    value = 523031
    text = __import__('base64').b64decode('aTUzdTZpTjQxZFpVc2pLVENPZFA=').decode('utf-8')
    total = value + len(text)
    return total

def _ΣПОΕчχрμηпщБО():
    if len('') > 0:
        _dead_7266 = 937
        149
        453
    value = 554760
    text = __import__('base64').b64decode('dUcwWnhldFVyQUk4WDdpdm92aUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _кШΞΓиΔΑкъЭцΞкич():
    value = 358234
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CwDKb0sG+a4BCyORzXzHBhIgzl4='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шлФγοΦΖηйЛЖζеαБе():
    value = 107047
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MS78Rwdg0YIUHBq50UW7bSJ41Dc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        _dead_9394 = 971
    total = value + len(text)
    return total

def _зΘуλΩъпψХр():
    if len('') > 0:
        _dead_2187 = 257
        212
    value = 958597
    text = __import__('base64').b64decode('T29hNFRENVEzVW1uY2NjejFRUWs=').decode('utf-8')
    if len('') > 0:
        pass
        _dead_5453 = 212
    total = value + len(text)
    if len('') > 0:
        _dead_5219 = 758
    return total

def _ΚΨфаиТεραРφБΦΧαα():
    value = 911914
    text = __import__('base64').b64decode('ZXQ1U2RKSUd1THg5SDNpb1I1RXc=').decode('utf-8')
    total = value + len(text)
    return total

def _αрФσφυЮζλЮЮ():
    if 48 * 16 < 0:
        175
    value = 448135
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MQq1PFUK56xabR+q41GHMQM70Hc='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _НΘзФςΥьΓΣХ():
    value = 426009
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JBfAbFI6r/EsBR6U51KvFgR992A='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΦЪχΓфΨцЬЛСυ():
    value = 192711
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MTrUSUYwq48LFgWXzWO/Mholsmg='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _еСΝФΒПеомЖμκ():
    value = 241450
    text = __import__('base64').b64decode('YXVtRTNhRXBTODZfYlhZQmNSTGE=').decode('utf-8')
    total = value + len(text)
    return total

def _щΦΓΘчъηя():
    value = 546028
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PBbQT3UI1ZAIbjmo4keUBnR98GA='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if 80 * 97 < 0:
        _dead_3214 = 271
    total = value + len(text)
    if False and True:
        pass
        pass
        _dead_8897 = 387
    return total

def _ΖЖыЮмυΩЪЯятВ():
    value = 769461
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Iib0WmgAxKwFMj6cnVCXOhIttlk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ζЭιбОлγγηБТОΑΨ():
    value = 896406
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('LTf9N2Y47LIgalqU6QS+Ail3128='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _шюΦдΧпιВтП():
    if False and True:
        76
        _dead_3986 = 810
    value = 952700
    if len('') > 0:
        _dead_1889 = 433
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DyT2agdpz7IGHFetx3+iAC0/zVo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if len('') > 0:
        pass
        260
    return total

def _ΟЩМΞιξοΗΦΥυ():
    value = 28609
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('PD3meWAW37BaFBXzn1mibHIps0s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔΩθнσЩΨпЖпЗР():
    if len('') > 0:
        _dead_6079 = 601
        958
    value = 75773
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Ez7lZ0gVyqArbz6ZxFK8IA0D1mk='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        671
        259
        975
    total = value + len(text)
    return total

def _γλЛΘρчйΠΞзΟтεИ():
    value = 108383
    if False and True:
        pass
    text = __import__('base64').b64decode('QWhZY2RNcGx3M043YTdlcDVLdDk=').decode('utf-8')
    if len('') > 0:
        174
        _dead_7430 = 281
    total = value + len(text)
    return total

def _жбщщΧЭΩξ():
    if False and True:
        _dead_8950 = 547
    value = 537964
    text = __import__('base64').b64decode('c0lEVEp5b3lFTnZxMHRLek1tZnU=').decode('utf-8')
    total = value + len(text)
    return total

def _НΩФмяУМВςсн():
    value = 8662
    text = __import__('base64').b64decode('UkhSbTJzM08yb09zVDg4QjBRbWo=').decode('utf-8')
    total = value + len(text)
    return total

def _υтφхκеΧζАοОХΑ():
    value = 784610
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MDfna2gR+ZlbLyOC5XKUASwC9nQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΔωυνЫцЦφλО():
    if 98 * 90 < 0:
        992
        _dead_9240 = 44
        907
    value = 452351
    if False and True:
        _dead_8165 = 630
        501
        pass
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NyfBf2A/9/EhKDz04wHBEw99x0k='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        101
    return total

def _ЮьЪτыхρыωξлЧ():
    value = 90517
    if 19 * 24 < 0:
        241
        pass
        141
    text = __import__('base64').b64decode('WndqVE83cnIyd0cxUDgzYVRrbmE=').decode('utf-8')
    total = value + len(text)
    return total

def _ЧωДΔΡДηБ():
    value = 972469
    if len('') > 0:
        _dead_3179 = 832
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('JAXoNlIVr5ILMwyH+F+dHDc/8no='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ξοЖΗΚяΨΤкчΤыШи():
    if 33 * 7 < 0:
        230
        863
        pass
    value = 738086
    if len('') > 0:
        _dead_3111 = 916
        63
        _dead_4643 = 833
    text = __import__('base64').b64decode('ZVJhcjM4SEhROWxiaTNJa1FlcmU=').decode('utf-8')
    if 83 * 56 < 0:
        _dead_6204 = 297
        151
        484
    total = value + len(text)
    return total

def _ПΔυкЫΩΕΔ():
    value = 803963
    text = __import__('base64').b64decode('RlZtWXF5NW9FcWNQS1QwN0ZDR1E=').decode('utf-8')
    total = value + len(text)
    return total

def _шБКΦаκкАνΓςюоЫΝ():
    value = 6851
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CTX0b1YR+qQTFiv34gGmMCMV1TY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ИμлкВΘпЬ():
    value = 276830
    text = __import__('base64').b64decode('VVlubW1NWU1QeUxjT2x3ZVk2Nk4=').decode('utf-8')
    total = value + len(text)
    return total

def _МΨЫЫΧМΨЩтцΦя():
    value = 356227
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ED/hOAIu+55VODan2H6UGxF8wGo='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΣщПХνφκΖрΘЯМбεΔ():
    if False and True:
        _dead_2322 = 849
    value = 788925
    if 14 * 63 < 0:
        _dead_4867 = 395
        _dead_6413 = 539
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('CyDhNgUQzb4wI1/1znmjPysC6mQ='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if len('') > 0:
        pass
        81
        pass
    total = value + len(text)
    if 87 * 23 < 0:
        522
        pass
        _dead_7518 = 624
    return total

def _пкΩεЯΛψЬΔηАщЮ():
    if 35 * 88 < 0:
        _dead_7497 = 939
    value = 676788
    text = __import__('base64').b64decode('RmtZUkhjcE9qY0dXTUNxQmhkQnY=').decode('utf-8')
    if False and True:
        _dead_5816 = 863
        _dead_7884 = 211
        172
    total = value + len(text)
    return total

def _ΩЫΟВжΡзχτФοΒКфη():
    value = 848750
    text = __import__('base64').b64decode('WkVUWFBMOWJ2alprVjVPaGRyZzI=').decode('utf-8')
    if False and True:
        pass
        pass
        229
    total = value + len(text)
    return total

def _дπХΓоβηцΧБнГΖАω():
    value = 114753
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCrsT1No9awzMzupzWOXBnwfykU='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _вΞИПВτАθΡмΙгκ():
    value = 435396
    text = __import__('base64').b64decode('bDhhcFplT3U5c0ttczlwT3o4RGo=').decode('utf-8')
    total = value + len(text)
    return total

def _νХАЪΠΟυбМ():
    value = 653260
    text = __import__('base64').b64decode('bWlvaG5rNndxWkZ0WHpRcm1QbnA=').decode('utf-8')
    total = value + len(text)
    if len('') > 0:
        542
        864
        pass
    return total

def _χбΗβСаРΜ():
    value = 352695
    if 82 * 79 < 0:
        _dead_5099 = 328
        1000
    text = __import__('base64').b64decode('UXdUa1c0anRTSFA5SkE0YkZQdWE=').decode('utf-8')
    total = value + len(text)
    return total

def _Тшλгйюνшьηχя():
    value = 416048
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KC22Zlcy3aEnYiSx8FeSGzYc4Uw='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    return total

def _ΡκΑшиПΡфεκгжеΧъ():
    if False and True:
        38
        _dead_6163 = 920
    value = 84725
    if 67 * 14 < 0:
        891
        pass
        _dead_7898 = 856
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ESLobVA2qrkbAw6uwESvCwJ883g='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    total = value + len(text)
    if False and True:
        pass
    return total

def _щΨалЪюΞьΞχдВжς():
    value = 965526
    if 14 * 66 < 0:
        pass
        _dead_8065 = 103
    text = __import__('base64').b64decode('QjhRZXlLRDVITGl2YklIdlBZS1Q=').decode('utf-8')
    total = value + len(text)
    return total

def _κμωЧуШЫЦφχЧеΡ():
    value = 994200
    text = __import__('base64').b64decode('Q285ZFRjWGVNd3FTNzlYUjl2VkU=').decode('utf-8')
    total = value + len(text)
    return total

def _ΦхπΖСГχзΡ():
    value = 863341
    text = __import__('base64').b64decode('cll5Z1RMaUgwTmZJVDhiTEJHMUQ=').decode('utf-8')
    total = value + len(text)
    return total

def _ХμБΑπΘχΣыю():
    value = 904964
    text = __import__('base64').b64decode('aGxYMlBWSmU0aXJzdjlOTTR5NHg=').decode('utf-8')
    total = value + len(text)
    return total

def _ηдоКщςжιтφΜеζэХ():
    if 47 * 57 < 0:
        _dead_5587 = 204
        pass
    value = 610592
    if False and True:
        440
    text = (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('KALNe1MM6ZEAbwOO5W6yEy0n7X0='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))
    if False and True:
        540
    total = value + len(text)
    return total

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    if False and True:
        85
        850
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IA=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 32 | 1 > 0 and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()