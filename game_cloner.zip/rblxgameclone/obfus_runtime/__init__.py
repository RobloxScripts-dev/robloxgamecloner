
"""
Obfus Runtime Package

This package provides runtime support for obfuscated Python code.
"""

from ._runtime import __obfus__, __obfus_enter__, __obfus_exit__

__all__ = ['__obfus__', '__obfus_enter__', '__obfus_exit__']
