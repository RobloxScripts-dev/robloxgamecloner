
"""
Runtime support functions for obfuscated code.
"""

import base64
import hashlib
import marshal
import sys
import types
import zlib


def __obfus__(name, filepath, data):
    """
    Main entry point for loading obfuscated modules.

    Args:
        name: Module name
        filepath: Original file path
        data: Encrypted bytecode data
    """
    # Decode the data
    decoded = base64.b64decode(data)

    # Extract salt and encrypted content
    salt = decoded[:16]
    encrypted = decoded[16:]

    # Get the key from environment or embedded
    key = _get_key()

    # Derive decryption key
    dk = hashlib.pbkdf2_hmac('sha256', key, salt, 10000, dklen=32)

    # Decrypt
    decrypted = bytes(b ^ dk[i % len(dk)] for i, b in enumerate(encrypted))

    # Decompress
    decompressed = zlib.decompress(decrypted)

    # Load code object
    code = marshal.loads(decompressed)

    # Execute in caller's namespace
    frame = sys._getframe(1)
    exec(code, frame.f_globals)


def __obfus_enter__(data):
    """Enter protected code section."""
    decoded = base64.b64decode(data)
    decompressed = zlib.decompress(decoded)
    return marshal.loads(decompressed)


def __obfus_exit__():
    """Exit protected code section."""
    # Cleanup can be done here
    frame = sys._getframe(1)
    # Optionally clear sensitive data from frame
    pass


def _get_key():
    """Get the encryption key."""
    import os
    # Try environment variable first
    key = os.environ.get('OBFUS_KEY')
    if key:
        return base64.b64decode(key)
    # Fallback to embedded key (should be replaced during obfuscation)
    return b'\x00' * 32
